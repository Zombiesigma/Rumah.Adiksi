import React from 'react';

export default function SplashScreen() {
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-brand-charcoal text-white">
      <img src="/logo.png" alt="Rumah Adiksi Logo" className="w-40 h-40 animate-pulse" />
      <div className="mt-4 text-center">
        <h1 className="text-3xl font-serif font-black tracking-tight text-white">Rumah Adiksi</h1>
        <p className="text-sm text-gray-400 mt-1">Inkubator Talenta Kreatif Pesisir Pelabuhan Ratu</p>
      </div>
    </div>
  );
}
