import dotenv from 'dotenv';
import path from 'path';
dotenv.config({ path: path.join(process.cwd(), '.env') });

import express from 'express';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { db } from './src/lib/firebase';
import { doc, setDoc, getDoc, updateDoc, runTransaction } from 'firebase/firestore';

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));
  const PORT = 3000;

  // Bootstrap payment settings with user's real Midtrans Production configuration
  try {
    const pmDocRef = doc(db, 'settings', 'payment');
    const pmDocSnap = await getDoc(pmDocRef);
    if (!pmDocSnap.exists()) {
      await setDoc(pmDocRef, {
        bankAccountNumber: '1234567890',
        bankName: 'Bank Mandiri',
        beneficiaryName: 'Rumah Adiksi',
        midtransClientKey: 'Mid-client-RZ7OSPkvCWfZiqbB',
        midtransServerKey: 'Mid-server-KtgffMtgdopZOOJg9CcFIpAb',
        midtransIsProduction: true
      });
      console.log('[Firestore] Prefilled payment settings with Midtrans Production keys.');
    } else {
      const data = pmDocSnap.data();
      // If the old keys present or missing keys, upgrade to user's requested production keys
      if (data.midtransClientKey === 'SB-Mid-client-pXsz4fOPr4H24a2U' || !data.midtransClientKey) {
        await setDoc(pmDocRef, {
          ...data,
          midtransClientKey: 'Mid-client-RZ7OSPkvCWfZiqbB',
          midtransServerKey: 'Mid-server-KtgffMtgdopZOOJg9CcFIpAb',
          midtransIsProduction: true
        }, { merge: true });
        console.log('[Firestore] Upgraded Midtrans Sandbox keys to the requested Production credentials.');
      }
    }
  } catch (err) {
    console.warn('[Firestore] Skipped payment settings bootstrapping:', err);
  }

  // Helper to process payment success atomically with a Firestore transaction
  async function processPaymentSuccessAtomic(orderId: string) {
    const orderRef = doc(db, 'orders', orderId);
    
    await runTransaction(db, async (transaction) => {
      const orderSnap = await transaction.get(orderRef);
      if (!orderSnap.exists()) {
        throw new Error(`Order ${orderId} does not exist in database.`);
      }

      const orderData = orderSnap.data();
      if (orderData.status === 'paid') {
        console.log(`[Transaction] Order ${orderId} is already paid. Skipping.`);
        return;
      }

      // Mark order as paid
      transaction.update(orderRef, { 
        status: 'paid',
        updatedAt: new Date().toISOString()
      });

      // Update inventory atomically
      const items = orderData.items || [];
      for (const item of items) {
        if (item.itemType === 'shop') {
          const productRef = doc(db, 'shopItems', item.itemId);
          const productSnap = await transaction.get(productRef);
          if (productSnap.exists()) {
            const productData = productSnap.data();
            const currentStock = productData.stock || 0;
            const newStock = Math.max(0, currentStock - item.quantity);
            transaction.update(productRef, { stock: newStock });
            console.log(`[Transaction] Updated shop item ${item.itemId} stock: ${currentStock} -> ${newStock}`);
          }
        } else if (item.itemType === 'gallery') {
          const artworkRef = doc(db, 'artworks', item.itemId);
          transaction.update(artworkRef, { isSold: true });
          console.log(`[Transaction] Marked artwork ${item.itemId} as sold.`);
        }
      }
    });
  }

  // Checkout Endpoint
  app.post('/api/midtrans/checkout', async (req, res) => {
    try {
      const { orderId, amount, customerDetails, items, userId } = req.body;

      if (!orderId || !amount || !customerDetails || !items) {
        return res.status(400).json({ error: 'Missing required checkout details.' });
      }

      // Save order to Firestore as 'pending'
      const orderRef = doc(db, 'orders', orderId);
      await setDoc(orderRef, {
        id: orderId,
        amount,
        customerDetails,
        items,
        userId: userId || '',
        status: 'pending',
        createdAt: new Date().toISOString()
      });

      // Prepare Midtrans Payload
      // Note: orderId must be unique for each transaction sent to Midtrans
      const midtransPayload = {
        transaction_details: {
          order_id: orderId,
          gross_amount: amount
        },
        credit_card: {
          secure: true
        },
        customer_details: {
          first_name: customerDetails.name,
          email: customerDetails.email,
          phone: customerDetails.phone
        },
        item_details: items.map((item: any) => ({
          id: item.itemId || item.id,
          price: item.price,
          quantity: item.quantity,
          name: item.name.length > 50 ? item.name.slice(0, 47) + '...' : item.name
        }))
      };

      // Fetch Midtrans credentials dynamically from Firestore
      let serverKey = process.env.MIDTRANS_SERVER_KEY;
      if (!serverKey) {
        console.warn('MIDTRANS_SERVER_KEY is undefined in environment variables.');
      }
      let isProduction = process.env.MIDTRANS_IS_PRODUCTION === 'true';

      try {
        const settingsRef = doc(db, 'settings', 'payment');
        const settingsSnap = await getDoc(settingsRef);
        if (settingsSnap.exists()) {
          const settingsData = settingsSnap.data();
          if (settingsData.midtransServerKey) {
            serverKey = settingsData.midtransServerKey;
          }
          if (settingsData.midtransIsProduction !== undefined) {
            isProduction = settingsData.midtransIsProduction === true;
          } else if (serverKey) {
            isProduction = serverKey.startsWith('Mid-');
          }
        }
      } catch (dbErr) {
        console.warn('Could not load custom Midtrans settings from Firestore, using environment defaults:', dbErr);
      }

      if (!serverKey) {
        return res.status(500).json({ error: 'Sistem pembayaran belum dikonfigurasi (MIDTRANS_SERVER_KEY tidak ditemukan).' });
      }

      console.log(`[Midtrans] Checking out with server key: ${serverKey.slice(0, 15)}... (Environment: ${isProduction ? 'Production' : 'Sandbox'})`);
      const base64Key = Buffer.from(serverKey + ':').toString('base64');

      const response = await fetch(
        isProduction 
          ? 'https://app.midtrans.com/snap/v1/transactions' 
          : 'https://app.sandbox.midtrans.com/snap/v1/transactions', 
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': `Basic ${base64Key}`
          },
          body: JSON.stringify(midtransPayload)
        }
      );

      const data = await response.json() as any;

      if (!response.ok) {
        throw new Error(data.error_messages?.[0] || 'Midtrans error occurred.');
      }

      // Save Snap Token to Order Document
      await setDoc(orderRef, { snapToken: data.token }, { merge: true });

      res.json({ token: data.token, orderId });
    } catch (err: any) {
      console.error('Midtrans Checkout Error:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // Get Transaction Status from Midtrans
  app.get('/api/midtrans/status/:orderId', async (req, res) => {
    try {
      const { orderId } = req.params;
      
      // Fetch Midtrans credentials dynamically from Firestore
      let serverKey = process.env.MIDTRANS_SERVER_KEY;
      if (!serverKey) {
        console.warn('MIDTRANS_SERVER_KEY is undefined in environment variables.');
      }
      let isProduction = process.env.MIDTRANS_IS_PRODUCTION === 'true';

      try {
        const settingsRef = doc(db, 'settings', 'payment');
        const settingsSnap = await getDoc(settingsRef);
        if (settingsSnap.exists()) {
          const settingsData = settingsSnap.data();
          if (settingsData.midtransServerKey) {
            serverKey = settingsData.midtransServerKey;
          }
          if (settingsData.midtransIsProduction !== undefined) {
            isProduction = settingsData.midtransIsProduction === true;
          } else if (serverKey) {
            isProduction = serverKey.startsWith('Mid-');
          }
        }
      } catch (dbErr) {
        console.warn('Could not load custom Midtrans settings from Firestore:', dbErr);
      }

      if (!serverKey) {
        return res.status(500).json({ error: 'Sistem pembayaran belum dikonfigurasi (MIDTRANS_SERVER_KEY tidak ditemukan).' });
      }

      const base64Key = Buffer.from(serverKey + ':').toString('base64');
      const url = isProduction
        ? `https://api.midtrans.com/v2/${orderId}/status`
        : `https://api.sandbox.midtrans.com/v2/${orderId}/status`;

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Basic ${base64Key}`
        }
      });

      const data = await response.json() as any;

      if (!response.ok) {
        return res.status(response.status).json({ error: data.status_message || 'Gagal memeriksa status ke Midtrans.' });
      }

      const transactionStatus = data.transaction_status;
      const fraudStatus = data.fraud_status;

      const isSuccess = 
        transactionStatus === 'settlement' || 
        (transactionStatus === 'capture' && fraudStatus === 'accept');

      if (isSuccess) {
        await processPaymentSuccessAtomic(orderId);
        console.log(`Order ${orderId} marked as PAID and inventory updated atomically via Status Check.`);
      } else if (
        transactionStatus === 'cancel' || 
        transactionStatus === 'deny' || 
        transactionStatus === 'expire'
      ) {
        const orderRef = doc(db, 'orders', orderId);
        await updateDoc(orderRef, { 
          status: 'failed',
          updatedAt: new Date().toISOString()
        });
        console.log(`Order ${orderId} marked as FAILED via Status Check.`);
      }

      res.json({ transactionStatus, status: 'ok', detail: data });
    } catch (err: any) {
      console.error('Status Check Error:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // Callback / Webhook Endpoint
  app.post('/api/midtrans/callback', async (req, res) => {
    try {
      const midtransResponse = req.body;
      const orderId = midtransResponse.order_id;
      const transactionStatus = midtransResponse.transaction_status;
      const fraudStatus = midtransResponse.fraud_status;
      const statusCode = midtransResponse.status_code;
      const grossAmount = midtransResponse.gross_amount;
      const signatureKey = midtransResponse.signature_key;

      console.log(`Midtrans callback received for Order: ${orderId}, Status: ${transactionStatus}, Fraud: ${fraudStatus}`);

      if (!orderId) {
        return res.status(400).json({ error: 'Order ID is missing.' });
      }

      // Fetch Midtrans credentials dynamically from Firestore for signature validation
      let serverKey = process.env.MIDTRANS_SERVER_KEY;
      if (!serverKey) {
        console.warn('MIDTRANS_SERVER_KEY is undefined in environment variables.');
      }
      try {
        const settingsRef = doc(db, 'settings', 'payment');
        const settingsSnap = await getDoc(settingsRef);
        if (settingsSnap.exists()) {
          const settingsData = settingsSnap.data();
          if (settingsData.midtransServerKey) {
            serverKey = settingsData.midtransServerKey;
          }
        }
      } catch (dbErr) {
        console.warn('Could not load serverKey for signature verification:', dbErr);
      }

      if (!serverKey) {
        console.error('Cannot process callback because MIDTRANS_SERVER_KEY is not configured.');
        return res.status(500).json({ error: 'Server Key not configured for validation.' });
      }

      // Verify signature to secure callback
      if (signatureKey && statusCode && grossAmount) {
        const calculatedSignature = crypto
          .createHash('sha512')
          .update(orderId + statusCode + grossAmount + serverKey)
          .digest('hex');
          
        if (calculatedSignature !== signatureKey) {
          console.warn(`[Midtrans Callback] Signature validation failed! Calculated: ${calculatedSignature}, Got: ${signatureKey}`);
          return res.status(400).json({ error: 'Invalid signature key' });
        }
      }

      // Verify the status is successful
      const isSuccess = 
        transactionStatus === 'settlement' || 
        (transactionStatus === 'capture' && fraudStatus === 'accept');

      if (isSuccess) {
        await processPaymentSuccessAtomic(orderId);
        console.log(`Order ${orderId} marked as PAID and inventory updated atomically via Midtrans Callback.`);
      } else if (
        transactionStatus === 'cancel' || 
        transactionStatus === 'deny' || 
        transactionStatus === 'expire'
      ) {
        const orderRef = doc(db, 'orders', orderId);
        await updateDoc(orderRef, { 
          status: 'failed',
          updatedAt: new Date().toISOString()
        });
        console.log(`Order ${orderId} marked as FAILED via Midtrans Callback.`);
      }

      res.json({ status: 'ok' });
    } catch (err: any) {
      console.error('Midtrans Callback Error:', err);
      // Still return 200 to Midtrans to prevent continuous retries
      res.status(200).json({ error: err.message });
    }
  });

  async function uploadToImageKit(base64Content: string, fileName: string): Promise<string> {
    const imageKitEndpoint = process.env.IMAGEKIT_URL_ENDPOINT?.trim();
    const imageKitPrivateKey = process.env.IMAGEKIT_PRIVATE_KEY?.trim();
    if (!imageKitEndpoint || !imageKitPrivateKey) {
      throw new Error('ImageKit credentials are not configured. Set IMAGEKIT_URL_ENDPOINT and IMAGEKIT_PRIVATE_KEY.');
    }

    const buffer = Buffer.from(base64Content, 'base64');
    const ext = path.extname(fileName).toLowerCase() || '.jpg';
    let mimeType = 'image/jpeg';
    if (ext === '.png') mimeType = 'image/png';
    else if (ext === '.gif') mimeType = 'image/gif';
    else if (ext === '.webp') mimeType = 'image/webp';
    else if (ext === '.bmp') mimeType = 'image/bmp';

    const formData = new FormData();
    formData.append('file', base64Content);
    formData.append('fileName', fileName);
    if (process.env.IMAGEKIT_FOLDER) {
      formData.append('folder', process.env.IMAGEKIT_FOLDER.trim());
    }

    console.log(`[ImageKit Upload] Sending upload request... filename: ${fileName}, size: ${buffer.length} bytes`);

    const basicAuth = Buffer.from(`${imageKitPrivateKey}:`).toString('base64');
    const response = await fetch('https://upload.imagekit.io/api/v1/files/upload', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${basicAuth}`,
        'User-Agent': 'Rumah-Adiksi-App',
      },
      body: formData,
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`ImageKit API error: ${response.statusText} - ${errText}`);
    }

    const result = await response.json();
    if (result && result.url) {
      const finalUrl = result.url.trim();
      console.log(`[ImageKit Upload] Uploaded successfully! URL: ${finalUrl}`);
      return finalUrl;
    }
    throw new Error(`Unexpected ImageKit response format: ${JSON.stringify(result)}`);
  }

  async function uploadToImageKitFallback(base64Content: string, fileName: string): Promise<{ url: string; provider: string }> {
    const imageKitEndpoint = process.env.IMAGEKIT_URL_ENDPOINT?.trim();
    const imageKitPrivateKey = process.env.IMAGEKIT_PRIVATE_KEY?.trim();
    if (!imageKitEndpoint || !imageKitPrivateKey) {
      throw new Error('ImageKit is not configured. Set IMAGEKIT_URL_ENDPOINT and IMAGEKIT_PRIVATE_KEY to enable fallback.');
    }

    const url = await uploadToImageKit(base64Content, fileName);
    return { url, provider: 'imagekit' };
  }

  // GitHub / ImageKit Image Upload Endpoint
  app.post('/api/uploadToGithub', async (req, res) => {
    const { file, folder, userIdentifier } = req.body;
    if (!file || !file.name || !file.content) {
      return res.status(400).json({ message: 'Missing file data (name or content).' });
    }

    // 1. Sanitize file name & userIdentifier
    const sanitizedName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const uniqueFileName = `${Date.now()}_${sanitizedName}`;
    
    const cleanUserFolderName = userIdentifier 
      ? userIdentifier.trim().replace(/[^a-zA-Z0-9_-]/g, '_')
      : 'user';

    // 2. Determine GitHub Repo Path based on folder type:
    let githubPath = '';
    const lowerFolder = (folder || '').toLowerCase();

    if (lowerFolder === 'profil' || lowerFolder === 'profile' || lowerFolder === 'user-profile' || lowerFolder === 'avatar') {
      githubPath = `profil/${cleanUserFolderName}/${uniqueFileName}`;
    } else if (lowerFolder === 'karya' || lowerFolder === 'artwork' || lowerFolder === 'gallery') {
      githubPath = `karya/${uniqueFileName}`;
    } else if (lowerFolder === 'produk' || lowerFolder === 'shop' || lowerFolder === 'product') {
      githubPath = `produk/${uniqueFileName}`;
    } else if (lowerFolder) {
      githubPath = `${folder}/${uniqueFileName}`;
    } else {
      githubPath = `lainnya/${uniqueFileName}`;
    }

    try {
      console.log(`[Upload System] Initiating upload. Target Path inside repo: ${githubPath}`);

      const rawToken = process.env.GITHUB_PAT || process.env.GITHUB_TOKEN || process.env.VITE_GITHUB_TOKEN;
      const GITHUB_TOKEN = rawToken ? rawToken.trim().replace(/['"\r\n]/g, '') : '';

      const imageKitEnabled = Boolean(process.env.IMAGEKIT_URL_ENDPOINT?.trim() && process.env.IMAGEKIT_PRIVATE_KEY?.trim());
      if (!GITHUB_TOKEN) {
        if (!imageKitEnabled) {
          return res.status(500).json({ message: 'GITHUB_TOKEN tidak tersedia dan ImageKit tidak dikonfigurasi. Tidak ada backend upload yang tersedia.' });
        }

        console.warn('[GitHub Upload] GITHUB_TOKEN is not defined. Using ImageKit fallback only.');
        const fallbackResult = await uploadToImageKitFallback(file.content, file.name);
        return res.json({
          success: true,
          downloadUrl: fallbackResult.url,
          path: `${fallbackResult.provider}/${uniqueFileName}`,
          provider: fallbackResult.provider
        });
      }

      let GITHUB_REPO = 'Zombiesigma/aset-rumah-adiksi';
      const envRepo = process.env.GITHUB_REPO || process.env.VITE_GITHUB_REPO;
      if (envRepo) {
        const cleanedRepo = envRepo.replace(/['"\r\n]/g, '').trim();
        if (cleanedRepo.startsWith('http://') || cleanedRepo.startsWith('https://')) {
          try {
            const urlObj = new URL(cleanedRepo);
            const pathParts = urlObj.pathname.split('/').filter(Boolean);
            if (pathParts.length >= 2) {
              GITHUB_REPO = `${pathParts[0]}/${pathParts[1]}`;
            }
          } catch (e) {
            console.warn('[GitHub Upload] Failed to parse URL from GITHUB_REPO in env:', e);
          }
        } else if (cleanedRepo) {
          GITHUB_REPO = cleanedRepo;
        }
      }

      console.log(`[GitHub Upload] Attempting upload to GitHub repo: ${GITHUB_REPO}`);

      // Try uploading to GitHub API
      const response = await fetch(
        `https://api.github.com/repos/${GITHUB_REPO}/contents/${githubPath}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `token ${GITHUB_TOKEN}`,
            'Accept': 'application/vnd.github.v3+json',
            'Content-Type': 'application/json',
            'User-Agent': 'Rumah-Adiksi-App'
          },
          body: JSON.stringify({
            message: `Upload ${githubPath} via Rumah Adiksi Dashboard`,
            content: file.content, // base64 string
          }),
        }
      );

      let responseText = '';
      try {
        responseText = await response.text();
      } catch (readErr) {
        console.error('[GitHub Upload] Failed to read response body:', readErr);
      }

      let data: any = {};
      try {
        data = responseText ? JSON.parse(responseText) : {};
      } catch (parseErr) {
        console.error('[GitHub Upload] Failed to parse response JSON. Raw text:', responseText);
      }

      if (!response.ok) {
        console.warn(`[GitHub Upload Error] Status: ${response.status}. Message: ${data.message || responseText}. Falling back to ImageKit only...`);
        if (!imageKitEnabled) {
          throw new Error(`GitHub upload failed and ImageKit is not configured: ${data.message || responseText}`);
        }
        const fallbackResult = await uploadToImageKitFallback(file.content, file.name);
        return res.json({
          success: true,
          downloadUrl: fallbackResult.url,
          path: `${fallbackResult.provider}/${uniqueFileName}`,
          provider: fallbackResult.provider
        });
      }

      const downloadUrl = data.content?.download_url || `https://raw.githubusercontent.com/${GITHUB_REPO}/main/${githubPath}`;
      console.log(`[GitHub Upload] GitHub upload succeeded! URL: ${downloadUrl}`);

      res.json({
        success: true,
        downloadUrl,
        path: githubPath,
        provider: 'github'
      });

    } catch (err: any) {
      console.warn(`[Upload System Exception] ${err.message}.`);
      const imageKitEnabled = Boolean(process.env.IMAGEKIT_URL_ENDPOINT?.trim() && process.env.IMAGEKIT_PRIVATE_KEY?.trim());
      if (imageKitEnabled) {
        try {
          const fallbackResult = await uploadToImageKitFallback(file.content, file.name);
          return res.json({
            success: true,
            downloadUrl: fallbackResult.url,
            path: `${fallbackResult.provider}/${uniqueFileName}`,
            provider: fallbackResult.provider
          });
        } catch (fallbackErr: any) {
          console.error('[Upload System Final Failure] GitHub and ImageKit upload both failed:', fallbackErr);
          return res.status(500).json({
            message: `Gagal mengunggah gambar ke GitHub dan ImageKit. Rincian error: ${err.message || err} & ${fallbackErr.message || fallbackErr}`
          });
        }
      }
      console.error('[Upload System Final Failure] GitHub upload failed and ImageKit is not configured:', err);
      return res.status(500).json({
        message: `Gagal mengunggah gambar ke GitHub. ImageKit tidak dikonfigurasi: ${err.message || err}`
      });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

startServer();
