import React, { useState, useCallback } from 'react';
import { UploadCloud, Loader, AlertCircle, Sparkles, Image as ImageIcon, CheckCircle } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { showSuccessToast, showErrorToast } from '../lib/alerts';

interface ImageGitHubUploaderProps {
  // Set 1 (General Use)
  folder?: string;
  onUploadSuccess?: (url: string) => void;
  currentUser?: { uid: string; displayName?: string | null } | null;

  // Set 2 (Used in ProfileSection)
  value?: string;
  onChange?: (url: string) => void;
  userIdentifier?: string;
  label?: string;

  // Set 3 (Used in CommunitySection)
  folderName?: string;
}

// Helper function to convert file to Base64
const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = error => reject(error);
});

const ImageGitHubUploader: React.FC<ImageGitHubUploaderProps> = ({ 
  folder, 
  onUploadSuccess, 
  currentUser,
  value,
  onChange,
  userIdentifier,
  label,
  folderName
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadDone, setUploadDone] = useState(false);

  // Unify props fallback
  const resolvedFolder = folder || folderName || 'lainnya';
  const resolvedCallback = onUploadSuccess || onChange;
  const resolvedUserIdentifier = userIdentifier || currentUser?.displayName || currentUser?.uid || 'anonymous';

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setIsUploading(true);
    setError(null);
    setUploadDone(false);

    try {
        const base64content = await toBase64(file);

        const response = await fetch('/api/uploadToGithub', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                file: {
                    name: file.name,
                    content: base64content,
                },
                folder: resolvedFolder,
                userIdentifier: resolvedUserIdentifier,
            }),
        });

        let responseText = '';
        try {
            responseText = await response.text();
        } catch (readErr) {
            console.error("Gagal membaca respon:", readErr);
        }

        if (!response.ok) {
            let errorMsg = 'Gagal mengunggah file.';
            try {
                const errorData = JSON.parse(responseText);
                errorMsg = errorData.message || errorMsg;
            } catch {
                errorMsg = responseText || errorMsg;
            }
            throw new Error(errorMsg);
        }

        let downloadUrl = '';
        try {
            const data = JSON.parse(responseText);
            downloadUrl = data.downloadUrl;
        } catch (parseErr) {
            console.error("Gagal menguraikan JSON respon sukses:", parseErr);
            throw new Error("Respon server tidak valid.");
        }
        
        if (resolvedCallback && downloadUrl) {
          resolvedCallback(downloadUrl);
        }
        setUploadDone(true);
        showSuccessToast('Upload Berhasil', 'File telah berhasil diunggah dan tersimpan di cloud.');

    } catch (err: any) {
        console.error("Upload error:", err);
        showErrorToast('Upload Gagal', err.message || 'Terjadi kesalahan saat mengunggah ke GitHub Cloud.');
        setError(err.message || 'Terjadi kesalahan saat mengunggah ke GitHub Cloud.');
    } finally {
        setIsUploading(false);
    }
  }, [resolvedFolder, resolvedCallback, resolvedUserIdentifier]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.jpeg', '.png', '.gif', '.webp'] },
    multiple: false,
  } as any);

  return (
    <div className="w-full">
        {/* Render optional label */}
        {label && (
          <label className="text-[10px] font-mono font-extrabold text-gray-400 uppercase tracking-widest block mb-1.5">
            {label}
          </label>
        )}

        <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5 items-stretch">
          {/* Active Image Thumbnail Preview */}
          {value && (
            <div className="md:col-span-3 flex flex-col items-center justify-center p-2 bg-slate-950/75 border border-white/5 rounded-2xl relative group overflow-hidden h-28 md:h-auto min-h-[96px]">
              <img 
                src={value} 
                alt="Cloud Preview" 
                className="w-full h-full rounded-xl object-cover transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center p-2 text-center">
                <span className="text-[8px] font-mono text-brand-gold font-bold tracking-widest uppercase">
                  Cloud Active
                </span>
              </div>
            </div>
          )}

          {/* Upload Dropzone */}
          <div
            {...getRootProps()}
            className={`relative flex flex-col items-center justify-center p-5 border-2 border-dashed rounded-2xl cursor-pointer transition-all duration-350 select-none
                ${value ? 'md:col-span-9' : 'md:col-span-12'}
                ${isDragActive ? 'border-brand-gold bg-brand-gold/10' : 'border-white/10 hover:border-brand-gold/40 bg-black/15'}
                ${isUploading ? 'cursor-wait opacity-60' : ''}`}
          >
            <input {...getInputProps()} disabled={isUploading} />
            
            {isUploading ? (
              <div className="flex flex-col items-center text-brand-gold space-y-1.5 py-1">
                <Loader className="animate-spin h-5 w-5 mb-0.5" />
                <p className="text-[10px] font-mono font-black uppercase tracking-widest">Mengunggah ke Cloud...</p>
                <p className="text-[9px] text-gray-500">Menyimpan berkas di GitHub / ImageKit</p>
              </div>
            ) : uploadDone ? (
              <div className="flex flex-col items-center text-emerald-400 space-y-1.5 py-1 text-center">
                <CheckCircle className="h-5 w-5 animate-bounce mb-0.5" />
                <p className="text-[10px] font-mono font-black uppercase tracking-widest">Selesai Diunggah!</p>
                <p className="text-[9px] text-gray-500">Media tersimpan aman di Cloud Storage</p>
              </div>
            ) : (
              <div className="flex flex-col items-center text-center text-gray-400 space-y-1.5 py-1">
                <UploadCloud className="h-5 w-5 text-gray-500" />
                <p className="text-[10px] font-extrabold uppercase tracking-widest text-zinc-300">
                  Unggah Media Cloud
                </p>
                <p className="text-[9px] text-gray-500 leading-relaxed max-w-[210px]">
                  Klik / Seret foto untuk simpan otomatis di GitHub (dengan Fallback ImageKit)
                </p>
              </div>
            )}
          </div>
        </div>

        {error && (
          <div className="mt-2.5 flex items-start text-[10px] font-mono text-rose-300 bg-rose-950/40 border border-rose-500/10 p-3 rounded-xl leading-relaxed whitespace-pre-wrap">
            <AlertCircle className="h-4 w-4 mr-2 text-rose-400 flex-shrink-0" />
            <div className="space-y-0.5">
              <span className="font-bold text-rose-400 uppercase tracking-wider block">KESALAHAN CLOUD UPLOAD</span>
              <span>{error}</span>
            </div>
          </div>
        )}
    </div>
  );
};

export default ImageGitHubUploader;

