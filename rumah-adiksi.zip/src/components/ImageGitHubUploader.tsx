/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { UploadCloud, Link, FileCheck, AlertCircle, RefreshCw, Eye } from 'lucide-react';
import { uploadToGitHub } from '../lib/github';

interface ImageGitHubUploaderProps {
  value: string;
  onChange: (url: string) => void;
  folder: 'profil' | 'karya' | 'produk' | 'events' | 'community';
  userIdentifier?: string; // e.g. user.displayName or user.uid
  label?: string;
  placeholder?: string;
}

export default function ImageGitHubUploader({
  value,
  onChange,
  folder,
  userIdentifier,
  label = 'Tautan Gambar / Unggah Berkas',
  placeholder = 'https://images.unsplash.com/... atau seret file'
}: ImageGitHubUploaderProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);
  const [mode, setMode] = useState<'upload' | 'url'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragActive(true);
    } else if (e.type === 'dragleave') {
      setIsDragActive(false);
    }
  };

  const processFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorText('Hanya file gambar yang diizinkan!');
      return;
    }
    // Limit to 5MB to be safe with GitHub APIs
    if (file.size > 5 * 1024 * 1024) {
      setErrorText('Maksimum ukuran gambar adalah 5MB!');
      return;
    }

    setUploading(true);
    setErrorText(null);

    try {
      const downloadUrl = await uploadToGitHub(file, folder, userIdentifier);
      onChange(downloadUrl);
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || 'Gagal mengunggah berkas.');
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      await processFile(e.target.files[0]);
    }
  };

  const selectFile = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-2 w-full text-left">
      <div className="flex items-center justify-between">
        <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
          {label}
        </label>
        <div className="flex gap-1.5 p-0.5 bg-slate-950 rounded-lg border border-white/5">
          <button
            type="button"
            onClick={() => {
              setMode('upload');
              setErrorText(null);
            }}
            className={`px-2.5 py-1 rounded-md text-[9px] uppercase font-mono font-bold transition-all cursor-pointer ${
              mode === 'upload'
                ? 'bg-brand-gold text-brand-charcoal'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Unggah Aset
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('url');
              setErrorText(null);
            }}
            className={`px-2.5 py-1 rounded-md text-[9px] uppercase font-mono font-bold transition-all cursor-pointer ${
              mode === 'url'
                ? 'bg-brand-gold text-brand-charcoal'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Tautan Web
          </button>
        </div>
      </div>

      {mode === 'upload' ? (
        <div
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={selectFile}
          className={`relative group border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] transition-all overflow-hidden ${
            isDragActive
              ? 'border-brand-gold bg-brand-gold/5 scale-[1.01]'
              : uploading
              ? 'border-amber-500/40 bg-amber-500/5 cursor-wait'
              : value
              ? 'border-emerald-500/20 bg-emerald-500/5 hover:border-emerald-500/40'
              : 'border-white/10 bg-black/40 hover:border-white/20'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
            disabled={uploading}
          />

          {uploading ? (
            <div className="space-y-2 flex flex-col items-center">
              <RefreshCw className="w-6 h-6 text-brand-gold animate-spin" />
              <div>
                <p className="text-[10px] font-mono font-bold text-gray-300">MENGUNGGAH KE GITHUB</p>
                <p className="text-[9px] text-gray-500">Mentransfer aset ke direktori cloud...</p>
              </div>
            </div>
          ) : value ? (
            <div className="flex flex-col items-center gap-2">
              <div className="relative w-12 h-12 rounded-lg border border-emerald-500/30 overflow-hidden bg-slate-950">
                <img
                  src={value}
                  alt="Aset terunggah"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Eye className="w-3.5 h-3.5 text-white" />
                </div>
              </div>
              <div>
                <p className="text-[10px] font-mono font-bold text-emerald-400 flex items-center gap-1 justify-center">
                  <FileCheck className="w-3.5 h-3.5" /> GAMBAR BERHASIL DISINKRON
                </p>
                <p className="text-[9px] text-gray-500">Klik atau seret file lain untuk menggantinya</p>
              </div>
            </div>
          ) : (
            <div className="space-y-1">
              <UploadCloud className="w-6 h-6 text-gray-500 hover:text-brand-gold mx-auto transition-colors" />
              <p className="text-[10px] font-mono font-bold text-gray-300">KLIK / SERET GAMBAR KE SINI</p>
              <p className="text-[9px] text-gray-500">Direktori cloud: github://{folder}/assets</p>
            </div>
          )}

          {errorText && (
            <div className="absolute inset-x-0 bottom-0 bg-rose-500/90 text-white py-1 px-3 flex items-center justify-center gap-1 text-[9px] font-bold">
              <AlertCircle className="w-3 h-3 text-white" /> {errorText}
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-1.5">
          <div className="relative">
            <Link className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="url"
              placeholder={placeholder}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              className="w-full bg-black/40 border border-white/10 hover:border-white/20 focus:border-brand-gold outline-none rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder-gray-600 transition-colors"
            />
          </div>
          {value && (
            <div className="flex items-center gap-2 mt-1.5 p-2 bg-slate-950/55 rounded-lg border border-white/5">
              <div className="w-8 h-8 rounded overflow-hidden">
                <img
                  src={value}
                  alt="Url preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-[9px] text-gray-500 line-clamp-1 truncate font-mono">
                {value}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
