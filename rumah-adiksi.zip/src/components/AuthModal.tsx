/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Mail, Lock, User as UserIcon, LogIn, ChevronRight, Check } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider
} from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (message: string) => void;
  onGoogleLogin: () => Promise<void>;
  onAnonymousLogin: (nickname: string) => Promise<void>;
}

export default function AuthModal({ 
  isOpen, 
  onClose, 
  onSuccess, 
  onGoogleLogin, 
  onAnonymousLogin 
}: AuthModalProps) {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Guest nickname flow
  const [tempNickname, setTempNickname] = useState('');
  const [showGuestInput, setShowGuestInput] = useState(false);

  if (!isOpen) return null;

  const handleEmailAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg('Silakan lengkapi semua bidang.');
      return;
    }
    if (activeTab === 'signup' && !displayName) {
      setErrorMsg('Nama lengkap wajib diisi untuk pendaftaran.');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Sandi harus berukuran minimal 6 karakter.');
      return;
    }

    setLoading(true);
    setErrorMsg('');

    try {
      if (activeTab === 'signup') {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Update Firebase profile info
        await updateProfile(user, {
          displayName: displayName.trim(),
          photoURL: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80`
        });

        // Initialize User Profile Document in Firestore with Role Information
        const isDefaultAdmin = email.toLowerCase() === 'gunturfadilah140@gmail.com';
        const assignedRole = isDefaultAdmin ? 'admin' : 'user';

        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          email: user.email,
          displayName: displayName.trim(),
          photoURL: user.photoURL || '',
          role: assignedRole,
          createdAt: new Date().toISOString()
        });

        onSuccess(`Akun berhasil dibuat! Selamat bergabung, ${displayName.trim()}.`);
        onClose();
      } else {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        onSuccess(`Selamat datang kembali, ${user.displayName || 'Kreator Pesisir'}!`);
        onClose();
      }
    } catch (error: any) {
      console.error('Firebase Auth Operation Failed: ', error);
      let userFriendlyMessage = 'Terjadi kesalahan. Silakan periksa kembali data Anda.';
      
      switch (error?.code) {
        case 'auth/email-already-in-use':
          userFriendlyMessage = 'Email ini sudah terdaftar. Silakan masuk.';
          break;
        case 'auth/invalid-email':
          userFriendlyMessage = 'Format alamat email tidak valid.';
          break;
        case 'auth/weak-password':
          userFriendlyMessage = 'Sandi terlalu lemah (minimal 6 karakter).';
          break;
        case 'auth/wrong-password':
        case 'auth/user-not-found':
        case 'auth/invalid-credential':
          userFriendlyMessage = 'Email atau sandi salah. Silakan coba lagi.';
          break;
        case 'auth/operation-not-allowed':
          userFriendlyMessage = 'Metode Email/Sandi belum diaktifkan di Firebase Console Anda.\n\nCara mengaktifkan:\n1. Buka Firebase Console proyek Anda.\n2. Klik menu "Authentication" > tab "Sign-in method".\n3. Klik "Add new provider" / pilih "Email/Password".\n4. Aktifkan (Enable) lalu klik "Save" / "Simpan".';
          break;
        case 'auth/network-request-failed':
          userFriendlyMessage = 'Koneksi Otentikasi Terblocked (auth/network-request-failed).\n\nHal ini biasanya disebabkan oleh:\n1. Adblocker (uBlock, AdBlock, dll) atau Brave Shields aktif dan memblokir domain auth Google.\n2. Pembatasan lingkungan sandbox Iframe pada editor.\n\nHari ini, kami SANGAT menyarankan Anda:\n- Klik ikon "Buka di tab baru" di kanan atas pratinjau untuk menjalankan aplikasi di luar iframe.\n- Nonaktifkan sementara adblocker Anda untuk situs pratinjau ini.';
          break;
        default:
          if (error?.message) {
            userFriendlyMessage = error.message;
          }
          break;
      }
      setErrorMsg(userFriendlyMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-brand-card border border-white/5 rounded-3xl p-6 md:p-8 max-w-md w-full space-y-6 shadow-2xl relative overflow-hidden"
      >
        {/* Ambient background decoration */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-gold/10 rounded-full filter blur-[40px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-brand-indigo/10 rounded-full filter blur-[40px] pointer-events-none" />

        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-gray-400 hover:text-white rounded-lg bg-white/5 transition-colors cursor-pointer"
          title="Tutup"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-1">
          <div className="inline-flex items-center gap-1.5 text-brand-gold text-xs font-mono font-bold uppercase tracking-wider bg-brand-gold/15 px-3 py-1 rounded-full mb-2">
            <Lock className="w-3.5 h-3.5" />
            <span>AKSES RUMAH ADIKSI</span>
          </div>
          <h3 className="text-2xl font-serif font-black text-white tracking-tight">
            {activeTab === 'signin' ? 'Masuk ke Akun Anda' : 'Daftar Akun Baru'}
          </h3>
          <p className="text-xs text-gray-400 max-w-xs mx-auto">
            Terhubunglah dengan ekosistem kreatif Pelabuhan Ratu, Sukabumi
          </p>
        </div>

        {/* Tab Selection Switch */}
        <div className="grid grid-cols-2 p-1 bg-black/50 rounded-xl border border-white/5">
          <button
            onClick={() => {
              setActiveTab('signin');
              setErrorMsg('');
            }}
            className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'signin'
                ? 'bg-brand-gold/20 text-brand-gold border border-brand-gold/30'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Masuk
          </button>
          <button
            onClick={() => {
              setActiveTab('signup');
              setErrorMsg('');
            }}
            className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'signup'
                ? 'bg-brand-gold/20 text-brand-gold border border-brand-gold/30'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Daftar
          </button>
        </div>

        {/* Form Error Box Container */}
        {errorMsg && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/25 rounded-xl text-rose-400 text-xs leading-relaxed text-left font-medium whitespace-pre-line">
            {errorMsg}
          </div>
        )}

        {/* Live Form Setup */}
        {!showGuestInput ? (
          <form onSubmit={handleEmailAction} className="space-y-4">
            {activeTab === 'signup' && (
              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Nama Lengkap</label>
                <div className="relative">
                  <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Rian Citepus"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 hover:border-white/20 focus:border-brand-gold outline-none rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-gray-600 transition-colors"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Akses Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="email"
                  required
                  placeholder="alamat@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 hover:border-white/20 focus:border-brand-gold outline-none rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-gray-600 transition-colors"
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Kata Sandi</label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-[10px] text-brand-gold hover:underline cursor-pointer focus:outline-none"
                >
                  {showPassword ? 'Sembunyikan' : 'Tampilkan'}
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Min. 6 karakter"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 hover:border-white/20 focus:border-brand-gold outline-none rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-gray-600 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-brand-gold to-amber-500 hover:from-white hover:to-white disabled:from-neutral-800 disabled:to-neutral-800 disabled:text-neutral-500 text-brand-charcoal font-black rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-lg mt-6"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-3 h-3 border-2 border-brand-charcoal border-t-transparent rounded-full animate-spin" />
                  Memproses Akses...
                </span>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>{activeTab === 'signin' ? 'Masuk Sekarang' : 'Daftarkan Akun'}</span>
                </>
              )}
            </button>
          </form>
        ) : (
          /* Guest Access Flow */
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block">Nama Samaran Tamu</label>
              <input
                type="text"
                placeholder="Masukkan nama samaran Anda..."
                value={tempNickname}
                onChange={(e) => setTempNickname(e.target.value)}
                className="w-full bg-black/40 border border-white/10 hover:border-white/20 focus:border-brand-gold outline-none rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 transition-colors"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && tempNickname.trim()) {
                    setLoading(true);
                    onAnonymousLogin(tempNickname)
                      .then(() => onClose())
                      .catch(() => {})
                      .finally(() => setLoading(false));
                  }
                }}
              />
            </div>
            
            <button
              onClick={() => {
                if (!tempNickname.trim()) return;
                setLoading(true);
                onAnonymousLogin(tempNickname)
                  .then(() => onClose())
                  .catch(() => {})
                  .finally(() => setLoading(false));
              }}
              disabled={loading || !tempNickname.trim()}
              className="w-full py-2.5 bg-brand-gold hover:bg-white text-brand-charcoal font-black text-xs rounded-xl transition-all cursor-pointer"
            >
              {loading ? 'Menghubungkan...' : 'Masuk sebagai Tamu'}
            </button>

            <button
              onClick={() => {
                setShowGuestInput(false);
                setErrorMsg('');
              }}
              className="w-full py-2 text-center text-gray-400 hover:text-white text-xs cursor-pointer font-semibold block"
            >
              Kembali ke Login Email
            </button>
          </div>
        )}

        {/* Social Authentication and Alternative controls */}
        {!showGuestInput && (
          <div className="space-y-4 pt-4 border-t border-white/5">
            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/5"></div>
              </div>
              <span className="relative px-3 bg-brand-card text-[10px] font-mono text-gray-500 uppercase tracking-widest">Atau Hubungkan Lewat</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Google Button */}
              <button
                type="button"
                onClick={async () => {
                  try {
                    await onGoogleLogin();
                    onClose();
                  } catch (e) {
                    // Handled inside handleGoogleLogin
                  }
                }}
                className="py-2 px-3 bg-white/5 hover:bg-white/10 text-xs font-semibold text-gray-200 border border-white/5 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <img 
                  src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/smartlock/iframe/google.svg" 
                  alt="Google"
                  className="w-3.5 h-3.5"
                />
                <span>Google</span>
              </button>

              {/* Guest Login button */}
              <button
                type="button"
                onClick={() => setShowGuestInput(true)}
                className="py-2 px-3 bg-white/5 hover:bg-white/10 text-xs font-semibold text-gray-200 border border-white/5 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <UserIcon className="w-3.5 h-3.5 text-brand-gold" />
                <span>Tamu Samaran</span>
              </button>
            </div>
          </div>
        )}

        {/* Terms detail footer */}
        <div className="text-[10px] text-gray-500 text-center leading-relaxed font-sans">
          Harap bijak. Dengan masuk Anda menyetujui kedaulatan komunitas dan program digitalisasi Rumah Adiksi Pelabuhan Ratu.
        </div>
      </motion.div>
    </div>
  );
}
