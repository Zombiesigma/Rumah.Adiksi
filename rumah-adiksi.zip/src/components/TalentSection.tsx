/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Instagram,
  Youtube,
  Pin,
  Award,
  Link2,
  BookOpen,
  ArrowUpRight,
  ExternalLink
} from 'lucide-react';
import { Talent, GalleryItem } from '../types';

interface TalentSectionProps {
  talents: Talent[];
  artworks: GalleryItem[];
  selectedTalentId: string | null;
  setSelectedTalentId: (id: string | null) => void;
  setActiveTab: (tab: string) => void;
  onExploreArtDetail: (art: GalleryItem) => void;
}

export default function TalentSection({
  talents,
  artworks,
  selectedTalentId,
  setSelectedTalentId,
  setActiveTab,
  onExploreArtDetail
}: TalentSectionProps) {
  const [searchField, setSearchField] = useState('');
  const [selectedSubLocation, setSelectedSubLocation] = useState('all');

  const fields = Array.from(new Set(talents.map((t) => t.field)));
  const locations = Array.from(
    new Set(talents.map((t) => t.location.replace('Pelabuhan Ratu - ', '')))
  );

  const filteredTalents = talents.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(searchField.toLowerCase()) ||
      t.field.toLowerCase().includes(searchField.toLowerCase()) ||
      t.skills.some((s) => s.toLowerCase().includes(searchField.toLowerCase()));

    const matchesLocation =
      selectedSubLocation === 'all' ||
      t.location.includes(selectedSubLocation);

    return matchesSearch && matchesLocation;
  });

  const getTalentArtworks = (talentId: string) => {
    return artworks.filter((art) => art.artistId === talentId);
  };

  return (
    <div className="space-y-8 py-4">
      {/* Directory Title and Filters */}
      <div className="space-y-6">
        <div className="space-y-2 border-b border-white/5 pb-6">
          <span className="text-xs font-mono text-brand-gold uppercase tracking-wider">PULSE OF PELABUHAN RATU</span>
          <h2 className="font-serif text-3xl font-bold text-white tracking-tight">Direktori Bakat Tradisi & Modern</h2>
          <p className="text-xs text-gray-400 max-w-xl">
            Sinergi pemuda berbakat dari Citepus, Cisolok, Karanghawu, hingga Cimaja. Temukan seniman, musisi indie, pengrajin ramah lingkungan, dan kreator kustom.
          </p>
        </div>

        {/* Searching and Sublocation Filter tools */}
        <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between">
          <div className="relative flex-grow max-w-md">
            <input
              type="text"
              placeholder="Cari talenta, keahlian (misal: mural, gitar, ukir)..."
              value={searchField}
              onChange={(e) => setSearchField(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-950 border border-white/10 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-brand-gold/60 transition-colors"
            />
          </div>

          <div className="flex gap-2 items-center flex-wrap">
            <span className="text-xs font-mono text-gray-500 flex items-center gap-1">
              <Pin className="w-3 h-3" /> Wilayah:
            </span>
            <button
              onClick={() => setSelectedSubLocation('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                selectedSubLocation === 'all'
                  ? 'bg-amber-500/10 text-brand-gold border border-brand-gold/30 font-semibold'
                  : 'text-gray-400 bg-transparent border border-white/5 hover:text-white'
              }`}
            >
              Semua
            </button>
            {locations.map((loc) => (
              <button
                key={loc}
                onClick={() => setSelectedSubLocation(loc)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  selectedSubLocation === loc
                    ? 'bg-amber-500/10 text-brand-gold border border-brand-gold/30 font-semibold'
                    : 'text-gray-400 bg-transparent border border-white/5 hover:text-white'
                }`}
              >
                {loc}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Directory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="talents-grid">
        {filteredTalents.map((talent) => {
          const personalArt = getTalentArtworks(talent.id);
          const isExpanded = selectedTalentId === talent.id;

          return (
            <div
              key={talent.id}
              className={`group flex flex-col justify-between p-6 rounded-2xl border transition-all duration-300 relative overflow-hidden ${
                isExpanded
                  ? 'bg-gradient-to-b from-slate-950 to-slate-900 border-brand-gold/45 shadow-xl md:col-span-2 lg:col-span-3'
                  : 'bg-slate-900/30 hover:bg-slate-900/50 border-white/5 hover:border-brand-gold/15'
              }`}
              id={`talent-card-${talent.id}`}
            >
              <div className="space-y-4">
                {/* Profile Header Block */}
                <div className="flex items-start gap-4">
                  {/* Glowing Profile Pic Frame */}
                  <div className="relative flex-shrink-0">
                    <div className="absolute -inset-1 bg-gradient-to-tr from-brand-gold/30 to-amber-500/30 rounded-full blur-sm opacity-0 group-hover:opacity-100 transition-opacity" />
                    <img
                      src={talent.avatarUrl}
                      alt={talent.name}
                      referrerPolicy="no-referrer"
                      loading="lazy"
                      className="w-14 h-14 rounded-full object-cover border border-brand-gold relative z-10"
                    />
                  </div>

                  {/* Identity */}
                  <div className="space-y-1">
                    <h3 className="font-serif text-lg font-bold text-white group-hover:text-brand-gold transition-colors">
                      {talent.name}
                    </h3>
                    <p className="text-xs font-mono text-brand-gold font-medium leading-none flex items-center gap-1">
                      <Award className="w-3 h-3 text-brand-gold" /> {talent.field}
                    </p>
                    <div className="text-[10px] text-gray-500 font-mono tracking-wide flex items-center gap-1">
                      <Pin className="w-3 h-3" /> {talent.location}
                    </div>
                  </div>
                </div>

                {/* Biography */}
                <p className="text-xs text-gray-400 leading-relaxed line-clamp-3">
                  {talent.bio}
                </p>

                {/* Specialties Chips */}
                <div className="flex flex-wrap gap-1">
                  {talent.skills.slice(0, 4).map((skill) => (
                    <span
                      key={skill}
                      className="text-[9px] font-mono px-2 py-0.5 bg-white/5 border border-white/10 rounded text-gray-300"
                    >
                      {skill}
                    </span>
                  ))}
                </div>

                {/* EXPANED SECTION: Showcases portfolios and deep engagement */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden border-t border-white/5 pt-4 mt-4 space-y-4"
                    >
                      {/* Social handles container */}
                      <div className="flex items-center gap-4 text-xs font-mono">
                        <span className="text-gray-500 font-medium">Sambungkan Kreativitas:</span>
                        {talent.socialMedia.instagram && (
                          <a
                            href={`https://instagram.com/${talent.socialMedia.instagram}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-gray-300 hover:text-brand-gold transition-colors"
                          >
                            <Instagram className="w-4 h-4 text-pink-500" /> @{talent.socialMedia.instagram}
                          </a>
                        )}
                        {talent.socialMedia.youtube && (
                          <a
                            href="#"
                            className="flex items-center gap-1 text-gray-300 hover:text-red-400 transition-colors"
                          >
                            <Youtube className="w-4 h-4 text-red-500" /> YouTube
                          </a>
                        )}
                        {talent.socialMedia.tiktok && (
                          <span className="text-gray-300 flex items-center gap-1">
                            <span className="font-bold text-indigo-400">T</span> @{talent.socialMedia.tiktok}
                          </span>
                        )}
                      </div>

                      {/* Portfolios Gallery Row */}
                      <div className="space-y-3">
                        <h4 className="text-xs font-mono text-brand-gold uppercase tracking-wider flex items-center gap-1">
                          <BookOpen className="w-3.5 h-3.5" /> Karya yang Dipromosikan ({personalArt.length})
                        </h4>

                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                          {personalArt.map((art) => (
                            <div
                              key={art.id}
                              onClick={() => {
                                onExploreArtDetail(art);
                                setActiveTab('gallery');
                              }}
                              className="group/art relative aspect-square rounded-xl overflow-hidden bg-slate-950 border border-white/10 hover:border-brand-gold cursor-pointer"
                            >
                              <img
                                src={art.imageUrl}
                                alt={art.title}
                                referrerPolicy="no-referrer"
                                loading="lazy"
                                className="w-full h-full object-cover transition-transform duration-500 group-hover/art:scale-110"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 to-transparent opacity-100 md:opacity-0 group-hover/art:opacity-100 transition-all flex flex-col justify-end p-2.5">
                                <h5 className="text-[10px] text-white font-bold tracking-tight line-clamp-1">{art.title}</h5>
                                <span className="text-[9px] text-brand-gold mt-0.5 font-semibold flex items-center gap-0.5">
                                  Lihat Detail <ArrowUpRight className="w-2.5 h-2.5" />
                                </span>
                              </div>
                            </div>
                          ))}
                          {personalArt.length === 0 && (
                            <div className="col-span-full border border-dashed border-white/5 rounded-xl p-6 text-center text-[11px] text-gray-500">
                              Artis ini belum mengunggah karya ke etalase utama.
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Toggle Detail / Collaboration Action buttons */}
              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                <button
                  onClick={() => setSelectedTalentId(isExpanded ? null : talent.id)}
                  className={`text-xs font-semibold px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
                    isExpanded
                      ? 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
                      : 'bg-brand-gold/10 hover:bg-brand-gold/20 text-brand-gold border border-brand-gold/20'
                  }`}
                >
                  {isExpanded ? 'Tutup Detail' : 'Lihat Portofolio'}
                </button>

                <a
                  href={`https://wa.me/6281234567890?text=Halo%20Rumah%20Adiksi,%20saya%20tertarik%20untuk%20berkolaborasi%20atau%20memesan%20karya%20dari%20seniman%20${encodeURIComponent(talent.name)}.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-gray-300 hover:text-white flex items-center gap-1"
                >
                  Ajukan Kolaborasi <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {filteredTalents.length === 0 && (
        <div className="text-center py-16 bg-slate-900/20 rounded-2xl border border-white/5">
          <p className="text-gray-400">Tidak ada talenta yang cocok dengan kriteria pencarian Anda.</p>
        </div>
      )}
    </div>
  );
}
