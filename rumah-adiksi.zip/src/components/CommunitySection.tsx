/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, 
  Heart, 
  Send, 
  Users, 
  Plus, 
  Check, 
  Search, 
  Trash2, 
  Calendar, 
  Clock, 
  MapPin, 
  Tag, 
  Palette, 
  Lightbulb,
  X,
  Share2,
  ChevronRight,
  Info,
  Star,
  PlusCircle,
  Award,
  BookOpen,
  Filter,
  CheckCircle,
  HelpCircle,
  Lock
} from 'lucide-react';
import { CommunityPost } from '../types';
import { db, auth, handleFirestoreError, OperationType, cleanUndefined } from '../lib/firebase';
import { doc, setDoc, deleteDoc } from 'firebase/firestore';
import ImageGitHubUploader from './ImageGitHubUploader';
import { User as FirebaseUser } from 'firebase/auth';

interface CommunitySectionProps {
  posts: CommunityPost[];
  setPosts: React.Dispatch<React.SetStateAction<CommunityPost[]>>;
  currentUser?: FirebaseUser | null;
  userRole?: 'user' | 'admin' | null;
  openAuthModal?: () => void;
}

const PRESET_ART_IMGS = [
  { id: 'p1', title: 'Mural Pesisir Pelabuhan Ratu', url: 'https://images.unsplash.com/photo-1541963463532-d68292c34b19?auto=format&fit=crop&w=600&h=400&q=80' },
  { id: 'p2', title: 'Sketsa Sunset Pantai Citepus', url: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&h=400&q=80' },
  { id: 'p3', title: 'Kriya Sand Driftwood Craft', url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&h=400&q=80' },
  { id: 'p4', title: 'Instalasi Bambu Kidul', url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&h=400&q=80' },
  { id: 'p5', title: 'Lukisan Kapal Samudra', url: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=600&h=400&q=80' },
];

const MULTI_ROLES = [
  'Sketser Utama', 'Muralis Lapangan', 'Tim Logistik Cat', 'Dokumentasi Kreatif', 'Koordinator Konsumsi'
];

const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80',
  'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&h=150&q=80',
  'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&h=150&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
];

export default function CommunitySection({ posts, setPosts, currentUser, userRole, openAuthModal }: CommunitySectionProps) {
  const [activeGroup, setActiveGroup] = useState<'Semua' | 'Diskusi' | 'Kolaborasi' | 'Workshop' | 'Karya'>('Semua');
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'terbaru' | 'terpopuler'>('terbaru');

  // Form States for drafting
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostGroup, setNewPostGroup] = useState<'Diskusi' | 'Kolaborasi' | 'Workshop' | 'Karya'>('Diskusi');
  const [authorName, setAuthorName] = useState('');
  const [authorField, setAuthorField] = useState('Seni & Pesisir');
  const [selectedAvatar, setSelectedAvatar] = useState(PRESET_AVATARS[0]);

  // Form states depending on category selection
  const [selectedPresetImg, setSelectedPresetImg] = useState('');
  const [customImgUrl, setCustomImgUrl] = useState('');
  const [muralLocation, setMuralLocation] = useState('');
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [workshopTime, setWorkshopTime] = useState('');
  const [workshopFee, setWorkshopFee] = useState('');
  const [workshopQuota, setWorkshopQuota] = useState('');
  const [artworkMedium, setArtworkMedium] = useState('');

  // Critique inputs for works showcase
  const [critiqueRating, setCritiqueRating] = useState<number>(5);
  const [critiqueText, setCritiqueText] = useState<string>('');

  // Interactivity states
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedPostDetail, setSelectedPostDetail] = useState<CommunityPost | null>(null);
  
  const avgRating = selectedPostDetail?.artworkRatings && selectedPostDetail.artworkRatings.length > 0
    ? selectedPostDetail.artworkRatings.reduce((sum, r) => sum + r.score, 0) / selectedPostDetail.artworkRatings.length
    : 0;

  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Local Storage Cache system for persisting self liked threads and assigned roles/bookings
  const [likedPostsCache, setLikedPostsCache] = useState<string[]>([]);
  const [myWorkshopRegistrations, setMyWorkshopRegistrations] = useState<string[]>([]);
  const [myClaimedRoles, setMyClaimedRoles] = useState<{ [postId: string]: string[] }>({}); // maps postId to array of roles

  // Load persistence cache from LocalStorage on mount
  useEffect(() => {
    try {
      const likes = localStorage.getItem('adiksi_forum_likes');
      if (likes) setLikedPostsCache(JSON.parse(likes));

      const enrolls = localStorage.getItem('adiksi_forum_workshops');
      if (enrolls) setMyWorkshopRegistrations(JSON.parse(enrolls));

      const roles = localStorage.getItem('adiksi_forum_roles');
      if (roles) setMyClaimedRoles(JSON.parse(roles));

      // Attempt loading default name from auth or local storage
      const storedName = localStorage.getItem('adiksi_forum_username');
      if (storedName) {
        setAuthorName(storedName);
      } else {
        const user = auth.currentUser;
        if (user?.displayName) {
          setAuthorName(user.displayName);
        }
      }

      const storedField = localStorage.getItem('adiksi_forum_userfield');
      if (storedField) setAuthorField(storedField);

      const storedAvatar = localStorage.getItem('adiksi_forum_useravatar');
      if (storedAvatar) setSelectedAvatar(storedAvatar);
    } catch (e) {
      console.error("Local storage sync error:", e);
    }
  }, []);

  // Listen and sync with logged-in user profile
  useEffect(() => {
    if (currentUser) {
      setAuthorName(currentUser.displayName || currentUser.email?.split('@')[0] || 'Anggota Adiksi');
      if (currentUser.photoURL) {
        setSelectedAvatar(currentUser.photoURL);
      }
    } else {
      setAuthorName('');
    }
  }, [currentUser]);

  // Safe credentials cache writer
  const persistIdentity = (name: string, field: string, avatar: string) => {
    try {
      localStorage.setItem('adiksi_forum_username', name);
      localStorage.setItem('adiksi_forum_userfield', field);
      localStorage.setItem('adiksi_forum_useravatar', avatar);
    } catch (e) {
      console.error(e);
    }
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      triggerToast("Akses Terbatas: Silakan masuk terlebih dahulu untuk membuat gagasan baru.");
      if (openAuthModal) openAuthModal();
      return;
    }

    if (!newPostTitle.trim() || !newPostContent.trim()) {
      triggerToast("Mohon isi judul dan deskripsi gagasan Anda!");
      return;
    }

    setIsSubmitting(true);
    const finalAuthorName = currentUser.displayName || authorName.trim() || 'Kreator Pesisir Anon';
    const finalAuthorField = authorField.trim() || 'Seni & Pesisir';

    // Store identity parameters in localStorage so users don't have to keep writing
    persistIdentity(finalAuthorName, finalAuthorField, selectedAvatar);

    const newPostId = `p-${Date.now()}`;
    const finalImgUrl = (newPostGroup === 'Karya' || newPostGroup === 'Kolaborasi') 
      ? (customImgUrl.trim() || selectedPresetImg || '') 
      : '';

    const newPost: CommunityPost = {
      id: newPostId,
      authorName: finalAuthorName,
      authorUid: currentUser.uid,
      authorField: finalAuthorField,
      authorAvatar: currentUser.photoURL || selectedAvatar,
      title: newPostTitle,
      content: newPostContent,
      group: newPostGroup,
      timestamp: 'Baru saja',
      likes: 0,
      likedByCurrentUser: false,
      comments: [],
      imageUrl: finalImgUrl || undefined,
      muralLocation: newPostGroup === 'Kolaborasi' ? muralLocation : undefined,
      rolesNeeded: newPostGroup === 'Kolaborasi' ? selectedRoles : undefined,
      workshopTime: newPostGroup === 'Workshop' ? workshopTime : undefined,
      workshopFee: newPostGroup === 'Workshop' ? workshopFee : undefined,
      workshopQuota: newPostGroup === 'Workshop' ? workshopQuota : undefined,
      artworkMedium: newPostGroup === 'Karya' ? artworkMedium : undefined,
      registeredParticipants: newPostGroup === 'Workshop' ? [] : undefined,
      collaborativeMembers: newPostGroup === 'Kolaborasi' ? {} : undefined,
      artworkRatings: newPostGroup === 'Karya' ? [] : undefined
    };

    try {
      await setDoc(doc(db, 'posts', newPostId), cleanUndefined(newPost));
      
      // Reset Form State
      setNewPostTitle('');
      setNewPostContent('');
      setMuralLocation('');
      setSelectedRoles([]);
      setWorkshopTime('');
      setWorkshopFee('');
      setWorkshopQuota('');
      setArtworkMedium('');
      setSelectedPresetImg('');
      setCustomImgUrl('');
      setShowCreatePost(false);
      triggerToast("Gagasan baru berhasil disiarkan ke majelis pesisir!");
    } catch (err) {
      console.error(err);
      handleFirestoreError(err, OperationType.CREATE, `posts/${newPostId}`);
      triggerToast("Gagal menerbitkan postingan ke database.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLikePost = async (postId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!currentUser) {
      triggerToast("Akses Terbatas: Silakan masuk terlebih dahulu untuk menyukai postingan ini.");
      if (openAuthModal) openAuthModal();
      return;
    }

    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    let updatedLikesCache = [...likedPostsCache];
    const isAlreadyLiked = likedPostsCache.includes(postId);

    let updatedLikesCount = post.likes || 0;
    if (isAlreadyLiked) {
      updatedLikesCount = Math.max(0, updatedLikesCount - 1);
      updatedLikesCache = updatedLikesCache.filter(id => id !== postId);
    } else {
      updatedLikesCount += 1;
      updatedLikesCache.push(postId);
    }

    // Persist to local storage
    try {
      localStorage.setItem('adiksi_forum_likes', JSON.stringify(updatedLikesCache));
      setLikedPostsCache(updatedLikesCache);
    } catch (err) {
      console.error(err);
    }

    const updatedPost: CommunityPost = {
      ...post,
      likes: updatedLikesCount,
      likedByCurrentUser: !isAlreadyLiked
    };

    // If modal is actively viewing this, sync modal state
    if (selectedPostDetail && selectedPostDetail.id === postId) {
      setSelectedPostDetail(updatedPost);
    }

    try {
      await setDoc(doc(db, 'posts', postId), cleanUndefined(updatedPost));
    } catch (err) {
      console.error(err);
      handleFirestoreError(err, OperationType.UPDATE, `posts/${postId}`);
    }
  };

  const handlePostComment = async (postId: string, e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!currentUser) {
      triggerToast("Akses Terbatas: Silakan masuk terlebih dahulu untuk mengirim komentar.");
      if (openAuthModal) openAuthModal();
      return;
    }

    const text = commentInputs[postId];
    if (!text || !text.trim()) return;

    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    const userDisplayName = currentUser.displayName || authorName.trim() || 'Apresiator Pesisir';
    persistIdentity(userDisplayName, authorField, selectedAvatar);

    const updatedComments = [
      ...(post.comments || []),
      {
        id: `c-${Date.now()}`,
        authorName: userDisplayName,
        authorUid: currentUser.uid,
        content: text.trim(),
        timestamp: 'Baru saja'
      }
    ];

    const updatedPost: CommunityPost = {
      ...post,
      comments: updatedComments
    };

    if (selectedPostDetail && selectedPostDetail.id === postId) {
      setSelectedPostDetail(updatedPost);
    }

    try {
      await setDoc(doc(db, 'posts', postId), cleanUndefined(updatedPost));
      setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
      triggerToast("Komentar berhasil dikirim!");
    } catch (err) {
      console.error(err);
      handleFirestoreError(err, OperationType.UPDATE, `posts/${postId}`);
    }
  };

  // INTERACTIVE ACTION: Enrollment for the educational workshop
  const handleWorkshopEnrollment = async (postId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) {
      triggerToast("Akses Terbatas: Silakan masuk terlebih dahulu untuk mendaftar workshop.");
      if (openAuthModal) openAuthModal();
      return;
    }

    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    const currentNick = currentUser.displayName || authorName.trim() || 'Kreator Anon';
    persistIdentity(currentNick, authorField, selectedAvatar);

    let enrolledList = [...(post.registeredParticipants || [])];
    const hasEnrolled = enrolledList.includes(currentNick);

    let updatedRegistrations = [...myWorkshopRegistrations];

    if (hasEnrolled) {
      // Opt-out
      enrolledList = enrolledList.filter(name => name !== currentNick);
      updatedRegistrations = updatedRegistrations.filter(id => id !== postId);
      triggerToast("Batal mendaftar dari kelas workshop.");
    } else {
      // Opt-in
      const maxQuota = parseInt(post.workshopQuota || '9999', 10);
      if (!isNaN(maxQuota) && enrolledList.length >= maxQuota) {
        triggerToast("Gagal! Kuota workshop ini telah penuh.");
        return;
      }
      enrolledList.push(currentNick);
      updatedRegistrations.push(postId);
      triggerToast("Berhasil reservasi tempat workshop!");
    }

    // Persist Cache
    try {
      localStorage.setItem('adiksi_forum_workshops', JSON.stringify(updatedRegistrations));
      setMyWorkshopRegistrations(updatedRegistrations);
    } catch (err) {
      console.error(err);
    }

    const updatedPost: CommunityPost = {
      ...post,
      registeredParticipants: enrolledList
    };

    if (selectedPostDetail && selectedPostDetail.id === postId) {
      setSelectedPostDetail(updatedPost);
    }

    try {
      await setDoc(doc(db, 'posts', postId), cleanUndefined(updatedPost));
    } catch (err) {
      console.error(err);
      handleFirestoreError(err, OperationType.UPDATE, `posts/${postId}`);
    }
  };

  // INTERACTIVE ACTION: Claim custom roles in mural collaborations
  const handleClaimCollaborativeRole = async (postId: string, roleName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) {
      triggerToast("Akses Terbatas: Silakan masuk terlebih dahulu untuk ikut andil dalam kolaborasi.");
      if (openAuthModal) openAuthModal();
      return;
    }

    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    const currentNick = currentUser.displayName || authorName.trim() || 'Kreator Anon';
    persistIdentity(currentNick, authorField, selectedAvatar);

    const membersMap = { ...(post.collaborativeMembers || {}) };
    const currentClaimant = membersMap[roleName];

    let postClaimedMap = { ...myClaimedRoles };
    if (!postClaimedMap[postId]) postClaimedMap[postId] = [];

    if (currentClaimant === currentNick) {
      // Disclaim/cancel claiming
      delete membersMap[roleName];
      postClaimedMap[postId] = postClaimedMap[postId].filter((r: string) => r !== roleName);
      triggerToast(`Batal mengisi peran ${roleName}.`);
    } else if (currentClaimant) {
      // Occupied by someone else
      triggerToast(`Peran ini sudah diisi oleh ${currentClaimant}.`);
      return;
    } else {
      // Claim vacant role
      membersMap[roleName] = currentNick;
      postClaimedMap[postId].push(roleName);
      triggerToast(`Anda telah berkomitmen mengisi peran ${roleName}!`);
    }

    // Persist to local storage
    try {
      localStorage.setItem('adiksi_forum_roles', JSON.stringify(postClaimedMap));
      setMyClaimedRoles(postClaimedMap);
    } catch (err) {
      console.error(err);
    }

    const updatedPost: CommunityPost = {
      ...post,
      collaborativeMembers: membersMap
    };

    if (selectedPostDetail && selectedPostDetail.id === postId) {
      setSelectedPostDetail(updatedPost);
    }

    try {
      await setDoc(doc(db, 'posts', postId), cleanUndefined(updatedPost));
    } catch (err) {
      console.error(err);
      handleFirestoreError(err, OperationType.UPDATE, `posts/${postId}`);
    }
  };

  // INTERACTIVE ACTION: Submit Critique rating stars for artwork
  const handleSubmitCritiqueRating = async (e: React.FormEvent, postId: string) => {
    e.preventDefault();
    if (!currentUser) {
      triggerToast("Akses Terbatas: Silakan masuk terlebih dahulu untuk memberi masukan ulasan.");
      if (openAuthModal) openAuthModal();
      return;
    }

    if (!critiqueText.trim()) {
      triggerToast("Mohon ketik ulasan kritis/masukan seni Anda!");
      return;
    }

    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    const currentNick = currentUser.displayName || authorName.trim() || 'Kritikus Seni Pantai';
    persistIdentity(currentNick, authorField, selectedAvatar);

    const newCritiqueItem = {
      id: `crit-${Date.now()}`,
      authorName: currentNick,
      authorUid: currentUser.uid,
      score: critiqueRating,
      feedback: critiqueText.trim(),
      timestamp: 'Baru saja'
    };

    const updatedRatings = [...(post.artworkRatings || []), newCritiqueItem];

    const updatedPost: CommunityPost = {
      ...post,
      artworkRatings: updatedRatings
    };

    setSelectedPostDetail(updatedPost);
    setCritiqueText('');
    setCritiqueRating(5);

    try {
      await setDoc(doc(db, 'posts', postId), cleanUndefined(updatedPost));
      triggerToast("Ulasan kuratorial & apresiasi bintang dikirim!");
    } catch (err) {
      console.error(err);
      handleFirestoreError(err, OperationType.UPDATE, `posts/${postId}`);
    }
  };

  const handleDeletePost = async (postId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    if (!currentUser) {
      triggerToast("Akses Terbatas: Silakan masuk terlebih dahulu.");
      return;
    }

    const isAuthorized = post.authorUid === currentUser.uid || userRole === 'admin';
    if (!isAuthorized) {
      triggerToast("Akses Ditolak: Anda tidak memiliki izin untuk menghapus gagasan ini.");
      return;
    }

    if (!window.confirm("Apakah Anda yakin ingin menghapus gagasan diskusi ini secara permanen dari majelis pesisir?")) return;

    try {
      await deleteDoc(doc(db, 'posts', postId));
      triggerToast("Gagasan berhasil dihapus dari server.");
      if (selectedPostDetail && selectedPostDetail.id === postId) {
        setSelectedPostDetail(null);
      }
    } catch (err) {
      console.error(err);
      triggerToast("Tindakan terhambat, gagal menghapus postingan.");
    }
  };

  const toggleRoleSelection = (role: string) => {
    if (selectedRoles.includes(role)) {
      setSelectedRoles(prev => prev.filter(r => r !== role));
    } else {
      setSelectedRoles(prev => [...prev, role]);
    }
  };

  // Sort & Filter functions
  const processedPosts = posts
    .filter((post) => {
      if (activeGroup !== 'Semua' && post.group !== activeGroup) return false;
      
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesTitle = post.title?.toLowerCase().includes(query);
        const matchesContent = post.content?.toLowerCase().includes(query);
        const matchesAuthor = post.authorName?.toLowerCase().includes(query);
        const matchesLoc = post.muralLocation?.toLowerCase().includes(query);
        const matchesMedium = post.artworkMedium?.toLowerCase().includes(query);
        return matchesTitle || matchesContent || matchesAuthor || matchesLoc || matchesMedium;
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'terpopuler') {
        return (b.likes || 0) - (a.likes || 0);
      }
      return b.id.localeCompare(a.id);
    });

  // Calculate stats for sidebar summary
  const totalGagasan = posts.length;
  const activeCollaborations = posts.filter(p => p.group === 'Kolaborasi').length;
  const upcomingWorkshops = posts.filter(p => p.group === 'Workshop').length;
  const totalLikes = posts.reduce((sum, p) => sum + (p.likes || 0), 0);

  // Derive Community Bintang (Creator Highlights Leaderboard)
  const creatorCounts: { [name: string]: { count: number; avatar: string; field: string; score: number } } = {};
  posts.forEach(p => {
    const author = p.authorName;
    if (!creatorCounts[author]) {
      creatorCounts[author] = { count: 0, avatar: p.authorAvatar, field: p.authorField, score: 0 };
    }
    creatorCounts[author].count += 1;
    creatorCounts[author].score += (p.likes || 0) + (p.comments?.length || 0) * 2;
  });

  const communityStars = Object.entries(creatorCounts)
    .map(([name, data]) => ({ name, ...data }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 4);

  if (selectedPostDetail) {
    const detailAvgRating = selectedPostDetail.artworkRatings && selectedPostDetail.artworkRatings.length > 0
      ? selectedPostDetail.artworkRatings.reduce((sum, r) => sum + r.score, 0) / selectedPostDetail.artworkRatings.length
      : 0;

    return (
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -15 }}
        className="space-y-8 py-6 max-w-4xl mx-auto text-white animate-fadeIn"
        id="community-post-fullpage-detail"
      >
        <div className="flex items-center justify-between border-b border-white/5 pb-4">
          <button
            onClick={() => setSelectedPostDetail(null)}
            className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-brand-gold hover:text-brand-charcoal text-xs font-bold rounded-xl transition cursor-pointer"
          >
            ← Kembali ke Forum Komunitas
          </button>
          
          <div className="text-xs font-mono text-gray-500 uppercase tracking-widest">
            Detail Gagasan & Diskusi
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-brand-card/35 p-6 rounded-3xl border border-white/5 space-y-4 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-gold/5 rounded-full filter blur-[40px] pointer-events-none" />
              
              <div className="flex items-center gap-2">
                <span className={`text-[10px] uppercase font-mono font-bold px-3 py-1 rounded-full border ${
                  selectedPostDetail.group === 'Kolaborasi' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/35 animate-pulse' :
                  selectedPostDetail.group === 'Workshop' ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/35' :
                  selectedPostDetail.group === 'Karya' ? 'bg-amber-500/10 text-amber-400 border-amber-400/35' :
                  'bg-white/5 text-gray-300 border-white/10'
                }`}>
                  {selectedPostDetail.group || 'Diskusi'}
                </span>
                <span className="text-[10px] font-mono text-gray-500">ID: {selectedPostDetail.id}</span>
              </div>

              <h2 className="font-serif text-3xl font-black text-white leading-tight tracking-tight">
                {selectedPostDetail.title}
              </h2>

              <div className="flex items-center justify-between p-3 bg-black/40 rounded-xl border border-white/5 gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={selectedPostDetail.authorAvatar}
                    alt={selectedPostDetail.authorName}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-brand-gold/30"
                  />
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-bold text-white uppercase">{selectedPostDetail.authorName}</span>
                      <span className="text-[9px] font-mono bg-brand-gold/10 text-brand-gold px-1.5 py-0.5 rounded border border-brand-gold/20">
                        {selectedPostDetail.authorField}
                      </span>
                    </div>
                    <span className="text-[10px] text-gray-500 font-mono">{selectedPostDetail.timestamp}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/#community?post=${selectedPostDetail.id}`);
                      triggerToast("Tautan forum disalin ke papan klip!");
                    }}
                    className="p-2 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                    title="Bagikan Tautan"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={(e) => handleLikePost(selectedPostDetail.id, e)}
                    className={`flex items-center gap-1 text-xs px-2.5 py-1.5 border rounded-lg transition-all cursor-pointer ${
                      likedPostsCache.includes(selectedPostDetail.id)
                        ? 'bg-rose-500/15 border-rose-500 text-rose-500 font-bold' 
                        : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${likedPostsCache.includes(selectedPostDetail.id) ? 'fill-current' : ''}`} />
                    <span>{selectedPostDetail.likes || 0}</span>
                  </button>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-gray-200 leading-relaxed whitespace-pre-line font-sans pt-2">
                {selectedPostDetail.content}
              </p>

              {selectedPostDetail.imageUrl && (
                <div className="rounded-2xl overflow-hidden border border-white/10 shadow-lg mt-4 max-h-[420px]">
                  <img
                    src={selectedPostDetail.imageUrl}
                    alt="Illustration"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover select-none"
                  />
                </div>
              )}
            </div>

            {selectedPostDetail.group === 'Kolaborasi' && (
              <div className="p-5 bg-slate-900/40 border border-emerald-500/20 rounded-2xl space-y-4 shadow-xl">
                <span className="text-[10px] font-mono text-emerald-400 font-extrabold uppercase tracking-wide block">Roster Tim & Peran Terbuka Mural Pantai</span>
                {selectedPostDetail.muralLocation && (
                  <div className="flex gap-2 text-xs text-white font-sans items-center bg-black/40 p-2.5 rounded-xl border border-white/5">
                    <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Penempatan Tembok: <strong className="text-white underline">{selectedPostDetail.muralLocation}</strong></span>
                  </div>
                )}
                {selectedPostDetail.rolesNeeded && selectedPostDetail.rolesNeeded.length > 0 && (
                  <div className="space-y-2 text-xs">
                    <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block">Daftar Perekrutan Peran (Ambil Peran untuk Join):</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {selectedPostDetail.rolesNeeded.map((r) => {
                        const claimsMap = selectedPostDetail.collaborativeMembers || {};
                        const occupier = claimsMap[r];
                        const standsForMe = occupier === authorName;

                        return (
                          <div key={r} className="p-3 bg-black/60 rounded-xl border border-white/5 flex items-center justify-between text-xs font-sans">
                            <div>
                              <span className="text-white font-bold block leading-tight">{r}</span>
                              <span className={`text-[9px] block ${occupier ? 'text-emerald-400 font-bold' : 'text-gray-500 font-mono'}`}>
                                {occupier ? `📍 Diisi oleh: ${occupier}` : '⏳ Belum ada yang mengambil'}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={(e) => handleClaimCollaborativeRole(selectedPostDetail.id, r, e)}
                              className={`px-3 py-1.5 rounded-lg text-[10px] font-mono font-black border transition-all cursor-pointer ${
                                standsForMe
                                  ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 hover:bg-rose-500/30'
                                  : occupier 
                                    ? 'bg-neutral-900 border-transparent text-gray-700 cursor-not-allowed'
                                    : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/30'
                              }`}
                              disabled={occupier ? !standsForMe : false}
                            >
                              {standsForMe ? 'Cancel' : occupier ? 'Gabung' : 'Gabung'}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {selectedPostDetail.group === 'Workshop' && (
              <div className="p-5 bg-slate-900/40 border border-violet-500/20 rounded-2xl space-y-4 shadow-xl">
                <span className="text-[10px] font-mono text-violet-400 font-extrabold uppercase tracking-wide block">PROGRAM BELAJAR & PENDAFTAR WORKSHOP</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-white">
                  <div className="p-3 bg-black/45 rounded-xl border border-white/5 space-y-1">
                    <span className="text-[9px] font-mono text-gray-500 uppercase block">Rencana Waktu</span>
                    <strong className="text-indigo-400 font-bold flex items-center gap-1 text-xs">
                      <Clock className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span>{selectedPostDetail.workshopTime || 'TBA'}</span>
                    </strong>
                  </div>

                  <div className="p-3 bg-black/45 rounded-xl border border-white/5 space-y-1">
                    <span className="text-[9px] font-mono text-gray-500 uppercase block">Investasi Belajar</span>
                    <strong className="text-indigo-400 font-bold flex items-center gap-1 text-xs">
                      <Tag className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span>{selectedPostDetail.workshopFee || 'Gratis'}</span>
                    </strong>
                  </div>

                  <div className="p-3 bg-black/45 rounded-xl border border-white/5 space-y-1">
                    <span className="text-[9px] font-mono text-gray-500 uppercase block">Sisa Kuota Kursi</span>
                    <strong className="text-indigo-400 font-bold flex items-center gap-1 text-xs">
                      <Users className="w-3.5 h-3.5 text-indigo-405 shrink-0" />
                      <span>{(selectedPostDetail.registeredParticipants || []).length} / {selectedPostDetail.workshopQuota || 'Terbuka'} Slot</span>
                    </strong>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 p-3.5 bg-black/40 rounded-xl border border-white/5">
                  <span className="text-[10px] font-mono text-gray-400 leading-normal max-w-xs">
                    {myWorkshopRegistrations.includes(selectedPostDetail.id)
                      ? "Materi lokakarya eksklusif disimpan. Rekomendasikan ke rekan Anda."
                      : "Gunakan nama penjelajah aktif Anda untuk mengamankan tiket."}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => handleWorkshopEnrollment(selectedPostDetail.id, e)}
                    className={`px-5 py-2.5 rounded-xl text-xs font-mono font-black uppercase tracking-wider transition-all cursor-pointer inline-flex items-center gap-1.5 ${
                      myWorkshopRegistrations.includes(selectedPostDetail.id)
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                        : 'bg-violet-500 text-white hover:bg-violet-400'
                    }`}
                  >
                    {myWorkshopRegistrations.includes(selectedPostDetail.id) ? '✓ Batalkan Reservasi' : 'Booking Kursi Sekarang'}
                  </button>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[9px] font-mono text-gray-400 uppercase tracking-widest block">Daftar Rekan-Rekan yang Terdaftar:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {(selectedPostDetail.registeredParticipants || []).map((p, index) => (
                      <span key={index} className="px-2.5 py-1 bg-violet-500/10 text-violet-400 text-[10px] uppercase font-mono rounded font-bold border border-violet-500/20">
                        👤 {p}
                      </span>
                    ))}
                    {(selectedPostDetail.registeredParticipants || []).length === 0 && (
                      <span className="text-[10px] text-gray-500 italic block">Belum ada rekan yang mendaftar.</span>
                    )}
                  </div>
                </div>
              </div>
            )}

            {selectedPostDetail.group === 'Karya' && (
              <div className="p-5 bg-slate-900/40 border border-brand-gold/20 rounded-2xl space-y-4 shadow-xl">
                <span className="text-[10px] font-mono text-brand-gold font-extrabold uppercase tracking-wide block">
                  Apresiasi Kritik Seni & Evaluasi Kuratorial ({detailAvgRating > 0 ? `Bintang Rata-Rata ${detailAvgRating.toFixed(1)} / 5.0` : 'Belum Ada Rating'})
                </span>
                
                {selectedPostDetail.artworkMedium && (
                  <div className="p-2 px-3 bg-black/40 border border-white/5 text-xs text-brand-gold inline-flex gap-2 rounded-xl">
                    <Palette className="w-3.5 h-3.5 text-brand-gold" />
                    <span>Media Pendukung Konsep: <strong>{selectedPostDetail.artworkMedium}</strong></span>
                  </div>
                )}

                {!currentUser ? (
                  <div className="bg-black/35 p-5 rounded-xl border border-dashed border-white/5 text-center space-y-3">
                    <p className="text-xs text-gray-405 leading-relaxed">
                      Silakan masuk terlebih dahulu menggunakan akun Google atau Tamu Anda untuk memberikan kritik seni & rating bintang kuratorial.
                    </p>
                    <button
                      type="button"
                      onClick={openAuthModal}
                      className="px-4 py-2 bg-brand-gold hover:bg-amber-500 text-brand-charcoal text-[10px] font-black uppercase rounded-lg transition"
                    >
                      Masuk Sekarang
                    </button>
                  </div>
                ) : (
                  <form onSubmit={(e) => handleSubmitCritiqueRating(e, selectedPostDetail.id)} className="space-y-3 bg-black/35 p-3.5 rounded-xl border border-white/5">
                    <div className="flex justify-between items-center flex-wrap gap-2">
                      <span className="text-[10px] font-semibold text-white">Beri Rating Apresiasi / Bintang Anda:</span>
                      <div className="flex gap-1 flex-row">
                        {[1, 2, 3, 4, 5].map((stars) => (
                          <button
                            type="button"
                            key={stars}
                            onClick={() => setCritiqueRating(stars)}
                            className="p-0.5 hover:scale-110 active:scale-90 transition-transform cursor-pointer"
                          >
                            <Star className={`w-5 h-5 ${stars <= critiqueRating ? 'fill-brand-gold text-brand-gold' : 'text-gray-600'}`} />
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        required
                        value={critiqueText}
                        onChange={(e) => setCritiqueText(e.target.value)}
                        placeholder="Tulis ulasan kuratorial kritis kriya driftwood / sketsa ini..."
                        className="flex-grow px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-brand-gold placeholder-gray-500"
                      />
                      <button type="submit" className="px-4 py-2 bg-brand-gold hover:bg-amber-500 text-brand-charcoal font-black rounded-xl text-xs transition-colors flex items-center justify-center cursor-pointer">
                        Kirim
                      </button>
                    </div>
                  </form>
                )}

                <div className="space-y-2.5 max-h-[190px] overflow-y-auto pr-1">
                  {(selectedPostDetail.artworkRatings || []).map((rating, index) => (
                    <div key={rating.id || index} className="p-3 bg-black/55 rounded-xl border border-white/5 text-xs space-y-1">
                      <div className="flex justify-between items-center">
                        <strong className="text-brand-gold font-mono text-[10px]">{rating.authorName}</strong>
                        <div className="flex gap-1 flex-row">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star key={s} className={`w-3 h-3 ${s <= rating.score ? 'fill-brand-gold text-brand-gold' : 'text-gray-700'}`} />
                          ))}
                        </div>
                      </div>
                      <p className="text-gray-300 font-sans leading-normal">{rating.feedback}</p>
                    </div>
                  ))}
                  {(selectedPostDetail.artworkRatings || []).length === 0 && (
                    <span className="text-xs text-gray-500 italic block text-center py-2">Belum ada ulasan kritik kuratorial. Kirim ide kurasimu di atas.</span>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="bg-brand-card/35 p-5 rounded-3xl border border-white/5 space-y-4">
              <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-brand-gold block border-b border-white/5 pb-1">
                Kolom Tanggapan ({selectedPostDetail.comments?.length || 0})
              </span>

              <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                {selectedPostDetail.comments && selectedPostDetail.comments.length > 0 ? (
                  selectedPostDetail.comments.map((comment, index) => (
                    <div 
                      key={comment.id || index} 
                      className="bg-slate-950/75 p-3.5 rounded-2xl border border-white/5 text-xs space-y-1"
                    >
                      <div className="flex justify-between items-center text-[10px]">
                        <strong className="text-brand-gold font-mono tracking-wide">{comment.authorName}</strong>
                        <span className="text-gray-500">{comment.timestamp}</span>
                      </div>
                      <p className="text-gray-300 leading-relaxed font-sans">{comment.content}</p>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 text-gray-500 text-xs italic">
                    Belum ada tanggapan. Salurkan masukan Anda di bawah.
                  </div>
                )}
              </div>

              {!currentUser ? (
                <div className="bg-slate-900/40 border border-white/5 p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 mt-4 text-center sm:text-left">
                  <div>
                    <span className="text-[10px] font-mono text-amber-500 uppercase font-bold tracking-wider block">Mode Pengamat</span>
                    <p className="text-xs text-gray-300 max-w-sm mt-0.5">
                      Masuk dengan akun Google untuk memberi komentar pada diskusi ini secara langsung.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={openAuthModal}
                    className="w-full sm:w-auto px-4 py-2 bg-brand-gold hover:bg-amber-500 text-brand-charcoal text-xs font-black uppercase rounded-xl transition-all cursor-pointer text-nowrap"
                  >
                    Masuk Sekarang
                  </button>
                </div>
              ) : (
                <form 
                  onSubmit={(e) => handlePostComment(selectedPostDetail.id, e)}
                  className="flex gap-2 border-t border-white/5 pt-4"
                >
                  <input
                    type="text"
                    required
                    placeholder={`Komentar sebagai ${currentUser.displayName || 'Anggota'}...`}
                    value={commentInputs[selectedPostDetail.id] || ''}
                    onChange={(e) =>
                      setCommentInputs((prev) => ({ ...prev, [selectedPostDetail.id]: e.target.value }))
                    }
                    className="flex-grow px-3 py-2.5 bg-slate-1000 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-brand-gold/45 placeholder-gray-500"
                  />
                  <button
                    type="submit"
                    className="p-2.5 bg-brand-gold hover:bg-amber-500 text-brand-charcoal font-black rounded-xl text-xs flex items-center justify-center cursor-pointer transition"
                    title="Kirim Masukan"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </div>

            {currentUser && (selectedPostDetail.authorUid === currentUser.uid || userRole === 'admin') && (
              <div className="bg-brand-card/35 p-4 rounded-2xl border border-rose-500/10">
                <button
                  onClick={(e) => {
                    handleDeletePost(selectedPostDetail.id, e);
                    setSelectedPostDetail(null);
                  }}
                  className="w-full px-4 py-2 bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-500/25 text-xs font-mono font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Tarik Postingan Ini</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-8 py-4 relative" id="community-main-container">
      
      {/* Visual Toast Notification Banner */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-slate-900 border border-brand-gold/40 text-brand-gold px-5 py-2.5 rounded-full text-xs font-mono font-bold shadow-2xl flex items-center gap-2"
          >
            <Check className="w-3.5 h-3.5 text-brand-gold animate-pulse" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Grid Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 border-b border-white/5 pb-8">
        <div className="space-y-2">
          <div className="flex items-center gap-2.5">
            <span className="text-xs font-mono text-brand-gold uppercase tracking-wider block bg-brand-gold/15 px-2.5 py-1 rounded border border-brand-gold/25">
              MAJELIS GERAKAN KREATIF PESISIR
            </span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Sistem Forum Komunitas
          </h2>
          <p className="text-xs sm:text-sm text-gray-400 max-w-2xl leading-relaxed">
            Menyatukan nafas pemuda Pelabuhan Ratu. Tanyakan opini kreatif, tawarkan program workshop berbagi ilmu, cetuskan proyek mural pantai kolaboratif bersama, atau promosikan sketsa konsep karya driftwood-mu untuk mendapatkan feedback kuratorial interaktif langsung dari warga.
          </p>
        </div>

        {/* Floating Drafting button */}
        <button
          onClick={() => {
            setShowCreatePost(!showCreatePost);
            if (!showCreatePost) {
              setTimeout(() => {
                document.getElementById('new-post-form')?.scrollIntoView({ behavior: 'smooth' });
              }, 100);
            }
          }}
          className={`px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wide flex items-center gap-2 cursor-pointer transition-all duration-300 shadow-lg ${
            showCreatePost 
              ? 'bg-neutral-800 text-white border border-white/10 hover:bg-neutral-700' 
              : 'bg-brand-gold text-brand-charcoal hover:bg-amber-500 shadow-brand-gold/20 hover:scale-[1.03]'
          }`}
          id="btn-trigger-new-post"
        >
          {showCreatePost ? (
            <>
              <X className="w-4 h-4" /> Batal Buat Ide
            </>
          ) : (
            <>
              <Plus className="w-4 h-4" /> Cetuskan Gagasan Baru
            </>
          )}
        </button>
      </div>

      {/* Forum Stats Topbar widget row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-950/40 p-4 border border-white/5 rounded-2xl shadow-inner">
        <div className="p-3 bg-brand-card/30 rounded-xl border border-white/5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
            <Lightbulb className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <span className="text-[9px] uppercase font-mono text-gray-400 block">Total Gagasan</span>
            <span className="text-sm font-bold text-white block font-mono">{totalGagasan}</span>
          </div>
        </div>

        <div className="p-3 bg-brand-card/30 rounded-xl border border-white/5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
            <Users className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <span className="text-[9px] uppercase font-mono text-gray-400 block">Proyek Mural Komunal</span>
            <span className="text-sm font-bold text-white block font-mono">{activeCollaborations}</span>
          </div>
        </div>

        <div className="p-3 bg-brand-card/30 rounded-xl border border-white/5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-violet-500/10 flex items-center justify-center text-violet-400">
            <BookOpen className="w-5 h-5 text-violet-400" />
          </div>
          <div>
            <span className="text-[9px] uppercase font-mono text-gray-400 block">Hajatan Workshop</span>
            <span className="text-sm font-bold text-white block font-mono">{upcomingWorkshops}</span>
          </div>
        </div>

        <div className="p-3 bg-brand-card/30 rounded-xl border border-white/5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400">
            <Heart className="w-5 h-5 text-rose-400" />
          </div>
          <div>
            <span className="text-[9px] uppercase font-mono text-gray-400 block">Likes Terhimpun</span>
            <span className="text-sm font-bold text-white block font-mono">{totalLikes}</span>
          </div>
        </div>
      </div>

      {/* Accordion / Modal for drafting new discussions */}
      <AnimatePresence>
        {showCreatePost && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form
              onSubmit={handleCreatePost}
              className="p-6 md:p-8 rounded-3xl bg-brand-card border border-brand-gold/30 space-y-6 shadow-2xl relative"
              id="new-post-form"
            >
              {/* Gold light accent decoration */}
              <div className="absolute top-0 right-1/4 w-32 h-32 bg-brand-gold/5 rounded-full filter blur-xl pointer-events-none" />

              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <h3 className="text-xs sm:text-sm font-bold font-mono text-brand-gold uppercase tracking-widest flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-brand-gold" /> 
                  <span>Formulir Menggelar Gagasan Baru</span>
                </h3>
                <span className="text-[9px] font-mono text-gray-400 bg-black/40 px-3 py-1 rounded-full border border-white/5">
                  Tipe Form: <span className="text-brand-gold font-bold uppercase">{newPostGroup}</span>
                </span>
              </div>

              {/* Identity & Category choice */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Gelar / Nama Anda</label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      disabled={!!currentUser}
                      placeholder="Contoh: Fajar Cimaja"
                      value={authorName}
                      onChange={(e) => setAuthorName(e.target.value)}
                      className={`w-full px-3.5 py-2.5 bg-slate-950 border rounded-xl text-xs text-white placeholder-gray-650 focus:outline-none transition-colors ${
                        currentUser 
                          ? 'border-amber-500/20 text-amber-500 bg-slate-950/40 cursor-not-allowed font-bold' 
                          : 'border-white/10 focus:border-brand-gold'
                      }`}
                    />
                    {currentUser && (
                      <span className="absolute right-3 top-2.5 text-[8px] font-mono uppercase bg-amber-500/10 text-brand-gold px-1.5 py-0.5 rounded font-black border border-brand-gold/15">
                        Tautan Akun
                      </span>
                    )}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Keahlian (Contoh: Muralis / Pegiat Kayu)</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Kriya Kayu Hanyut"
                    value={authorField}
                    onChange={(e) => setAuthorField(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-white/10 rounded-xl text-xs text-white placeholder-gray-650 focus:outline-none focus:border-brand-gold transition-colors"
                  />
                </div>

                <div className="space-y-1.5 font-sans">
                  <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Wadah/Kategori Forum</label>
                  <select
                    value={newPostGroup}
                    onChange={(e: any) => setNewPostGroup(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-brand-gold transition-all"
                  >
                    <option value="Diskusi font-sans">💬 Diskusi & Opini (Tanya Opini Bebas)</option>
                    <option value="Kolaborasi font-sans">🎨 Proyek Mural Pantai Kolaboratif (Cari Tim)</option>
                    <option value="Workshop font-sans font-sans">🎓 Program Workshop (Tawarkan Belajar Bersama)</option>
                    <option value="Karya font-sans">🖼️ Showcase Sketsa & Pameran Pesisir</option>
                  </select>
                </div>
              </div>

              {/* Avatar Selector Box */}
              <div className="space-y-2 p-4 bg-slate-950/40 border border-white/5 rounded-2xl">
                <label className="text-[10px] font-mono text-gray-400 uppercase block tracking-wider">
                  Pilih Avatar Karakter Kreatif Anda
                </label>
                <div className="flex gap-3 overflow-x-auto py-1">
                  {PRESET_AVATARS.map((avatarUrl, i) => (
                    <button
                      type="button"
                      key={i}
                      onClick={() => setSelectedAvatar(avatarUrl)}
                      className={`relative w-12 h-12 rounded-full overflow-hidden border-2 transition-transform cursor-pointer shrink-0 ${
                        selectedAvatar === avatarUrl 
                          ? 'border-brand-gold scale-102 scale-105 shadow-lg shadow-brand-gold/15' 
                          : 'border-transparent opacity-60 hover:opacity-100 hover:scale-102'
                      }`}
                    >
                      <img src={avatarUrl} alt={`Avatar ${i}`} className="w-full h-full object-cover" />
                      {selectedAvatar === avatarUrl && (
                        <div className="absolute inset-0 bg-brand-gold/20 flex items-center justify-center">
                          <CheckCircle className="w-5 h-5 text-white drop-shadow-md" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Title & Core body */}
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Judul Gagasan / Nama Program</label>
                  <input
                    type="text"
                    required
                    placeholder="Bikin judul yang menarik, sepeti 'Mural Kemerdekaan Citepus' atau 'Ngobras Kriya Driftwood'..."
                    value={newPostTitle}
                    onChange={(e) => setNewPostTitle(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-950 border border-white/15 rounded-xl text-xs text-white placeholder-gray-650 focus:outline-none focus:border-brand-gold transition-colors font-semibold"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Keterangan / Detil Pesan Utama</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Tulis apa idemu, latar belakangnya apa, target lokasinya, atau kriteria peserta/kolaborator yang diharapkan..."
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-950 border border-white/15 rounded-xl text-xs text-white placeholder-gray-650 focus:outline-none focus:border-brand-gold transition-colors resize-none leading-relaxed"
                  />
                </div>
              </div>

              {/* CUSTOM DYNAMIC SUBFIELDS per group selection */}
              {newPostGroup === 'Kolaborasi' && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-5 bg-slate-950/60 rounded-2xl border border-brand-gold/10 space-y-4 shadow-inner"
                >
                  <div className="flex items-center gap-1.5 text-brand-gold font-mono text-[11px] font-bold">
                    <Palette className="w-4 h-4 text-brand-gold" />
                    <span>SPESIFIKASI MURAL PANTAI KOLABORATIF</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono text-gray-400 uppercase block">Rencana Lokasi Tembok / Lokasi Pantai</label>
                      <input
                        type="text"
                        placeholder="Contoh: Belakang Pos Satgas Citepus, Bidang Tembok 5x3m"
                        value={muralLocation}
                        onChange={(e) => setMuralLocation(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-brand-gold"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <ImageGitHubUploader
                        value={customImgUrl}
                        onChange={setCustomImgUrl}
                        folder="karya"
                        userIdentifier={authorName || 'community'}
                        label="Unggah Berkas Sketsa Mural / Tautan URL"
                        placeholder="Contoh: https://images.unsplash.com/... atau seret berkas"
                      />
                    </div>
                  </div>

                  {/* Multi-role selection */}
                  <div className="space-y-2">
                    <label className="text-[9px] font-mono text-gray-400 uppercase block">Pilih Peran Anggota Tim yang Dibutuhkan</label>
                    <div className="flex flex-wrap gap-2">
                      {MULTI_ROLES.map((role) => {
                        const isSelected = selectedRoles.includes(role);
                        return (
                          <button
                            type="button"
                            key={role}
                            onClick={() => toggleRoleSelection(role)}
                            className={`px-3 py-1.5 rounded-lg text-[10px] font-mono font-bold border transition-all cursor-pointer ${
                              isSelected 
                                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/70 shadow-emerald-500/5' 
                                : 'bg-slate-900 text-gray-500 border-white/10 hover:text-white hover:border-white/20'
                            }`}
                          >
                            {isSelected ? '✓ ' : '+ '} {role}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </motion.div>
              )}

              {newPostGroup === 'Workshop' && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-5 bg-slate-950/60 rounded-2xl border border-brand-gold/10 space-y-4"
                >
                  <div className="flex items-center gap-1.5 text-brand-gold font-mono text-[11px] font-bold">
                    <Clock className="w-4 h-4 text-brand-gold" />
                    <span>INFORMASI ACARA & JALUR EDUKASI</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono text-gray-400 uppercase block">Rencana Waktu Acara</label>
                      <input
                        type="text"
                        placeholder="Contoh: Depan Kios Adiksi, Minggu Jam 15.00"
                        value={workshopTime}
                        onChange={(e) => setWorkshopTime(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-brand-gold"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono text-gray-400 uppercase block">Biaya Investasi / Belajar</label>
                      <input
                        type="text"
                        placeholder="Contoh: Gratis / Rp 15.000 (Cat dasar)"
                        value={workshopFee}
                        onChange={(e) => setWorkshopFee(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-brand-gold"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono text-gray-400 uppercase block">Batas Kuota Peserta</label>
                      <input
                        type="text"
                        placeholder="Contoh: 15 Peserta"
                        value={workshopQuota}
                        onChange={(e) => setWorkshopQuota(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-brand-gold"
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              {newPostGroup === 'Karya' && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-5 bg-slate-950/60 rounded-2xl border border-brand-gold/10 space-y-4"
                >
                  <div className="flex items-center gap-1.5 text-brand-gold font-mono text-[11px] font-bold">
                    <Tag className="w-4 h-4 text-brand-gold" />
                    <span>SPESIFIKASI SHOWCASE PEMERANAN SKETSA</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono text-gray-400 uppercase block">Media Seni yang Digunakan</label>
                      <input
                        type="text"
                        placeholder="Contoh: Kayu Hanyut Resin, Cat Pylox, Acrylic di Kanvas"
                        value={artworkMedium}
                        onChange={(e) => setArtworkMedium(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-brand-gold"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <ImageGitHubUploader
                        value={customImgUrl}
                        onChange={setCustomImgUrl}
                        folder="karya"
                        userIdentifier={authorName || 'community'}
                        label="Unggah Berkas Gambar Karya / Tautan URL"
                        placeholder="Contoh: https://images.unsplash.com/... atau seret berkas"
                      />
                    </div>
                  </div>

                  {/* Preset Selector */}
                  <div className="space-y-2">
                    <label className="text-[9px] font-mono text-gray-400 uppercase block">Pilih Sketsa Pendukung Cepat (Preset Pilihan Unsplash)</label>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                      {PRESET_ART_IMGS.map((preset) => (
                        <div
                          key={preset.id}
                          className={`relative h-20 rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                            selectedPresetImg === preset.url 
                              ? 'border-brand-gold scale-[0.98] shadow-md' 
                              : 'border-transparent hover:border-white/25 hover:scale-102 font-sans'
                          }`}
                          onClick={() => {
                            setSelectedPresetImg(preset.url);
                            setCustomImgUrl(''); 
                          }}
                        >
                          <img src={preset.url} alt={preset.title} className="w-full h-full object-cover brightness-75" />
                          <div className="absolute inset-0 bg-black/40 flex items-end p-1.5">
                            <span className="text-[8px] text-white font-mono block truncate w-full font-bold">{preset.title}</span>
                          </div>
                          {selectedPresetImg === preset.url && (
                            <div className="absolute top-1.5 right-1.5 w-4 h-4 bg-brand-gold text-brand-charcoal flex items-center justify-center rounded-full text-[8px] font-black">
                              ✓
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Action buttons */}
              <div className="flex justify-end items-center gap-3 border-t border-white/5 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreatePost(false)}
                  className="px-4 py-2 hover:bg-white/5 rounded-xl text-xs text-gray-400 hover:text-white transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 bg-brand-gold hover:bg-amber-500 disabled:bg-neutral-800 disabled:text-gray-500 text-brand-charcoal font-black rounded-xl text-xs cursor-pointer flex items-center gap-2 transition-all shadow-md shadow-brand-gold/15"
                >
                  {isSubmitting ? "Mengirim ke Database..." : "Siarkan Gagasan Sekarang"} 
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FILTER PANEL BAR */}
      <div className="bg-slate-950/70 backdrop-blur-md sticky top-[72px] z-30 p-4 rounded-2xl border border-white/5 grid grid-cols-1 md:grid-cols-12 gap-4 items-center shadow-lg shadow-black/35">
        
        {/* Keyword Search */}
        <div className="md:col-span-4 relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Cari gagasan, nama, kayu hanyut, dsb..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-white/10 rounded-xl text-xs text-white placeholder-gray-550 focus:outline-none focus:border-brand-gold/50 transition-all font-medium"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white text-xs font-bold"
            >
              ×
            </button>
          )}
        </div>

        {/* Categories scrollbar matching requested prompt categories */}
        <div className="md:col-span-5 flex gap-1.5 overflow-x-auto scrollbar-none py-1">
          {[
            { id: 'Semua', label: 'Semua Gagasan' },
            { id: 'Diskusi', label: '💬 Tanya Opini' },
            { id: 'Kolaborasi', label: '🎨 Mural Pantai' },
            { id: 'Workshop', label: '🎓 Workshop' },
            { id: 'Karya', label: '🖼️ Sketsa & Pameran' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveGroup(cat.id as any)}
              className={`px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap border transition-all cursor-pointer ${
                activeGroup === cat.id
                  ? 'bg-brand-gold/15 border-brand-gold/30 text-brand-gold font-bold'
                  : 'bg-transparent border-transparent text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Sorter Selector */}
        <div className="md:col-span-3 flex justify-end gap-2 text-xs">
          <Filter className="w-3.5 h-3.5 text-gray-500 self-center" />
          <span className="text-gray-500 font-mono self-center">Urutan:</span>
          <select
            value={sortBy}
            onChange={(e: any) => setSortBy(e.target.value)}
            className="px-3 py-2 bg-slate-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-brand-gold/60 cursor-pointer transition-colors"
          >
            <option value="terbaru">⏰ Gagasan Baru</option>
            <option value="terpopuler">🔥 Terpopuler (Cinta)</option>
          </select>
        </div>
      </div>

      {/* DETAILED DISCUSSION list with sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Sidebar: Community Guild Tips & Community Leaderboard */}
        <div className="lg:col-span-4 space-y-6 lg:sticky lg:top-[160px]">
          
          {/* Identity Info Panel / Settings quick check */}
          <div className="bg-brand-card rounded-2xl border border-white/5 p-5 space-y-4">
            <h4 className="text-xs uppercase font-mono text-brand-gold tracking-widest font-extrabold flex items-center gap-1.5">
              <Users className="w-4 h-4 text-brand-gold" />
              <span>Identitas Penjelajah Anda</span>
            </h4>
            <div className="p-3 bg-slate-950/60 rounded-xl border border-white/5 flex items-center gap-3">
              <img src={selectedAvatar} alt="Identity avatar" className="w-10 h-10 rounded-full object-cover border border-white/10" />
              <div className="min-w-0">
                <span className="text-[10px] text-gray-500 uppercase font-mono block">Nickname Aktif</span>
                <span className="text-xs text-white font-bold block truncate">{authorName || 'Kreator Tamu'}</span>
                <span className="text-[9px] text-brand-gold font-bold block truncate font-mono">{authorField}</span>
              </div>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed font-sans mt-2">
              Bila ingin mengubah nickname, Anda bisa menuliskan nama baru Anda di dalam formulir "Mulai Ide" dan sapaan itu otomatis tersimpan permanen.
            </p>
          </div>

          {/* ACTIVE LEADERS & POPULAR CREATORS BANNER */}
          <div className="bg-brand-card rounded-2xl border border-white/5 p-5 space-y-3">
            <h4 className="text-xs uppercase font-mono text-indigo-400 tracking-widest font-black flex items-center gap-2">
              <Award className="w-4 h-4 text-indigo-450" />
              <span>BINTANG MAJELIS PESISIR</span>
            </h4>
            <span className="text-[10px] uppercase font-mono text-gray-500 block">Kreator Berkontribusi Terpopuler</span>
            
            <div className="space-y-3 pt-1">
              {communityStars.map((creator, id) => (
                <div key={creator.name} className="flex items-center justify-between p-2 bg-slate-950/40 rounded-xl border border-white/5 text-xs">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-[10px] font-mono font-bold text-brand-gold w-3">{id + 1}</span>
                    <img src={creator.avatar} alt={creator.name} className="w-8 h-8 rounded-full object-cover shrink-0 border border-brand-gold/15" />
                    <div className="min-w-0">
                      <strong className="text-white block truncate text-[11px]">{creator.name}</strong>
                      <span className="text-[9px] text-gray-500 block truncate">{creator.field}</span>
                    </div>
                  </div>
                  <span className="text-[10px] bg-brand-gold/10 text-brand-gold px-2 py-0.5 rounded font-bold shrink-0">
                    {creator.count} Ide
                  </span>
                </div>
              ))}
              {communityStars.length === 0 && (
                <div className="text-center py-4 text-gray-500 text-xs">
                  Belum ada kontribusi. Jadilah pionir majelis!
                </div>
              )}
            </div>
          </div>

          {/* Guidelines info */}
          <div className="bg-gradient-to-br from-slate-950 to-brand-card/30 rounded-2xl border border-brand-gold/20 p-5 space-y-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-brand-gold/5 rounded-full filter blur-md" />
            <h5 className="font-serif text-sm font-bold text-white flex items-center gap-1.5">
              <Lightbulb className="w-4 h-4 text-brand-gold" />
              <span>Inkubasi Ide Pantai</span>
            </h5>
            <p className="text-[11px] text-gray-400 leading-normal leading-relaxed">
              Majelis ini dikelola bersama pemuda pesisir Pelabuhan Ratu. Gunakan pilihan filter kategori di atas untuk memilah program kerja riil di lapangan.
            </p>
          </div>
        </div>

        {/* Right Area: POST FEED LIST */}
        <div className="lg:col-span-8 space-y-6" id="discussion-feed">
          
          {processedPosts.map((post) => {
            const isLikedByMe = likedPostsCache.includes(post.id);
            const myRegistered = myWorkshopRegistrations.includes(post.id);
            
            // Average ratings calculation if Karya
            let avgRating = 0;
            if (post.artworkRatings && post.artworkRatings.length > 0) {
              avgRating = post.artworkRatings.reduce((sum, r) => sum + r.score, 0) / post.artworkRatings.length;
            }

            return (
              <div
                key={post.id}
                onClick={() => setSelectedPostDetail(post)}
                className={`bg-brand-card hover:bg-brand-card/90 rounded-3xl border p-6 md:p-8 space-y-5 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-2xl relative group ${
                  post.group === 'Kolaborasi' ? 'border-l-4 border-l-emerald-500 border-white/5 hover:border-emerald-500/30' :
                  post.group === 'Workshop' ? 'border-l-4 border-l-violet-500 border-white/5 hover:border-violet-500/30' :
                  post.group === 'Karya' ? 'border-l-4 border-l-brand-gold border-white/5 hover:border-brand-gold/30' :
                  'border-l-4 border-l-sky-500 border-white/5 hover:border-sky-500/30'
                }`}
              >
                {/* Visual Accent Hover highlight */}
                <div className="absolute inset-0 bg-gradient-to-r from-white/10,000 to-transparent pointer-events-none rounded-3xl" />

                {/* Creator identity block */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.authorAvatar}
                      alt={post.authorName}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full object-cover border border-white/10"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="text-xs font-bold text-white leading-tight">{post.authorName}</h4>
                        <span className="text-[8px] font-mono text-brand-gold uppercase tracking-wider leading-none px-1.5 py-0.5 bg-brand-gold/15 border border-brand-gold/15 rounded">
                          {post.authorField}
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-500 font-mono mt-0.5 block">{post.timestamp}</span>
                    </div>
                  </div>

                  {/* Category Indicator Badge with distinct theme */}
                  <span className={`text-[10px] font-mono font-bold px-3 py-1 rounded-full border flex items-center gap-1 ${
                    post.group === 'Kolaborasi' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/25' :
                    post.group === 'Workshop' ? 'bg-violet-500/10 text-violet-400 border-violet-500/25' :
                    post.group === 'Karya' ? 'bg-amber-500/10 text-brand-gold border-brand-gold/25' :
                    'bg-sky-500/10 text-sky-400 border-sky-500/25'
                  }`}>
                    {post.group === 'Kolaborasi' ? '🎨 Mural Pantai' :
                     post.group === 'Workshop' ? '🎓 Edukasi' :
                     post.group === 'Karya' ? '🖼️ Sketsa Pameran' :
                     '💬 Tanya Opini'}
                  </span>
                </div>

                {/* Post description block */}
                <div className="space-y-2">
                  <h3 className="font-serif text-xl font-bold text-white tracking-tight group-hover:text-brand-gold transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-xs md:text-sm text-gray-300 leading-relaxed line-clamp-3">
                    {post.content}
                  </p>
                </div>

                {/* DYNAMIC COMPONENT: WORKSHOP ENROLLMENT PREVIEW BAR */}
                {post.group === 'Workshop' && (
                  <div className="p-4 bg-slate-1000/60 p-4 border border-white/5 rounded-2xl space-y-3">
                    <div className="flex justify-between items-center text-xs">
                      <div className="flex items-center gap-1.5 text-gray-300">
                        <Clock className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span>Waktu: <strong className="text-white">{post.workshopTime || 'TBA'}</strong></span>
                      </div>
                      <div className="text-brand-gold bg-brand-gold/10 px-2 py-0.5 rounded text-[10px] font-mono border border-brand-gold/25 font-bold">
                        Daftar: {post.workshopFee || 'Gratis'}
                      </div>
                    </div>

                    {/* Registration slots left */}
                    {post.workshopQuota && (
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-[10px] font-mono text-gray-400">
                          <span>Progress Quota Kelas:</span>
                          <span className="text-white font-bold">
                            {(post.registeredParticipants || []).length} / {post.workshopQuota} Diisi
                          </span>
                        </div>
                        {/* Simulated Progress bar */}
                        <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-violet-500 to-indigo-500 transition-all duration-300"
                            style={{ 
                              width: `${Math.min(100, (((post.registeredParticipants || []).length) / parseInt(post.workshopQuota || '1', 10)) * 100)}%` 
                            }} 
                          />
                        </div>
                      </div>
                    )}

                    {/* Trigger Booking button directly from card */}
                    <div className="flex justify-end pt-1">
                      <button
                        onClick={(e) => handleWorkshopEnrollment(post.id, e)}
                        className={`px-4 py-2 rounded-xl text-[10px] font-mono font-black uppercase tracking-wider transition-all cursor-pointer ${
                          myRegistered 
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 hover:bg-rose-500/30' 
                            : 'bg-violet-500 hover:bg-violet-400 text-white shadow-md shadow-violet-500/10'
                        }`}
                      >
                        {myRegistered ? '✓ Terdaftar (Batal)' : '🔗 Booking Slot Kelas'}
                      </button>
                    </div>
                  </div>
                )}

                {/* DYNAMIC COMPONENT: BEACH MURAL COLLABORATION matrix recruiting slots */}
                {post.group === 'Kolaborasi' && (post.muralLocation || post.rolesNeeded) && (
                  <div className="p-4 bg-slate-950/60 p-4 border border-white/5 rounded-2xl space-y-3.5">
                    {post.muralLocation && (
                      <div className="flex items-center gap-2 text-xs text-gray-300 border-b border-white/5 pb-2">
                        <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Penempatan Tembok: <strong className="text-white select-all">{post.muralLocation}</strong></span>
                      </div>
                    )}

                    {post.rolesNeeded && post.rolesNeeded.length > 0 && (
                      <div className="space-y-2">
                        <span className="text-[9px] uppercase font-mono text-emerald-400 font-black block tracking-widest">
                          Matrix Kebutuhan Komposer Kolaborator (Ambil Peran):
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px]">
                          {post.rolesNeeded.slice(0, 4).map((role) => {
                            const isAssigned = post.collaborativeMembers && post.collaborativeMembers[role];
                            const isAssignedByMe = isAssigned === authorName;

                            return (
                              <div key={role} className="p-2 bg-black/35 rounded-xl border border-white/5 flex items-center justify-between">
                                <div className="min-w-0">
                                  <span className="text-white block truncate font-medium">{role}</span>
                                  <span className={`text-[9px] block truncate ${isAssigned ? 'text-emerald-400 font-bold' : 'text-gray-500 font-mono'}`}>
                                    {isAssigned ? `📍 Diisi: ${isAssigned}` : '⏳ Vacant / Kosong'}
                                  </span>
                                </div>
                                <button
                                  onClick={(e) => handleClaimCollaborativeRole(post.id, role, e)}
                                  className={`px-2.5 py-1 rounded text-[9px] font-mono font-black border transition-all cursor-pointer ${
                                    isAssignedByMe
                                      ? 'bg-rose-500/15 text-rose-400 border-rose-500/35'
                                      : isAssigned 
                                        ? 'bg-slate-900 border-transparent text-gray-600 cursor-not-allowed'
                                        : 'bg-emerald-500/15 hover:bg-emerald-500/35 text-emerald-400 border-emerald-500/25'
                                  }`}
                                  disabled={isAssigned ? !isAssignedByMe : false}
                                >
                                  {isAssignedByMe ? 'Batal' : isAssigned ? 'Full' : 'Join'}
                                </button>
                              </div>
                            );
                          })}
                          {post.rolesNeeded.length > 4 && (
                            <div className="sm:col-span-2 text-right">
                              <span className="text-[9px] font-mono text-gray-500 block">+{post.rolesNeeded.length - 4} Peran Lowong Lainnya, Klik tombol Masuk Diskusi</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* DYNAMIC COMPONENT: ART SKETCH RATING RENDERER */}
                {post.group === 'Karya' && (
                  <div className="p-4 bg-slate-950/60 p-4 border border-white/5 rounded-2xl block space-y-2.5">
                    <div className="flex justify-between items-center text-xs">
                      <div className="flex items-center gap-1.5 text-gray-400">
                        <Palette className="w-3.5 h-3.5 text-brand-gold" />
                        <span>Media: <strong className="text-white">{post.artworkMedium || 'Cat Air/Acrylic'}</strong></span>
                      </div>

                      {/* Average score */}
                      <div className="flex items-center gap-1 bg-brand-gold/10 px-2.5 py-1 rounded-xl border border-brand-gold/25">
                        <Star className="w-3.5 h-3.5 fill-brand-gold text-brand-gold" />
                        <span className="text-xs text-brand-gold font-mono font-bold">
                          {avgRating > 0 ? `${avgRating.toFixed(1)} / 5.0` : 'Belum Ada Rating'}
                        </span>
                        <span className="text-[9px] text-gray-500 font-mono font-bold">
                          ({(post.artworkRatings || []).length} Apresiasi)
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Attached concepts layout image preview */}
                {post.imageUrl && (
                  <div className="relative h-44 sm:h-56 rounded-2xl overflow-hidden border border-white/5">
                    <img
                      src={post.imageUrl}
                      alt="Scenic Art Concept Preview"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-[1.015] transition-transform duration-500 brightness-90 border-transparent"
                    />
                    <div className="absolute top-3.5 left-3.5 px-3 py-1 bg-black/60 backdrop-blur-md rounded-xl text-[9px] font-mono text-brand-gold font-bold border border-brand-gold/20">
                      PRATINJAU SKETSA KONSEP
                    </div>
                  </div>
                )}

                {/* Card interaction controls footer */}
                <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-5">
                    
                    {/* Like button with active persisted cache checking */}
                    <button
                      onClick={(e) => handleLikePost(post.id, e)}
                      className={`flex items-center gap-1.5 text-xs cursor-pointer active:scale-95 transition-all p-2 rounded-xl hover:bg-rose-500/5 ${
                        isLikedByMe 
                          ? 'text-rose-500 font-bold bg-rose-500/5 border border-rose-500/15 px-3' 
                          : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      <Heart className={`w-4 h-4 transition-transform ${isLikedByMe ? 'fill-current scale-105' : ''}`} />
                      <span>{post.likes || 0} Apresiasi</span>
                    </button>

                    <div className="flex items-center gap-1.5 text-xs text-gray-400 p-2">
                      <MessageSquare className="w-4 h-4 text-brand-gold" />
                      <span>{post.comments?.length || 0} Tanggapan</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    
                    {/* Delete option if matched active cached username */}
                    {currentUser && (post.authorUid === currentUser.uid || userRole === 'admin') && (
                      <button
                        onClick={(e) => handleDeletePost(post.id, e)}
                        className="p-2.5 bg-slate-1000/20 hover:bg-rose-950 border border-white/5 hover:border-rose-500/20 text-gray-400 hover:text-rose-400 rounded-xl transition-all cursor-pointer"
                        title="Hapus Usulan Ini"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      onClick={() => setSelectedPostDetail(post)}
                      className="px-4.5 py-2.5 bg-slate-950 group-hover:bg-brand-gold/10 border border-white/5 group-hover:border-brand-gold/35 text-white group-hover:text-brand-gold rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all"
                    >
                      <span>Masuk Diskusi</span>
                      <ChevronRight className="w-3.5 h-3.5 transform group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}

          {processedPosts.length === 0 && (
            <div className="text-center py-20 bg-brand-card rounded-3xl border border-white/5 space-y-4">
              <Users className="w-12 h-12 text-gray-650 mx-auto animate-bounce" />
              <div className="space-y-1">
                <p className="text-gray-400 text-sm font-semibold">Gagasan Tidak Ditemukan</p>
                <p className="text-gray-500 text-xs px-4 max-w-sm mx-auto">
                  Belum ada usulan pada wadah "{activeGroup}" yang cocok dengan kata pencarianmu "{searchQuery}". Jadilah yang pertama menyulut diskusinya!
                </p>
              </div>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveGroup('Semua');
                }}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-mono border border-white/10 cursor-pointer"
              >
                Reset Semua Filter Forum
              </button>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
