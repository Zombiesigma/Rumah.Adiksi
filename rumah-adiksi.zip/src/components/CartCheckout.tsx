/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShoppingBag,
  Trash2,
  Lock,
  ChevronRight,
  User,
  Mail,
  MapPin,
  CheckCircle,
  FileText,
  CreditCard,
  QrCode,
  ArrowLeft,
  Coins,
  Printer
} from 'lucide-react';
import { CartItem } from '../types';
import { db } from '../lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';

interface CartCheckoutProps {
  cart: CartItem[];
  setCart: React.Dispatch<React.SetStateAction<CartItem[]>>;
  clearCart: () => void;
  addNotification: (msg: string) => void;
  setActiveTab: (tab: string) => void;
}

type CheckoutStep = 'cart' | 'shipping' | 'payment_trigger' | 'receipt';
type PaymentMethod = 'qris' | 'bank_transfer' | 'e_wallet';

export default function CartCheckout({
  cart,
  setCart,
  clearCart,
  addNotification,
  setActiveTab
}: CartCheckoutProps) {
  const [step, setStep] = useState<CheckoutStep>('cart');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('qris');
  const [fulfillment, setFulfillment] = useState<'pickup' | 'delivery'>('pickup');

  // Customer Contact State
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerTel, setCustomerTel] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');

  // Payment Verification Processing states
  const [isVerifying, setIsVerifying] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [isPaid, setIsPaid] = useState(false);

  // Totals calculations
  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const shippingFee = fulfillment === 'delivery' ? 18000 : 0;
  const total = subtotal + shippingFee;

  const handleQtyChange = (cartItemId: string, amount: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === cartItemId) {
            const newQty = item.quantity + amount;
            return { ...item, quantity: newQty < 1 ? 1 : newQty };
          }
          return item;
        })
    );
  };

  const handleRemove = (cartItemId: string, name: string) => {
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
    addNotification(`"${name}" dihapus dari keranjang.`);
  };

  const handleProceedToShipping = () => {
    if (cart.length === 0) return;
    setStep('shipping');
  };

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail || !customerTel) return;
    if (fulfillment === 'delivery' && !customerAddress) return;

    setOrderId(`RA-${Math.floor(100000 + Math.random() * 900000)}`);
    setStep('payment_trigger');
  };

  const handleVerifyPaymentNow = async () => {
    setIsVerifying(true);
    
    // Deduct stock in Firestore in real-time
    try {
      for (const item of cart) {
        if (item.itemType === 'shop') {
          const productRef = doc(db, 'shopItems', item.itemId);
          const productSnap = await getDoc(productRef);
          if (productSnap.exists()) {
            const productData = productSnap.data();
            const currentStock = productData.stock || 0;
            const newStock = Math.max(0, currentStock - item.quantity);
            await updateDoc(productRef, { stock: newStock });
            console.log(`Deducted stock for ${item.name}: ${currentStock} -> ${newStock}`);
          }
        } else if (item.itemType === 'gallery') {
          const artworkRef = doc(db, 'artworks', item.itemId);
          const artworkSnap = await getDoc(artworkRef);
          if (artworkSnap.exists()) {
            // Mark artwork as sold
            await updateDoc(artworkRef, { isSold: true });
            console.log(`Marked artwork ${item.name} as sold`);
          }
        }
      }
    } catch (err) {
      console.error("Gagal melakukan pengurangan stock realtime di Firestore:", err);
    }

    setTimeout(() => {
      setIsVerifying(false);
      setIsPaid(true);
      setStep('receipt');
      addNotification(`Apresiasi pembayaran LUNAS order #${orderId} sukses diterima! Sukses mendaftarkan transaksi.`);
    }, 2000);
  };

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(val);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 py-4">
      {/* Checkout Navbar Progress indicators */}
      <div className="flex items-center justify-between border-b border-white/5 pb-5">
        <h2 className="font-serif text-3xl font-bold text-white tracking-tight">
          {step === 'receipt' ? 'Nota Bukti Transaksi' : 'Keranjang Belanja & Pembayaran'}
        </h2>

        {/* Progress pills indicator */}
        {step !== 'receipt' && (
          <div className="flex gap-1.5 items-center text-[10px] font-mono text-gray-400">
            <span className={step === 'cart' ? 'text-brand-gold font-bold' : ''}>01 Keranjang</span>
            <ChevronRight className="w-3 h-3 text-gray-700" />
            <span className={step === 'shipping' ? 'text-brand-gold font-bold' : ''}>02 Pengiriman</span>
            <ChevronRight className="w-3 h-3 text-gray-700" />
            <span className={step === 'payment_trigger' ? 'text-brand-gold font-bold' : ''}>03 Pembayaran Secure</span>
          </div>
        )}
      </div>

      {step === 'cart' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Cart items list in left column */}
          <div className="lg:col-span-8 space-y-4">
            {cart.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-4 bg-slate-900/30 border border-white/5 p-4 rounded-xl hover:border-white/10 transition-colors"
                id={`cart-item-${item.id}`}
              >
                <img
                  src={item.imageUrl}
                  alt={item.name}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-xl object-cover bg-slate-950 border border-white/15 flex-shrink-0"
                />

                <div className="flex-grow min-w-0 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1">
                      {item.name}
                    </h4>
                    <button
                      onClick={() => handleRemove(item.id, item.name)}
                      className="text-gray-500 hover:text-rose-500 p-1 cursor-pointer transition-colors"
                      title="Hapus barang"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-[10px] font-mono text-brand-gold">
                    {item.itemType === 'gallery' ? 'KARYA RETRO EXCLUSIF' : 'KEDAI PRODUK'}
                  </p>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs font-bold text-gray-300">
                      {formatRupiah(item.price)}
                    </span>

                    {/* Qty changer buttons */}
                    <div className="flex items-center gap-2.5 bg-slate-950 p-1 rounded-lg border border-white/10">
                      <button
                        onClick={() => handleQtyChange(item.id, -1)}
                        className="w-5 h-5 rounded hover:bg-white/5 text-gray-400 hover:text-white font-mono text-xs cursor-pointer"
                      >
                        -
                      </button>
                      <span className="text-xs font-mono font-bold text-white px-1">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => handleQtyChange(item.id, 1)}
                        className="w-5 h-5 rounded hover:bg-white/5 text-gray-400 hover:text-white font-mono text-xs cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {cart.length === 0 && (
              <div className="text-center py-16 bg-slate-900/10 rounded-2xl border border-dashed border-white/5">
                <ShoppingBag className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <p className="text-gray-400 text-sm">Keranjang belanja Anda masih kosong.</p>
                <div className="pt-4">
                  <button
                    onClick={() => setActiveTab('shop')}
                    className="px-4 py-2 bg-brand-gold hover:bg-brand-gold/90 text-brand-charcoal text-xs font-bold rounded-xl cursor-pointer"
                  >
                    Buka Adiksi Shop sekarang
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Cart Summary right column */}
          <div className="lg:col-span-4 bg-slate-950 rounded-2xl border border-brand-gold/15 p-5 space-y-4">
            <h3 className="text-xs uppercase font-mono font-bold text-white tracking-widest border-b border-white/5 pb-2.5">
              Apresiasi Ringkasan
            </h3>

            <div className="space-y-2 text-xs font-mono text-gray-400">
              <div className="flex justify-between">
                <span>Subtotal Item:</span>
                <span className="text-white">{formatRupiah(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Pilihan Kurir:</span>
                <span className="text-white">Fasilitas Komunitas</span>
              </div>
            </div>

            <div className="border-t border-white/5 pt-3 flex justify-between text-sm">
              <span className="font-semibold text-white">TOTAL APRESIASI:</span>
              <span className="font-bold text-brand-gold text-lg">{formatRupiah(total)}</span>
            </div>

            <button
              onClick={handleProceedToShipping}
              disabled={cart.length === 0}
              className="w-full py-2.5 bg-brand-gold hover:bg-brand-gold/90 disabled:bg-gray-800 disabled:text-gray-500 text-brand-charcoal font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-lg transition-transform"
              id="btn-proceed-checkout"
            >
              <Lock className="w-3.5 h-3.5" /> Lanjutkan ke Pengiriman
            </button>
          </div>
        </div>
      )}

      {step === 'shipping' && (
        <form onSubmit={handleProceedToPayment} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Shipping Form left column */}
          <div className="lg:col-span-8 bg-slate-900/30 rounded-2xl border border-white/5 p-6 space-y-5">
            <h3 className="text-sm font-semibold font-mono text-brand-gold uppercase tracking-widest flex items-center gap-1.5">
              <User className="w-4 h-4" /> Informasi Kontak Pemesan
            </h3>

            {/* Delivery choice selector */}
            <div className="grid grid-cols-2 gap-4">
              <div
                onClick={() => setFulfillment('pickup')}
                className={`p-3.5 rounded-xl border cursor-pointer flex flex-col justify-between h-20 transition-all ${
                  fulfillment === 'pickup'
                    ? 'bg-amber-500/10 border-brand-gold/30 text-brand-gold font-bold'
                    : 'bg-transparent border-white/5 text-gray-400 hover:text-white'
                }`}
              >
                <div className="text-xs font-serif font-bold">Ambil di Kedai Pelabuhan Ratu</div>
                <div className="text-[10px] font-mono font-medium tracking-wide">Gratis seduh di tempat</div>
              </div>

              <div
                onClick={() => setFulfillment('delivery')}
                className={`p-3.5 rounded-xl border cursor-pointer flex flex-col justify-between h-20 transition-all ${
                  fulfillment === 'delivery'
                    ? 'bg-amber-500/10 border-brand-gold/30 text-brand-gold font-bold'
                    : 'bg-transparent border-white/5 text-gray-400 hover:text-white'
                }`}
              >
                <div className="text-xs font-serif font-bold">Kirim ke Alamat Rumah Anda</div>
                <div className="text-[10px] font-mono font-medium tracking-wide">Ongkir Rp 18.000 FLAT</div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-gray-400 uppercase">Nama Lengkap</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">
                    <User className="w-3.5 h-3.5" />
                  </span>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Guntur Fadilah"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-brand-gold"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-gray-400 uppercase">Surel / Email aktif</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">
                    <Mail className="w-3.5 h-3.5" />
                  </span>
                  <input
                    type="email"
                    required
                    placeholder="nama@email.com"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-brand-gold"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-gray-400 uppercase">Nomor WhatsApp / HP</label>
              <input
                type="tel"
                required
                placeholder="081234xxxxxx"
                value={customerTel}
                onChange={(e) => setCustomerTel(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-brand-gold"
              />
            </div>

            {fulfillment === 'delivery' && (
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-gray-400 uppercase">Alamat Lengkap Pengiriman</label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-gray-500">
                    <MapPin className="w-3.5 h-3.5" />
                  </span>
                  <textarea
                    rows={3}
                    required
                    placeholder="Tuliskan nama jalan, RT/RW, Kecamatan, Kota, kode pos..."
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-brand-gold resize-none"
                  />
                </div>
              </div>
            )}

            {/* Back to cart option */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => setStep('cart')}
                className="text-xs font-mono text-gray-500 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Kembali urus keranjang
              </button>
            </div>
          </div>

          {/* Secure Payment details right column */}
          <div className="lg:col-span-4 bg-slate-950 rounded-2xl border border-brand-gold/15 p-5 space-y-4">
            <h3 className="text-xs uppercase font-mono font-bold text-white tracking-widest border-b border-white/5 pb-2.5">
              Metode Pembayaran
            </h3>

            <div className="space-y-2">
              {[
                { id: 'qris', label: 'QRIS Praktis instan', desc: 'Saran e-wallet & m-banking', icon: QrCode },
                { id: 'bank_transfer', label: 'Transfer Virtual Mandiri', desc: 'BCA / Mandiri / BNI', icon: CreditCard },
                { id: 'e_wallet', label: 'GoPay / ShopeePay', desc: 'Dompet digital instan', icon: Coins }
              ].map((m) => (
                <div
                  key={m.id}
                  onClick={() => setPaymentMethod(m.id as PaymentMethod)}
                  className={`p-3 rounded-xl border cursor-pointer flex items-center gap-3 transition-all ${
                    paymentMethod === m.id
                      ? 'bg-amber-500/10 border-brand-gold/40 text-white'
                      : 'bg-transparent border-white/5 text-gray-400 hover:text-white'
                  }`}
                >
                  <m.icon className="w-5 h-5 text-brand-gold flex-shrink-0" />
                  <div>
                    <h5 className="text-xs font-semibold leading-none">{m.label}</h5>
                    <p className="text-[10px] text-gray-500 mt-1 block leading-none">{m.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-white/5 pt-3 font-mono text-xs text-gray-400 space-y-1.5">
              <div className="flex justify-between">
                <span>Total Belanja:</span>
                <span>{formatRupiah(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Ongkos Kirim:</span>
                <span>{formatRupiah(shippingFee)}</span>
              </div>
              <div className="flex justify-between font-bold text-white text-sm pt-1 border-t border-white/5">
                <span>GRAND TOTAL:</span>
                <span className="text-brand-gold">{formatRupiah(total)}</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-brand-gold hover:bg-brand-gold/90 text-brand-charcoal font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-lg hover:scale-101 transition-all"
              id="btn-confirm-shipping-payment"
            >
              Bayar Secure: {formatRupiah(total)} <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>
      )}

      {step === 'payment_trigger' && (
        <div className="bg-slate-900/30 rounded-2xl border border-brand-gold/15 p-6 md:p-8 max-w-lg mx-auto text-center space-y-6">
          <div className="space-y-2">
            <span className="text-xs font-mono text-brand-gold uppercase tracking-widest px-2.5 py-0.5 bg-brand-gold/10 rounded-full border border-brand-gold/25">
              Aman & Enkripsi SSL
            </span>
            <h3 className="font-serif text-xl font-bold text-white">Selesaikan Gerbang Pembayaran</h3>
            <p className="text-xs text-gray-400">
              Silakan lakukan pembayaran sebesar <strong className="text-brand-gold font-mono">{formatRupiah(total)}</strong> untuk nomor pesanan Anda <strong className="text-white font-mono">{orderId}</strong>.
            </p>
          </div>

          <div className="p-4 bg-slate-950 border border-white/5 rounded-2xl inline-block mx-auto">
            {paymentMethod === 'qris' && (
              <div className="space-y-4">
                <span className="text-xs font-mono text-rose-500 font-bold block">PIN QRIS GPN NEGARA REPUBLIK INDONESIA</span>
                {/* Beautiful Mock QR Code layout */}
                <div className="bg-white p-3 rounded-xl inline-block relative overflow-hidden project-qris-container">
                  <div className="w-44 h-44 bg-slate-300 flex flex-wrap p-1 gap-1 items-center justify-center rounded">
                    {/* Art representation of QR code blocks */}
                    {Array.from({ length: 16 }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-9 h-9 rounded-sm ${
                          (i % 3 === 0 || i === 0 || i === 15 || i === 12 || i === 3)
                            ? 'bg-slate-950'
                            : 'bg-white border border-slate-200'
                        }`}
                      />
                    ))}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="bg-white px-2 py-1 rounded border border-slate-300 text-[10px] font-mono font-black text-rose-600">
                        QRIS
                      </div>
                    </div>
                  </div>
                </div>
                <p className="text-[10px] font-mono text-gray-500">Pindai kode QRIS di atas dengan Gopay, OVO, ShopeePay, m-BCA, Mandiri Livin dll.</p>
              </div>
            )}

            {paymentMethod === 'bank_transfer' && (
              <div className="p-4 space-y-3 font-mono text-xs text-left">
                <div className="text-center pb-2 border-b border-white/5">
                  <span className="text-[10px] text-gray-400">BANK MANDIRI PEMBAYARAN KREATOR</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span>Nomor Rekening VA:</span>
                  <span className="font-bold text-white select-all">8807 0812 3456 7890</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span>Atas Nama Beneficiary:</span>
                  <span className="text-brand-gold text-right">RUMAH ADIKSI KREATIF PESISIR</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span>Jumlah Transfer:</span>
                  <span className="font-bold text-white">{formatRupiah(total)}</span>
                </div>
              </div>
            )}

            {paymentMethod === 'e_wallet' && (
              <div className="p-4 space-y-2 text-center">
                <span className="text-xs uppercase font-mono text-brand-gold font-semibold">Tautan Dompet Digital</span>
                <p className="text-xs text-gray-300">Konfirmasi pembayaran dikirim ke nomor WhatsApp Anda.</p>
                <div className="p-2.5 bg-white/5 border border-white/5 rounded-xl text-xs text-white">
                  {customerTel}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4 pt-2">
            <button
              onClick={handleVerifyPaymentNow}
              disabled={isVerifying}
              className="w-full sm:w-64 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-lg mx-auto transition-colors"
              id="btn-verify-secured-payment"
            >
              {isVerifying ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Memverifikasi Pembayaran...
                </>
              ) : (
                'Saya Sudah Melunasi (Konfirmasi)'
              )}
            </button>

            <button
              onClick={() => setStep('shipping')}
              className="text-[11px] font-mono text-gray-500 hover:text-white block mx-auto cursor-pointer"
            >
              Kembali ganti metode
            </button>
          </div>
        </div>
      )}

      {step === 'receipt' && (
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Action header */}
          <div className="flex justify-between items-center no-print">
            <button
              onClick={() => {
                clearCart();
                setStep('cart');
                setActiveTab('beranda');
              }}
              className="px-4 py-2 bg-white/5 border border-white/15 rounded-xl hover:bg-white/10 text-white text-xs font-semibold cursor-pointer flex items-center gap-1 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Beli Lagi / Kembali ke Beranda
            </button>

            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-brand-gold hover:bg-brand-gold/90 text-brand-charcoal text-xs font-bold rounded-xl cursor-pointer flex items-center gap-1 transition-transform"
            >
              <Printer className="w-3.5 h-3.5" /> Cetak Nota PDF / Print
            </button>
          </div>

          {/* Core printable Receipt Canvas */}
          <div
            className="bg-zinc-950 p-6 sm:p-8 rounded-3xl border border-brand-gold/20 shadow-2xl relative space-y-6 overflow-hidden text-white"
            id="billing-receipt-canvas"
          >
            {/* Artistic watermark */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-brand-gold/5 rounded-full filter blur-2xl pointer-events-none" />

            {/* Receipt Ribbon headline */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/10 pb-6">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-mono tracking-widest text-brand-gold">FAKTUR RESMI ADIKSI CREATIVE</span>
                <h3 className="font-serif text-2xl font-bold text-white">RUMAH ADIKSI</h3>
                <p className="text-[10px] text-gray-500 font-mono leading-none">Pesisir Pelabuhan Ratu, Sukabumi, Indonesia</p>
              </div>

              <div className="text-left sm:text-right">
                <div className="inline-flex px-3 py-1 bg-emerald-950 border border-emerald-500/20 rounded-full font-mono text-[10px] font-bold text-emerald-400 uppercase tracking-widest">
                  ✓ DIBAYAR LUNAS (PAID)
                </div>
                <p className="text-[11px] font-mono text-gray-400 mt-1.5 font-bold">Faktur No: {orderId}</p>
              </div>
            </div>

            {/* Purchaser / Fulfillment Meta detail */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono border-b border-white/10 pb-6">
              <div className="space-y-1">
                <span className="text-[10px] text-gray-500 uppercase">IDENTITAS PEMESAN</span>
                <p className="font-bold text-white leading-tight">{customerName}</p>
                <p className="text-gray-400 leading-tight">{customerEmail}</p>
                <p className="text-gray-400 leading-tight">{customerTel}</p>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-gray-500 uppercase">METODE & PENYALURAN</span>
                <p className="font-bold text-brand-gold leading-tight">
                  {fulfillment === 'pickup' ? 'Ambil di Kedai Pelabuhan Ratu' : 'Pengiriman Kurir'}
                </p>
                <p className="text-gray-400 leading-tight uppercase font-semibold">Bayar: {paymentMethod.replace('_', ' ')}</p>
                {fulfillment === 'delivery' && (
                  <p className="text-gray-500 text-[10px] leading-tight line-clamp-1">{customerAddress}</p>
                )}
              </div>
            </div>

            {/* Solid Table of Goods purchased */}
            <div className="space-y-3">
              <span className="text-[10px] font-mono text-gray-500 uppercase block">DAFTAR KARYA & SEDUHAN</span>
              <div className="space-y-2">
                {cart.map((item) => (
                  <div key={item.id} className="flex justify-between items-center text-xs">
                    <div className="space-y-0.5">
                      <span className="font-semibold text-white block">{item.name}</span>
                      <span className="text-[10px] text-gray-500 font-mono block">
                        {item.quantity} x {formatRupiah(item.price)}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-gray-300">
                      {formatRupiah(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Final computation tally */}
            <div className="border-t border-white/10 pt-4 font-mono text-xs space-y-1 text-gray-400">
              <div className="flex justify-between">
                <span>Subtotal Barang:</span>
                <span>{formatRupiah(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Biaya Koridor:</span>
                <span>{formatRupiah(shippingFee)}</span>
              </div>
              <div className="flex justify-between font-bold text-white text-sm pt-2 border-t border-white/10">
                <span>TOTAL SETORAN:</span>
                <span className="text-brand-gold text-base">{formatRupiah(total)}</span>
              </div>
            </div>

            {/* Custom footer signature quote */}
            <div className="text-center pt-3 border-t border-dashed border-white/10">
              <p className="text-[11px] text-gray-400">
                "Setiap karya seni memiliki jiwa, terima kasih telah memfasilitasi mimpi pemuda Pelabuhan Ratu."
              </p>
              <span className="text-[9px] uppercase font-mono tracking-widest text-brand-gold block mt-2">
                RUMAH ADIKSI KREATIF - SUKABUMI SELATAN
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
