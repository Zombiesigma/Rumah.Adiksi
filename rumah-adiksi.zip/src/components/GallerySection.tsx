/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Eye,
  ShoppingBag,
  Info,
  Layers,
  Image,
  Award,
  Music,
  Camera,
  Paintbrush
} from 'lucide-react';
import { GalleryItem } from '../types';

interface GallerySectionProps {
  artworks: GalleryItem[];
  setArtworks: React.Dispatch<React.SetStateAction<GalleryItem[]>>;
  addToCart: (artwork: GalleryItem) => void;
  onExploreArtist: (artistId: string) => void;
}

type FilterType = 'all' | 'painting' | 'music' | 'photography' | 'craft';

export default function GallerySection({ artworks, setArtworks, addToCart, onExploreArtist }: GallerySectionProps) {
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [selectedArtwork, setSelectedArtwork] = useState<GalleryItem | null>(null);

  // Handle live likes
  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setArtworks((prev) =>
      prev.map((art) => {
        if (art.id === id) {
          // Normal toggle (toggle simulation)
          const isLiked = (art as any).userLiked;
          return {
            ...art,
            likes: isLiked ? art.likes - 1 : art.likes + 1,
            userLiked: !isLiked
          } as any;
        }
        return art;
      })
    );
  };

  const filteredArtworks = artworks.filter((art) => {
    if (activeFilter === 'all') return true;
    return art.type === activeFilter;
  });

  const getCategoryIcon = (type: string) => {
    switch (type) {
      case 'painting': return <Paintbrush className="w-3.5 h-3.5" />;
      case 'music': return <Music className="w-3.5 h-3.5" />;
      case 'photography': return <Camera className="w-3.5 h-3.5" />;
      case 'craft': return <Layers className="w-3.5 h-3.5" />;
      default: return <Image className="w-3.5 h-3.5" />;
    }
  };

  const formatRupiah = (val?: number) => {
    if (!val) return 'Free / Donasi';
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(val);
  };

  if (selectedArtwork) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -15 }}
        className="space-y-8 py-6 animate-fadeIn text-white max-w-5xl mx-auto"
        id="artwork-fullpage-detail"
      >
        <div className="flex items-center justify-between border-b border-white/5 pb-4">
          <button
            onClick={() => setSelectedArtwork(null)}
            className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-brand-gold hover:text-brand-charcoal text-xs font-bold rounded-xl transition cursor-pointer"
          >
            ← Kembali ke Galeri
          </button>
          
          <div className="text-xs font-mono text-gray-500 uppercase tracking-widest">
            Karya Seni Terpilih
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 space-y-4">
            <div className="relative bg-slate-950 rounded-2xl overflow-hidden border border-white/5 shadow-2xl">
              <img
                src={selectedArtwork.imageUrl}
                alt={selectedArtwork.title}
                referrerPolicy="no-referrer"
                className="w-full object-contain max-h-[500px] h-auto mx-auto transition-transform duration-700 hover:scale-102"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent pointer-events-none" />
            </div>

            <div className="flex items-start gap-3 p-4 bg-brand-gold/5 rounded-2xl border border-brand-gold/15 text-xs text-gray-450 leading-relaxed">
              <Award className="w-5 h-5 text-brand-gold flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Sertifikasi Keaslian Rumah Adiksi</span>
                Sertifikat orisinalitas digital diterbitkan dan diserahkan secara personal ke setiap penikmat karya binaan kami.
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-6 bg-brand-card/30 p-6 rounded-2xl border border-white/5">
            <div className="space-y-3">
              <span className="text-[10px] text-brand-gold font-mono font-bold uppercase tracking-widest bg-brand-gold/10 px-3 py-1 rounded-md border border-brand-gold/20">
                {selectedArtwork.type}
              </span>
              
              <h3 className="font-serif text-3xl font-bold tracking-tight text-white leading-tight">
                {selectedArtwork.title}
              </h3>
              
              <div className="flex items-center gap-2 text-xs font-sans text-gray-400">
                <span>Seniman :</span>
                <button
                  onClick={() => {
                    onExploreArtist(selectedArtwork.artistId);
                    setSelectedArtwork(null);
                  }}
                  className="text-brand-gold hover:underline font-bold text-sm bg-brand-gold/5 px-2.5 py-1 rounded cursor-pointer animate-pulse"
                >
                  {selectedArtwork.artistName}
                </button>
              </div>
            </div>

            <div className="space-y-2 border-t border-white/5 pt-4">
              <h4 className="text-xs uppercase font-mono text-gray-400 tracking-wider">Filosofi & Kisah Karya :</h4>
              <p className="text-xs text-gray-300 leading-relaxed font-sans font-medium whitespace-pre-wrap">
                {selectedArtwork.description}
              </p>
            </div>

            <div className="flex items-center gap-4 text-xs text-gray-500 font-mono border-t border-white/5 pt-4">
              <span className="flex items-center gap-1.5 bg-white/5 px-2.5 py-1 rounded-lg">
                <Eye className="w-3.5 h-3.5" /> {selectedArtwork.views} views
              </span>
              <span className="flex items-center gap-1.5 bg-rose-500/5 text-rose-400 px-2.5 py-1 rounded-lg">
                <Heart className="w-3.5 h-3.5 fill-current" /> {selectedArtwork.likes} likes
              </span>
            </div>

            <div className="border-t border-white/5 pt-5 flex items-center justify-between gap-4">
              <div>
                <span className="text-[10px] text-gray-500 uppercase font-mono block">Apresiasi Koleksi</span>
                <span className="text-xl font-serif font-black text-brand-gold">
                  {formatRupiah(selectedArtwork.price)}
                </span>
              </div>

              {selectedArtwork.price && !selectedArtwork.isSold ? (
                <button
                  onClick={() => {
                    addToCart(selectedArtwork);
                    setSelectedArtwork(null);
                  }}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-brand-gold hover:bg-white text-brand-charcoal font-black rounded-xl text-xs uppercase tracking-wider transition cursor-pointer"
                  id="btn-buy-art-fullpage"
                >
                  <ShoppingBag className="w-4 h-4" /> Beli Karya
                </button>
              ) : (
                <div className="px-4 py-2.5 bg-white/5 rounded-xl border border-white/10 text-xs text-gray-400 font-bold select-none text-nowrap">
                  {selectedArtwork.isSold ? 'Terjual' : 'Hanya Dipajang'}
                </div>
              )}
            </div>

          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-8 py-4">
      {/* Gallery Header and Explanation */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-white/5 pb-6">
        <div className="space-y-2">
          <span className="text-xs font-mono text-brand-gold uppercase tracking-wider">PRESEVASI SENI PESISIR</span>
          <h2 className="font-serif text-3xl font-bold text-white tracking-tight">Galeri Karya Kreatif</h2>
          <p className="text-xs text-gray-400 max-w-xl">
            Saksikan mahakarya kolaboratif pemuda Pelabuhan Ratu. Setiap pembelian membantu langsung pendanaan studio gratis dan pengembangan bakat di perkampungan nelayan.
          </p>
        </div>

        {/* Categories Tab Pill design */}
        <div className="flex flex-wrap gap-1.5 bg-slate-950/70 p-1 rounded-xl border border-white/5">
          {[
            { id: 'all', label: 'Semua Karya' },
            { id: 'painting', label: 'Lukisan' },
            { id: 'music', label: 'Musik / Audio' },
            { id: 'photography', label: 'Fotografi' },
            { id: 'craft', label: 'Seni Kriya' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id as FilterType)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                activeFilter === tab.id
                  ? 'bg-brand-gold text-brand-charcoal font-semibold shadow-md'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Artworks */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="art-works-grid">
        <AnimatePresence mode="popLayout">
          {filteredArtworks.map((art) => (
            <motion.div
              key={art.id}
              layout
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
              className="group relative flex flex-col justify-between bg-slate-900/40 rounded-2xl border border-white/5 hover:border-brand-gold/30 overflow-hidden shadow-lg hover:shadow-brand-gold/5 transition-all duration-300"
              onClick={() => setSelectedArtwork(art)}
            >
              {/* Product Badge / Sold-Out overlay */}
              <div className="absolute top-3 left-3 z-20 flex gap-1.5 flex-col items-start">
                <span className="flex items-center gap-1 text-[10px] uppercase font-mono font-semibold bg-slate-950/80 text-brand-gold px-2.5 py-1 rounded-full border border-brand-gold/15 shadow-sm">
                  {getCategoryIcon(art.type)} {art.type === 'craft' ? 'kriya' : art.type}
                </span>

                {art.isSold && (
                  <span className="text-[10px] font-mono font-bold uppercase bg-rose-600/90 text-white px-2.5 py-1 rounded-full shadow-md">
                    Karya Terjual
                  </span>
                )}
              </div>

              {/* Like / Love Button */}
              <button
                onClick={(e) => handleLike(art.id, e)}
                className={`absolute top-3 right-3 z-20 p-2 rounded-full cursor-pointer transition-transform active:scale-95 ${
                  (art as any).userLiked
                    ? 'bg-rose-500/10 text-rose-500 border border-rose-500/35'
                    : 'bg-slate-950/80 text-gray-400 hover:text-white border border-white/10'
                }`}
                title="Sukai Karya"
              >
                <Heart className={`w-4 h-4 ${(art as any).userLiked ? 'fill-current' : ''}`} />
              </button>

              {/* Artwork Media Canvas with vibrant zoom animation */}
              <div className="relative aspect-[4/3] overflow-hidden bg-slate-950">
                <img
                  src={art.imageUrl}
                  alt={art.title}
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108 filter contrast-[1.02]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-between p-4 pointer-events-none">
                  <span className="text-xs text-white bg-brand-gold/90 text-brand-charcoal px-2.5 py-1 rounded font-semibold flex items-center gap-1">
                    <Info className="w-3 h-3" /> Klik Untuk Cerita Karya
                  </span>
                </div>
              </div>

              {/* Card Footer detail */}
              <div className="p-5 flex-grow flex flex-col justify-between space-y-4">
                <div className="space-y-1.5">
                  <h3 className="font-serif text-lg font-bold text-white group-hover:text-brand-gold transition-colors line-clamp-1 pointer-events-none">
                    {art.title}
                  </h3>
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-gray-400">Oleh: <strong className="text-white hover:underline cursor-pointer" onClick={(e) => { e.stopPropagation(); onExploreArtist(art.artistId); }}>{art.artistName}</strong></span>
                    <span className="text-gray-500">{art.createdDate}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs text-gray-400">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" /> {art.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className={`w-3.5 h-3.5 ${(art as any).userLiked ? 'text-rose-500 fill-current' : ''}`} /> {art.likes}
                    </span>
                  </div>

                  <div className="text-right">
                    <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest leading-none">Apresiasi Karya</div>
                    <div className="text-sm font-bold text-brand-gold mt-0.5">{formatRupiah(art.price)}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* No artworks fallbacks state */}
      {filteredArtworks.length === 0 && (
        <div className="text-center py-16 bg-slate-900/20 rounded-2xl border border-white/5">
          <p className="text-gray-400">Belum ada karya seni pada kategori ini.</p>
        </div>
      )}

    </div>
  );
}
