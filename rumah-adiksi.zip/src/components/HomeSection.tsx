/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Compass,
  BookOpen,
  Palette,
  Utensils,
  Award,
  Users,
  Heart,
  ArrowRight,
  Coffee,
  ShoppingBag,
  Calendar,
  MessageSquare,
  Plus,
  Star,
  Eye,
  X,
  Clock,
  MapPin,
  Tag
} from 'lucide-react';
import { Talent, GalleryItem, ShopItem } from '../types';
import { INITIAL_SHOP_ITEMS } from '../data';

interface HomeSectionProps {
  talents: Talent[];
  artworks: GalleryItem[];
  shopItems?: ShopItem[];
  setActiveTab: (tab: string) => void;
  onSelectTalent: (talent: Talent) => void;
  addToCart?: (item: ShopItem, qty?: number) => void;
}

export default function HomeSection({
  talents,
  artworks,
  shopItems = [],
  setActiveTab,
  onSelectTalent,
  addToCart
}: HomeSectionProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSlide, setActiveSlide] = useState(0);
  const [showQuickView, setShowQuickView] = useState(false);

  // Filter 3 live curated shop items to display on the Bento side panel
  const featuredProducts = (shopItems && shopItems.length > 0 ? shopItems : INITIAL_SHOP_ITEMS).slice(0, 3);

  // Animated background slide images representing Pelabuhan Ratu and creators
  const [slides, setSlides] = useState<any[]>([
    {
      url: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=1200&q=80',
      title: 'Melahirkan Harapan Baru',
      desc: 'Pelabuhan Ratu bukan hanya tentang laut, tapi segenap jiwa kreatif pemudanya.',
      status: 'Live',
      tag: 'Kolektif Seni Rupa',
      date: '22 Mei - 29 Mei 2026',
      time: '14:00 - 21:00 WIB',
      loc: 'Rumah Adiksi Menara Pesisir, Pelabuhan Ratu',
      summary: 'Sebuah pameran seni rupa kontemporer hasil inkubasi seniman muda pesisir Pelabuhan Ratu. Menghadirkan lukisan cat minyak, instalasi bambu pesisir, dan seni resin yang mengekspresikan dinamika kehidupan nelayan.'
    },
    {
      url: 'https://images.unsplash.com/photo-1541963463532-d68292c34b19?auto=format&fit=crop&w=1200&q=80',
      title: 'Eksplorasi Tanpa Batas',
      desc: 'Seni kriya, lukis, musik, hingga digital bersatu memicu ekonomi kreatif lokal.',
      status: 'Upcoming',
      tag: 'Creative Workshop & Talks',
      date: '02 Juni 2026',
      time: '10:00 - 16:30 WIB',
      loc: 'Creative Lab Room - Lantai 2',
      summary: 'Sesi kriya kerajinan tangan pesisir menggunakan media daur ulang kayu pantai (driftwood) dan sisa jaring nelayan, dipadukan dengan lokakarya branding digital.'
    },
    {
      url: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=1200&q=80',
      title: 'Wadah Sinergi Komunitas',
      desc: 'Menemukan panggilan jiwa melalui kecanduan positif—candu karya seni.',
      status: 'Live',
      tag: 'Acoustic & Poetry Night',
      date: 'Setiap Jumat Malam',
      time: '19:30 - Selesai WIB',
      loc: 'Amfiteater Terbuka Rumah Adiksi',
      summary: 'Merajut jembatan empati melalui sajak dan melodi gitar akustik di bawah bintang-bintang pesisir.'
    }
  ]);

  useEffect(() => {
    if (artworks && artworks.length > 0) {
      // Pick up to 3 random artworks currently in the database
      const shuffled = [...artworks].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, 3);
      const dynamicSlides = selected.map((art) => ({
        url: art.imageUrl,
        title: art.title,
        desc: `Karya orisinal buatan tangan seniman lokal ${art.artistName || 'Rumah Adiksi'}.`,
        status: art.isSold ? 'Terjual' : 'Sedia',
        tag: `Kriya Pesisir: ${art.type.toUpperCase()}`,
        date: art.createdDate || 'Mei 2026',
        time: art.price ? `Rp ${art.price.toLocaleString('id-ID')}` : 'Pajangan Galeri Utama',
        loc: `Kreator: ${art.artistName}`,
        summary: art.description || 'Karya ekspresif luar biasa yang disinkronisasi langsung secara real-time dari mahakarya para pemuda kreatif Pelabuhan Ratu.'
      }));
      setSlides(dynamicSlides);
    }
  }, [artworks]);

  useEffect(() => {
    if (slides.length === 0) return;
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [slides]);

  // HTML5 Interactive Canvas particles representing ocean ripples and glowing spray elements
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 800);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 450);

    const handleResize = () => {
      if (canvas && canvas.parentElement) {
        width = canvas.width = canvas.parentElement.clientWidth;
        height = canvas.height = canvas.parentElement.clientHeight || 450;
      }
    };
    window.addEventListener('resize', handleResize);

    const particleCount = 25;
    const particles: Array<{
      x: number;
      y: number;
      radius: number;
      color: string;
      speedX: number;
      speedY: number;
      alpha: number;
    }> = [];

    const colors = [
      'rgba(245, 158, 11, 0.4)',  // Brand Gold (amber-500)
      'rgba(217, 119, 6, 0.4)',   // Orange Amber
      'rgba(99, 102, 241, 0.25)',  // Coastal Indigo
      'rgba(255, 255, 255, 0.15)'  // White Spray
    ];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 3 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.4 - 0.1,
        alpha: Math.random() * 0.4 + 0.2
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw subtle wave
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.03)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < width; i++) {
        const waveY =
          height / 1.5 +
          Math.sin(i * 0.005 + Date.now() * 0.0008) * 15 +
          Math.cos(i * 0.008 + Date.now() * 0.0004) * 8;
        if (i === 0) ctx.moveTo(i, waveY);
        else ctx.lineTo(i, waveY);
      }
      ctx.stroke();

      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      });

      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <div className="space-y-6 py-2">
      
      {/* Intro Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-5">
        <div>
          <span className="text-[10px] uppercase font-mono tracking-[0.25em] text-brand-gold font-bold flex items-center gap-1.5 mb-1.5">
            <Compass className="w-3.5 h-3.5 text-brand-gold" /> Pelabuhan Ratu Creative Hub
          </span>
          <h2 className="text-3xl font-bold tracking-tight text-white font-serif">
            Kreativitas Pemuda, <span className="text-brand-gold italic">Kecanduan Berkarya</span>
          </h2>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('manifesto')}
            className="px-4 py-2 bg-gradient-to-r from-amber-500/10 to-brand-gold/10 hover:from-amber-500/25 hover:to-brand-gold/25 text-brand-gold border border-brand-gold/30 hover:border-brand-gold text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-brand-gold" />
            <span>Baca Manifesto</span>
          </button>
          <button
            onClick={() => setActiveTab('gallery')}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white border border-white/5 hover:border-white/10 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>Jelajahi Karya Seni</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Bento Grid layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5" id="home-bento-grid-container">
        
        {/* BENTO CARD 1: Featured Creator Slider / Interactive Canvas Showcase */}
        <div
          id="home-bento-grid"
          className="md:col-span-12 lg:col-span-8 bg-brand-card rounded-3xl overflow-hidden relative border border-white/5 min-h-[460px] flex flex-col justify-between shadow-2xl group transition-all duration-300 hover:scale-[1.01] hover:shadow-[0_22px_60px_rgba(245,158,11,0.22)] hover:border-brand-gold/35"
        >
          
          {/* Canvas animation layer behind */}
          <div className="absolute inset-0 pointer-events-none z-0">
            <canvas ref={canvasRef} className="w-full h-full object-cover opacity-60" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent" />
          </div>

          {/* Dynamic sliding images */}
          <div className="absolute inset-0 z-[1] opacity-75">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSlide}
                initial={{ opacity: 0, scale: 1.05 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.4, ease: 'easeInOut' }}
                className="absolute inset-0 w-full h-full"
              >
                <img
                  src={slides[activeSlide].url}
                  alt={slides[activeSlide].title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover mix-blend-luminosity brightness-[0.35] group-hover:scale-105 transition-transform duration-[6s] ease-out"
                />
              </motion.div>
            </AnimatePresence>
            {/* Ambient vignette */}
            <div className="absolute inset-0 bg-gradient-to-tr from-brand-charcoal via-transparent to-transparent" />
          </div>

          {/* Top layout details */}
          <div className="relative z-10 p-6 md:p-8 flex justify-between items-center w-full">
            <span className="px-3 py-1 bg-brand-gold/15 text-brand-gold text-[10px] font-bold font-mono uppercase tracking-wider rounded-md border border-brand-gold/35">
              Sorotan Agenda Utama
            </span>
            
            {/* Dynamic Live / Upcoming Status Indicator + Slide dots in Top Right Area */}
            <div className="flex items-center gap-2.5">
              <div className="flex gap-1.5 mr-1.5">
                {slides.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveSlide(idx);
                    }}
                    className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${activeSlide === idx ? 'w-5 bg-brand-gold' : 'w-1.5 bg-white/20'}`}
                  />
                ))}
              </div>
              <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-widest border transition-all duration-300 ${
                slides[activeSlide].status === 'Live'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/35 animate-pulse'
                  : 'bg-amber-500/10 text-amber-400 border-amber-500/35'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${slides[activeSlide].status === 'Live' ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
                <span>{slides[activeSlide].status}</span>
              </div>
            </div>
          </div>

          {/* Bottom layout detail */}
          <div className="relative z-10 p-6 md:p-8 space-y-4 max-w-xl">
            <div className="space-y-2">
              <span className="text-brand-gold text-xs font-mono tracking-widest uppercase block">Art Exhibition Spotlight</span>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-serif leading-tight tracking-tight">
                {slides[activeSlide].title}
              </h1>
              <p className="text-sm text-gray-300 leading-relaxed max-w-lg">
                {slides[activeSlide].desc}
              </p>
            </div>

            <div className="flex flex-wrap gap-2.5 pt-2">
              <button
                onClick={() => setActiveTab('gallery')}
                className="px-5 py-2.5 bg-brand-gold hover:bg-amber-500 text-brand-charcoal text-xs font-bold uppercase rounded-full tracking-wide transition-all shadow-md shadow-brand-gold/10 hover:scale-105 cursor-pointer"
              >
                Lihat Galeri
              </button>
              <button
                onClick={() => setActiveTab('events')}
                className="px-5 py-2.5 bg-white/10 hover:bg-white/15 backdrop-blur-md text-white border border-white/10 hover:border-white/20 text-xs font-bold uppercase rounded-full tracking-wide transition-all cursor-pointer"
              >
                Reservasi Tiket
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowQuickView(true);
                }}
                className="px-5 py-2.5 bg-neutral-800/80 hover:bg-neutral-700 backdrop-blur-md text-brand-gold border border-brand-gold/20 hover:border-brand-gold/40 text-xs font-bold uppercase rounded-full tracking-wide transition-all cursor-pointer flex items-center gap-1.5 shadow-lg shadow-black/30"
              >
                <Eye className="w-3.5 h-3.5 text-brand-gold animate-pulse" />
                <span>Quick View</span>
              </button>
            </div>
          </div>
        </div>

        {/* BENTO CARD 2: Interactive Adiksi Shop Sidebar Showcase */}
        <div className="md:col-span-12 lg:col-span-4 bg-gradient-to-br from-brand-subcard to-brand-card rounded-3xl p-6 border border-white/5 flex flex-col justify-between shadow-2xl relative">
          <div>
            <div className="flex justify-between items-center mb-4 border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <Utensils className="w-5 h-5 text-brand-gold animate-pulse" />
                <h3 className="text-lg font-bold uppercase tracking-tight text-white font-sans">Adiksi Shop</h3>
              </div>
              <span className="text-[10px] font-mono text-brand-gold tracking-widest uppercase px-2 py-0.5 bg-brand-gold/10 rounded border border-brand-gold/25">
                Otentik
              </span>
            </div>

            <p className="text-[12px] text-gray-400 mb-4 leading-relaxed">
              Seduhan biji kopi dataran tinggi Sukabumi & merchandise orisinal pemberdayaan pemuda.
            </p>

            {/* List of 3 featured products */}
            <div className="space-y-3">
              {featuredProducts.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center gap-3 bg-slate-950/40 p-2.5 rounded-2xl hover:bg-slate-950/70 transition-all border border-white/5 group"
                >
                  <img
                    src={p.imageUrl}
                    alt={p.name}
                    referrerPolicy="no-referrer"
                    className="w-11 h-11 rounded-xl object-cover border border-white/10 group-hover:scale-105 transition-transform"
                  />
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-gray-200 truncate group-hover:text-brand-gold transition-colors">{p.name}</h4>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-gray-400 capitalize font-mono">{p.category}</span>
                      <div className="flex items-center text-[10px] text-amber-500">
                        <Star className="w-2.5 h-2.5 fill-current" />
                        <span className="ml-0.5">{p.rating}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1.5">
                    <span className="text-xs font-black text-white font-mono">
                      Rp {(p.price / 1000).toFixed(0)}k
                    </span>
                    <button
                      onClick={() => addToCart && addToCart(p, 1)}
                      className="p-1 px-2 bg-brand-gold/10 hover:bg-brand-gold text-brand-gold hover:text-brand-charcoal rounded-lg border border-brand-gold/30 hover:border-transparent text-[10px] font-black transition-all flex items-center justify-center gap-1 active:scale-95"
                      title="Tambah ke Keranjang"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Beli</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-white/5">
            <button
              onClick={() => setActiveTab('shop')}
              className="w-full py-3 bg-brand-gold hover:bg-amber-500 text-brand-charcoal text-[11px] font-black uppercase rounded-2xl tracking-widest transition-all shadow-lg shadow-brand-gold/10 flex items-center justify-center gap-2"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Semua Produk Kafe & Merch</span>
            </button>
          </div>
        </div>

        {/* BENTO CARD 3: Talent Directory Hub Selector */}
        <div className="md:col-span-12 lg:col-span-5 bg-brand-card rounded-3xl p-6 border border-white/5 flex flex-col justify-between shadow-2xl min-h-[380px]">
          <div>
            <div className="flex justify-between items-center mb-4 border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold text-white font-sans uppercase tracking-tight">Talents Directory</h3>
              </div>
              <button
                onClick={() => setActiveTab('talents')}
                className="text-[10px] text-gray-400 hover:text-brand-gold uppercase font-mono tracking-wider font-bold transition-colors"
              >
                Lihat Semua
              </button>
            </div>

            <p className="text-[12px] text-gray-400 mb-4 leading-relaxed">
              Direktori pemuda kreatif Pelabuhan Ratu. Klik seniman untuk melihat koleksi karya & kontak sosial mereka.
            </p>

            {/* Grid display of artists */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {talents.slice(0, 4).map((talent) => (
                <div
                  key={talent.id}
                  onClick={() => onSelectTalent(talent)}
                  className="flex items-center gap-3 bg-slate-950/30 p-2.5 rounded-2xl hover:bg-slate-950/70 hover:border-brand-gold/30 transition-all border border-white/5 cursor-pointer group"
                >
                  <img
                    src={talent.avatarUrl}
                    alt={talent.name}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-white/15 group-hover:border-brand-gold"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-gray-200 truncate group-hover:text-brand-gold transition-colors">
                      {talent.name}
                    </p>
                    <p className="text-[10px] text-gray-500 truncate capitalize">
                      {talent.field.split(' ')[0]}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-white/5">
            {talents.slice(0, 1).map((spotlight) => (
              <div key={spotlight.id} className="flex items-center justify-between bg-brand-gold/5 p-3 rounded-2xl border border-brand-gold/10">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                  <span className="text-[10px] uppercase font-mono text-gray-400">Rekomendasi Sorotan:</span>
                  <span className="text-[11px] font-bold text-brand-gold truncate max-w-[120px]">{spotlight.name}</span>
                </div>
                <button
                  onClick={() => onSelectTalent(spotlight)}
                  className="text-[10px] text-brand-gold hover:underline font-bold flex items-center gap-0.5"
                >
                  <span>Lihat Profil</span>
                  <ArrowRight className="w-2.5 h-2.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* BENTO CARD 4: Community dialogue, Event feeds, and latest feedback */}
        <div className="md:col-span-12 lg:col-span-7 bg-brand-card rounded-3xl p-6 border border-white/5 flex flex-col md:flex-row gap-5 shadow-2xl min-h-[380px]">
          
          {/* Left panel of Card 4: Event alert */}
          <div className="flex-1 flex flex-col justify-between border-b md:border-b-0 md:border-r border-white/5 pb-4 md:pb-0 md:pr-5">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-ping" />
                <h4 className="text-xs font-black uppercase text-red-500 tracking-wider font-mono">Event Terdekat</h4>
              </div>

              <div className="space-y-2 mt-5">
                <span className="px-2 py-0.5 bg-red-500/10 text-red-400 text-[10px] font-bold uppercase rounded border border-red-500/20">
                  Tiket Gratis Terbuka
                </span>
                <h3 className="text-lg font-bold text-white leading-snug">Gelar Karya Seni Pesisir 2026</h3>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  Pameran seni terbesar tahunan di Pendopo Pantai Citepus menampilkan instalasi driftwood dan lukisan pantai kolaboratif.
                </p>
                <div className="text-[11px] text-gray-300 font-mono flex items-center gap-1.5 mt-2">
                  <Calendar className="w-3.5 h-3.5 text-brand-gold" />
                  <span>15 Juni • Pendopo Pantai Citepus</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveTab('events')}
              className="w-full mt-4 py-2.5 bg-white/5 hover:bg-white/10 text-white border border-white/15 hover:border-brand-gold/30 rounded-xl text-xs font-semibold text-center transition-all cursor-pointer"
            >
              Buka Jadwal Acara Seni
            </button>
          </div>

          {/* Right panel of Card 4: Forum questions feedback posts */}
          <div className="flex-1 flex flex-col justify-between pt-0 md:pt-0">
            <div>
              <div className="flex items-center gap-2 mb-3 pb-2 border-b border-white/5 justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-indigo-400" />
                  <h4 className="text-xs font-bold uppercase text-gray-400 tracking-wider font-mono">Diskusi Komunitas</h4>
                </div>
                <span className="text-[9px] text-gray-500 font-mono">Live feeds</span>
              </div>

              {/* Little quote elements representing posts inside the forum */}
              <div className="space-y-2.5 mt-5">
                <div className="bg-slate-950/20 p-2.5 rounded-2xl border border-white/5 flex flex-col justify-between">
                  <span className="text-[11px] text-gray-300 font-medium italic line-clamp-2">
                    "Kapan mulai hunting kayu hanyut driftwood lagi di bibir pantai Citepus?"
                  </span>
                  <div className="flex items-center gap-1.5 mt-2 justify-between">
                    <span className="text-[10px] text-indigo-300 font-bold">@siti_ayu_kriya</span>
                    <span className="text-[9px] text-gray-500 font-mono">Baru saja</span>
                  </div>
                </div>

                <div className="bg-slate-950/20 p-2.5 rounded-2xl border border-white/5 flex flex-col justify-between">
                  <span className="text-[11px] text-gray-300 font-medium italic line-clamp-2">
                    "Signature Kopi Arabika Jampang diseduh dengan Gula Aren alami Sukabumi nagih bgt!"
                  </span>
                  <div className="flex items-center gap-1.5 mt-2 justify-between">
                    <span className="text-[10px] text-indigo-300 font-bold">@raka_citepus</span>
                    <span className="text-[9px] text-gray-500 font-mono">1 j yg lalu</span>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveTab('community')}
              className="w-full mt-4 py-2.5 bg-brand-gold/10 hover:bg-brand-gold hover:text-brand-charcoal text-brand-gold border border-brand-gold/20 hover:border-transparent rounded-xl text-xs font-semibold text-center transition-all cursor-pointer"
            >
              Masuk Forum Obrolan
            </button>
          </div>

        </div>

      </div>

      {/* Decorative Brand Impact Statistics Bar */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-4 p-5 rounded-2xl bg-white/[0.01] border border-white/5 mt-3 shadow-inner" id="impact-stats">
        {[
          { icon: Users, val: '24+', label: 'Talenta Lokal Aktif', desc: 'Lukis, musik & kriya' },
          { icon: Palette, val: '80+', label: 'Karya Seni Kreatif', desc: 'Promosi karya pesisir' },
          { icon: Utensils, val: '500+', label: 'Seduhan Sebulan', desc: 'Adiksi Coffee & Matcha' },
          { icon: Award, val: 'Rp20M+', label: 'Kontribusi Ekonomi', desc: 'Langsung ke warga pelukis' }
        ].map((item, idx) => (
          <div key={idx} className="space-y-1 p-2 text-center border-r last:border-r-0 border-white/5">
            <div className="text-xl sm:text-2xl font-black text-brand-gold tracking-tight">{item.val}</div>
            <div className="text-[11px] font-bold text-gray-300 leading-tight block">{item.label}</div>
            <p className="text-[9px] text-gray-500 leading-none block mt-0.5">{item.desc}</p>
          </div>
        ))}
      </section>

      {/* Quick View Featured Event Modal */}
      <AnimatePresence>
        {showQuickView && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ duration: 0.3 }}
              className="bg-brand-card border border-brand-gold/30 rounded-3xl p-6 sm:p-8 max-w-2xl w-full space-y-6 shadow-2xl relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Highlight background glow */}
              <div className="absolute -top-40 -right-40 w-80 h-80 bg-brand-gold/5 rounded-full filter blur-[70px] pointer-events-none" />

              {/* Close Button */}
              <button
                onClick={() => setShowQuickView(false)}
                className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                title="Tutup"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Modal Banner Image */}
              <div className="relative h-48 md:h-64 rounded-2xl overflow-hidden border border-white/5 shadow-inner">
                <img
                  src={slides[activeSlide].url}
                  alt={slides[activeSlide].title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover brightness-50"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                
                {/* Event Tag */}
                <div className="absolute top-4 left-4 flex gap-2">
                  <span className="px-2.5 py-1 bg-brand-gold/20 backdrop-blur-md text-brand-gold text-[10px] font-mono font-black uppercase tracking-wider rounded border border-brand-gold/45">
                    {slides[activeSlide].tag}
                  </span>
                  <span className={`px-2.5 py-1 backdrop-blur-md text-[10px] font-mono font-black uppercase tracking-wider rounded border ${
                    slides[activeSlide].status === 'Live'
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/45 animate-pulse'
                      : 'bg-amber-500/20 text-amber-400 border-amber-500/45'
                  }`}>
                    {slides[activeSlide].status} Action
                  </span>
                </div>

                <div className="absolute bottom-4 left-4 right-4 animate-fade-in">
                  <h3 className="text-xl sm:text-2xl font-serif font-black text-white leading-tight">
                    {slides[activeSlide].title}
                  </h3>
                </div>
              </div>

              {/* Event Metadata Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-950/40 border border-white/5 p-3 rounded-xl flex items-center gap-2.5">
                  <Calendar className="w-4 h-4 text-brand-gold shrink-0" />
                  <div className="min-w-0">
                    <span className="text-[9px] uppercase font-mono text-gray-500 block">Tanggal</span>
                    <span className="text-xs text-white font-medium block truncate">{slides[activeSlide].date}</span>
                  </div>
                </div>

                <div className="bg-slate-950/40 border border-white/5 p-3 rounded-xl flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-brand-gold shrink-0" />
                  <div className="min-w-0">
                    <span className="text-[9px] uppercase font-mono text-gray-500 block">Waktu</span>
                    <span className="text-xs text-white font-medium block truncate">{slides[activeSlide].time}</span>
                  </div>
                </div>

                <div className="bg-slate-950/40 border border-white/5 p-3 rounded-xl flex items-center gap-2.5">
                  <MapPin className="w-4 h-4 text-brand-gold shrink-0" />
                  <div className="min-w-0">
                    <span className="text-[9px] uppercase font-mono text-gray-500 block">Lokasi</span>
                    <span className="text-xs text-white font-medium block truncate">{slides[activeSlide].loc}</span>
                  </div>
                </div>
              </div>

              {/* Event Summary */}
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-brand-gold block border-b border-white/5 pb-1">
                  Ringkasan Agenda & Inkubasi
                </span>
                <p className="text-xs md:text-sm text-gray-300 leading-relaxed font-sans whitespace-pre-line">
                  {slides[activeSlide].summary}
                </p>
              </div>

              {/* Footer CTA Actions */}
              <div className="flex gap-2 justify-end pt-2 border-t border-white/5">
                <button
                  onClick={() => setShowQuickView(false)}
                  className="px-4 py-2 bg-neutral-850 hover:bg-neutral-700 text-white rounded-xl text-xs font-bold uppercase tracking-wide transition-colors cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  onClick={() => {
                    setShowQuickView(false);
                    setActiveTab('events');
                  }}
                  className="px-5 py-2.5 bg-brand-gold hover:bg-amber-500 text-brand-charcoal text-xs font-bold uppercase rounded-xl tracking-wide transition-all shadow-md shadow-brand-gold/10 hover:scale-102 cursor-pointer"
                >
                  Reservasi Tiket
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
