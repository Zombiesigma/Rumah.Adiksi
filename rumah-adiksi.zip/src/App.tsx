/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Palette,
  Users,
  ShoppingBag,
  Bell,
  MessageSquare,
  Coffee,
  Calendar,
  Home,
  CheckCircle,
  Scroll,
  Star,
  Award,
  Menu,
  X,
  LogIn,
  LogOut,
  User as UserIcon,
  Sparkles,
  Compass
} from 'lucide-react';

import {
  INITIAL_TALENTS,
  INITIAL_GALLERY,
  INITIAL_SHOP_ITEMS,
  INITIAL_EVENTS,
  INITIAL_POSTS
} from './data';
import { Talent, GalleryItem, ShopItem, CartItem, CommunityPost, ArtEvent } from './types';
import { COFFEE_JOURNEYS } from './lib/coffeeStories';

// Component imports
import HomeSection from './components/HomeSection';
import GallerySection from './components/GallerySection';
import TalentSection from './components/TalentSection';
import ShopSection from './components/ShopSection';
import CommunitySection from './components/CommunitySection';
import EventsSection from './components/EventsSection';
import CartCheckout from './components/CartCheckout';
import ManifestoSection from './components/ManifestoSection';
import AuthModal from './components/AuthModal';
import AdminSection from './components/AdminSection';
import ProfileSection from './components/ProfileSection';

// Firebase core integration imports
import { auth, db, cleanUndefined } from './lib/firebase';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User, signInAnonymously, updateProfile } from 'firebase/auth';
import { collection, onSnapshot, doc, setDoc, getDoc } from 'firebase/firestore';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('beranda');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [notificationsOpen, setNotificationsOpen] = useState<boolean>(false);

  // Global State Engine
  const [talents, setTalents] = useState<Talent[]>([]);
  const [artworks, setArtworks] = useState<GalleryItem[]>([]);
  const [shopItems, setShopItems] = useState<ShopItem[]>([]);
  const [events, setEvents] = useState<ArtEvent[]>([]);
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [systemAlerts, setSystemAlerts] = useState<any[]>([]);

  // Cart Local Persistence State
  const [cart, setCart] = useState<CartItem[]>([]);

  // Inter-section routing helpers
  const [selectedTalentId, setSelectedTalentId] = useState<string | null>(null);

  // Firebase Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<'user' | 'admin' | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);

  // Auth Fallback and Diagnostics Diagnostics States
  const [authErrorModalOpen, setAuthErrorModalOpen] = useState<boolean>(false);
  const [authErrorMessage, setAuthErrorMessage] = useState<string>('');
  const [tempNickname, setTempNickname] = useState<string>('');
  const [isLoggingInAnonymously, setIsLoggingInAnonymously] = useState<boolean>(false);

  // Notification center lists
  const [notifications, setNotifications] = useState<Array<{ id: string; message: string; timestamp: string }>>([
    {
      id: 'n-init-1',
      message: 'Selamat datang di Rumah Adiksi! Pameran Gelar Karya Pesisir 2026 kini dibuka untuk reservasi tiket gratis.',
      timestamp: '14.00'
    },
    {
      id: 'n-init-2',
      message: 'Cobalah Kopi Arabika Jampang racikan baru pemuda tani binaan Sukabumi di Adiksi Shop!',
      timestamp: 'Kemarin'
    }
  ]);

  const addNotification = (message: string) => {
    const time = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    setNotifications((prev) => [
      { id: `notif-${Date.now()}`, message, timestamp: time },
      ...prev
    ]);
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  // 1. Listen to Authenticated User State Changes and Fetch Roles
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        // Enforce bootstrapped admin by email
        if (user.email === 'gunturfadilah140@gmail.com') {
          setUserRole('admin');
        } else {
          try {
            const userDoc = await getDoc(doc(db, 'users', user.uid));
            if (userDoc.exists()) {
              const data = userDoc.data();
              setUserRole(data.role?.toLowerCase() === 'admin' ? 'admin' : 'user');
            } else {
              const defaultRole = (user.email === 'gunturfadilah140@gmail.com') ? 'admin' : 'user';
              await setDoc(doc(db, 'users', user.uid), cleanUndefined({
                uid: user.uid,
                email: user.email || null,
                displayName: user.displayName || 'Creator Pesisir',
                photoURL: user.photoURL || '',
                role: defaultRole,
                createdAt: new Date().toISOString()
              }));
              setUserRole(defaultRole);
            }
          } catch (e) {
            console.error("Failed fetching user role from Firestore:", e);
            setUserRole('user');
          }
        }
      } else {
        setUserRole(null);
      }
    });
    return () => unsubscribe();
  }, []);

  // 2. Real-time syncing with Firebase Firestore "posts" collection
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'posts'), (snapshot) => {
      if (snapshot.empty) {
        setPosts([]);
      } else {
        const postsList: CommunityPost[] = [];
        snapshot.forEach((snap) => {
          postsList.push(snap.data() as CommunityPost);
        });
        // Sort descending by creation timestamp key or id
        postsList.sort((a, b) => b.id.localeCompare(a.id));
        setPosts(postsList);
      }
    }, (error) => {
      console.warn("Firestore onSnapshot empty or reading default posts fallback:", error.message);
      setPosts([]);
    });
    return () => unsubscribe();
  }, []);

  // 3. Real-time syncing with Firebase Firestore "events" collection
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'events'), (snapshot) => {
      if (snapshot.empty) {
        setEvents([]);
      } else {
        const eventsList: ArtEvent[] = [];
        snapshot.forEach((snap) => {
          eventsList.push(snap.data() as ArtEvent);
        });
        eventsList.sort((a, b) => a.id.localeCompare(b.id));
        setEvents(eventsList);
      }
    }, (error) => {
      console.warn("Firestore onSnapshot empty or reading default events fallback:", error.message);
      setEvents([]);
    });
    return () => unsubscribe();
  }, []);

  // Synchronize system alerts real-time for broadcast
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'system_alerts'), (snapshot) => {
      if (snapshot.empty) {
        setSystemAlerts([]);
      } else {
        const list: any[] = [];
        snapshot.forEach((snap) => {
          const item = snap.data();
          if (item.isActive) {
            list.push({ id: snap.id, ...item });
          }
        });
        setSystemAlerts(list);
      }
    }, (error) => {
      console.warn("Error fetching system alerts:", error.message);
      setSystemAlerts([]);
    });
    return () => unsubscribe();
  }, []);

  // 4. Real-time syncing with Firebase Firestore "artworks" collection
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'artworks'), (snapshot) => {
      if (snapshot.empty) {
        setArtworks([]);
      } else {
        const artworksList: GalleryItem[] = [];
        snapshot.forEach((snap) => {
          artworksList.push(snap.data() as GalleryItem);
        });
        artworksList.sort((a, b) => b.id.localeCompare(a.id));
        setArtworks(artworksList);
      }
    }, (error) => {
      console.warn("Firestore onSnapshot empty or reading default artworks fallback:", error.message);
      setArtworks([]);
    });
    return () => unsubscribe();
  }, []);

  // 5. Real-time syncing with Firebase Firestore "shopItems" collection
  useEffect(() => {
    const seedDefaultShopItems = async () => {
      try {
        console.log("Seeding INITIAL_SHOP_ITEMS to Firestore...");
        for (const item of INITIAL_SHOP_ITEMS) {
          const initialReviews = [
            {
              id: `rev-seed-1-${item.id}`,
              authorName: "Bayu Samudra",
              rating: 5,
              comment: item.category === 'coffee' 
                ? "Kopi Jampang ini aseli enak banget, rasanya sangat kaya akan buah tropis dan cokelat kelapa laut. Sangat cocok dinikmati saat matahari terbit di Pantai Citepus." 
                : item.category === 'matcha' 
                ? "Matcha lattenya legit banget, susunya creamy dan kerasa gurih umami asli Uji Kyoto dipadu manis madu Cisolok!"
                : item.category === 'tea'
                ? "Teh melatinya harum semerbak alami, tidak seperti rasa buatan. Sangat menenangkan diminum sore hari."
                : "Merchandise keren, sablonnya rapih tebal dan desainnya menggambarkan ombak Cimaja yang kental lokal seni!",
              timestamp: new Date(Date.now() - 3600000 * 4).toISOString()
            },
            {
              id: `rev-seed-2-${item.id}`,
              authorName: "Siti Ayu Larasati",
              rating: item.rating >= 4.8 ? 5 : 4,
              comment: item.category === 'coffee'
                ? "Sangat halus di lambung. Metode roasting-nya pas tidak keriangan pahit gosong. Mantap Rumah Adiksi!"
                : item.category === 'matcha'
                ? "Pilihan matcha terbaik bagi pecinta matcha non-dairy latte. Kombinasinya dengan madu liar pas sekali manis lumer."
                : item.category === 'tea'
                ? "Sangat rekomen buat santai, wanginya asli melati segar yang dipetik dari perkebunan warga."
                : "Bahan kaosnya sangat adem dipakai harian di pantai. Sablonannya tidak pecah setelah berkali-kali cuci.",
              timestamp: new Date(Date.now() - 3600000 * 24).toISOString()
            }
          ];
          await setDoc(doc(db, 'shopItems', item.id), cleanUndefined({
            ...item,
            reviews: initialReviews
          }));
        }
        console.log("Seeding shopItems completed!");
      } catch (err: any) {
        console.warn("Failed seeding shopItems: ", err.message);
      }
    };

    const unsubscribe = onSnapshot(collection(db, 'shopItems'), (snapshot) => {
      if (snapshot.empty) {
        setShopItems([]);
        seedDefaultShopItems();
      } else {
        const list: ShopItem[] = [];
        snapshot.forEach((snap) => {
          list.push(snap.data() as ShopItem);
        });
        list.sort((a, b) => a.id.localeCompare(b.id));
        setShopItems(list);
      }
    }, (error) => {
      console.warn("Firestore onSnapshot empty or reading default shopItems fallback:", error.message);
      setShopItems([]);
    });
    return () => unsubscribe();
  }, []);

  // 6. Real-time syncing with Firebase Firestore "talents" collection
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'talents'), (snapshot) => {
      if (snapshot.empty) {
        setTalents([]);
      } else {
        const talentsList: Talent[] = [];
        snapshot.forEach((snap) => {
          talentsList.push(snap.data() as Talent);
        });
        setTalents(talentsList);
      }
    }, (error) => {
      console.warn("Firestore onSnapshot empty or reading default talents fallback:", error.message);
      setTalents([]);
    });
    return () => unsubscribe();
  }, []);

  const handleGoogleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      // Enforce signInWithPopup to overcome sandboxed iFrame redirects safely
      await signInWithPopup(auth, provider);
      addNotification("Berhasil masuk melalui Google.");
    } catch (error: any) {
      console.warn("Authentication popup cancelled or fails:", error);
      const isDomainError = 
        error?.code === 'auth/unauthorized-domain' || 
        (error?.message && error.message.includes('auth/unauthorized-domain'));
      const isNetworkError = 
        error?.code === 'auth/network-request-failed' ||
        (error?.message && error.message.includes('network-request-failed')) ||
        (error?.name && error.name.includes('AuthNetworkRequestFailed'));

      if (isDomainError) {
        setAuthErrorMessage(error.message || 'Firebase: Error (auth/unauthorized-domain).');
        setAuthErrorModalOpen(true);
      } else if (isNetworkError) {
        setAuthErrorMessage('network-request-failed');
        setAuthErrorModalOpen(true);
        console.error("Firebase Auth detected network-request-failed. Showing diagnostic helper.");
      } else {
        addNotification("Aksi masuk dibatalkan atau terkendala koneksi.");
      }
    }
  };

  const handleAnonymousLogin = async (nickname: string) => {
    if (!nickname.trim()) return;
    setIsLoggingInAnonymously(true);
    try {
      const userCredential = await signInAnonymously(auth);
      await updateProfile(userCredential.user, {
        displayName: nickname.trim(),
        photoURL: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80"
      });
      // Force update user state
      if (auth.currentUser) {
        setCurrentUser({ ...auth.currentUser });
      }
      addNotification(`Berhasil masuk sebagai Tamu Kreatif: ${nickname}`);
      setAuthErrorModalOpen(false);
    } catch (err: any) {
      console.error("Anonymous sign in failed:", err);
      const isNetworkError = 
        err?.code === 'auth/network-request-failed' ||
        (err?.message && err.message.includes('network-request-failed'));

      if (err?.code === 'auth/operation-not-allowed') {
        setAuthErrorMessage('operation-not-allowed-anon');
        setAuthErrorModalOpen(true);
      } else if (isNetworkError) {
        setAuthErrorMessage('network-request-failed');
        setAuthErrorModalOpen(true);
      } else {
        addNotification("Aksi masuk sementara terkendala.");
      }
    } finally {
      setIsLoggingInAnonymously(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      addNotification("Aman keluar dari akun Google.");
    } catch (error) {
      console.error("Signout error:", error);
    }
  };

  // Add Shop product to Cart handler
  const handleAddShopToCart = (item: ShopItem, qty = 1) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.itemId === item.id && c.itemType === 'shop');
      if (existing) {
        return prev.map((c) =>
          c.itemId === item.id && c.itemType === 'shop'
            ? { ...c, quantity: c.quantity + qty }
            : c
        );
      }
      return [
        ...prev,
        {
          id: `cart-shop-${item.id}`,
          itemType: 'shop',
          itemId: item.id,
          name: item.name,
          price: item.price,
          imageUrl: item.imageUrl,
          quantity: qty
        }
      ];
    });
    addNotification(`"${item.name}" berhasil ditambahkan ke Keranjang Belanja.`);
  };

  // Add unique Gallery Artwork to Cart handler
  const handleAddArtToCart = (art: GalleryItem) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.itemId === art.id && c.itemType === 'gallery');
      if (existing) return prev; // Artwork is a 1-of-1 exclusive item
      return [
        ...prev,
        {
          id: `cart-art-${art.id}`,
          itemType: 'gallery',
          itemId: art.id,
          name: `Mahakarya: ${art.title}`,
          price: art.price || 0,
          imageUrl: art.imageUrl,
          quantity: 1
        }
      ];
    });
    addNotification(`Mahakarya "${art.title}" dikunci ke Keranjang Belanja Anda!`);
  };

  const handleSelectTalentFromHome = (talent: Talent) => {
    setSelectedTalentId(talent.id);
    setActiveTab('talents');
  };

  const handleExploreArtFromTalent = (art: GalleryItem) => {
    // Force set filter or simply let GallerySection open it
    // Under client flow, we route to gallery to let user purchase
    setActiveTab('gallery');
  };

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Tabs structure metadata
  const navigationItems = [
    { id: 'beranda', label: 'Beranda', icon: Home },
    { id: 'manifesto', label: 'Manifesto', icon: Scroll },
    { id: 'gallery', label: 'Galeri Karya', icon: Palette },
    { id: 'talents', label: 'Direktori Bakat', icon: Users },
    { id: 'shop', label: 'Adiksi Shop', icon: Coffee },
    { id: 'community', label: 'Sistem Komunitas', icon: MessageSquare },
    { id: 'events', label: 'Acara Seni', icon: Calendar },
    { id: 'profile', label: 'Profil Saya', icon: UserIcon }
  ];

  const visibleNavigationItems = [
    ...navigationItems,
    ...(userRole === 'admin' ? [{ id: 'admin', label: 'Panel Admin', icon: Award }] : [])
  ];

  return (
    <div className="min-h-screen bg-brand-charcoal text-slate-100 font-sans relative antialiased flex flex-col justify-between selection:bg-brand-gold/30 selection:text-white">
      {/* Floating system broadcast alerts stack */}
      <div className="fixed top-24 right-4 z-50 space-y-3 pointer-events-none max-w-sm w-full">
        <AnimatePresence>
          {systemAlerts.map((alert) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: 50, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 50, scale: 0.95 }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              className="pointer-events-auto p-4 rounded-2xl border shadow-xl flex gap-3.5 relative overflow-hidden backdrop-blur-md"
              style={{
                background: alert.type === 'alert' ? 'rgba(239, 68, 68, 0.15)' : alert.type === 'warning' ? 'rgba(245, 158, 11, 0.15)' : alert.type === 'promo' ? 'rgba(168, 85, 247, 0.15)' : 'rgba(59, 130, 246, 0.15)',
                borderColor: alert.type === 'alert' ? 'rgba(239, 68, 68, 0.4)' : alert.type === 'warning' ? 'rgba(245, 158, 11, 0.4)' : alert.type === 'promo' ? 'rgba(168, 85, 247, 0.4)' : 'rgba(59, 130, 246, 0.4)',
                color: '#fff'
              }}
            >
              {/* Subtle type indicator bar */}
              <div className="absolute top-0 bottom-0 left-0 w-1.5" style={{
                background: alert.type === 'alert' ? '#ef4444' : alert.type === 'warning' ? '#f59e0b' : alert.type === 'promo' ? '#a855f7' : '#3b82f6'
              }} />
              
              <div className="flex-1 space-y-1 pl-1">
                <span className="text-[9px] font-mono font-bold uppercase tracking-widest block opacity-75">
                  BROADCAST: {alert.type === 'alert' ? 'PENGUMUMAN DARURAT' : alert.type === 'warning' ? 'PERINGATAN' : alert.type === 'promo' ? 'INFO PROMOSI' : 'INFORMASI'}
                </span>
                <p className="text-xs leading-relaxed font-sans font-medium text-white/95">{alert.message}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Visual Ambient Gold Halo Spotlight Glows */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-brand-gold/5 rounded-full filter blur-[120px] pointer-events-none z-0" />
      <div className="absolute bottom-20 right-10 w-[400px] h-[400px] bg-brand-indigo/5 rounded-full filter blur-[100px] pointer-events-none z-0" />

      {/* Professional Top Ticker Banner */}
      <div className="hidden md:block bg-slate-950/95 border-b border-white/5 py-2.5 text-xs text-gray-400 font-mono relative overflow-hidden z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-gray-200 font-black uppercase tracking-wider text-[8px] bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 shadow-sm leading-none flex items-center gap-1">
              <span className="inline-block w-1 h-1 rounded-full bg-emerald-400 animate-ping" />
              SINKRONISASI FIRESTORE
            </span>
            <span className="text-gray-300 font-sans text-[11px] font-medium">Informasi & Transaksi Terkoneksi Secara Real-time</span>
          </div>
          <div className="flex items-center gap-4 text-[10px] text-gray-500">
            <span className="flex items-center gap-1">⏰ Buka Hari Ini: 09:00 - 22:00 WIB</span>
            <span className="text-brand-gold font-bold">📍 Citepus, Pelabuhan Ratu</span>
          </div>
        </div>
      </div>

      {/* Elegant Header Area */}
      <header className="sticky top-0 z-40 bg-brand-card/95 backdrop-blur-xl border-b border-white/10 shadow-2xl transition-all duration-300 no-print">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 md:h-20 flex items-center justify-between gap-2.5 md:gap-4">
          
          {/* Logo Brand Title with Deluxe Styling */}
          <div
            onClick={() => {
              setActiveTab('beranda');
              setNotificationsOpen(false);
            }}
            className="flex items-center gap-2 md:gap-3.5 cursor-pointer group select-none shrink-0"
            id="brand-logo-trigger"
          >
            <div className="relative w-8 h-8 md:w-11 md:h-11 rounded-xl md:rounded-2xl bg-gradient-to-br from-brand-gold via-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-brand-gold/10 group-hover:scale-105 group-hover:shadow-brand-gold/25 transition-all duration-300 border border-white/10">
              <span className="font-serif font-black text-brand-charcoal text-sm md:text-xl tracking-tighter">R</span>
              {/* Beautiful luxury corner star spark */}
              <div className="absolute -top-1 -right-1 p-0.5 rounded-full bg-slate-950 border border-brand-gold/20">
                <Sparkles className="w-2 md:w-2.5 h-2 md:h-2.5 text-brand-gold animate-pulse fill-brand-gold/20" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-serif text-sm md:text-lg font-black tracking-tight text-white group-hover:text-brand-gold transition-colors duration-200">
                  RUMAH ADIKSI
                </span>
                <span className="inline-block w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-brand-gold animate-bounce" />
              </div>
              <span className="hidden sm:block text-[9px] uppercase font-mono tracking-widest text-gray-400 group-hover:text-brand-gold/80 transition-colors duration-200 block">
                PELABUHAN RATU CREATIVE HUB
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-950/40 p-1 rounded-2xl border border-white/5 animate-fadeIn" id="desktop-navigation">
            {visibleNavigationItems.map((nav) => {
              const Icon = nav.icon;
              const isSelected = activeTab === nav.id;
              return (
                <button
                  key={nav.id}
                  onClick={() => {
                    setActiveTab(nav.id);
                    setNotificationsOpen(false);
                    if (nav.id !== 'talents') setSelectedTalentId(null);
                  }}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-gradient-to-b from-brand-gold/20 to-brand-gold/5 text-brand-gold border border-brand-gold/30 shadow-inner'
                      : 'text-gray-400 hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <Icon className={`w-4 h-4 transition-transform duration-300 ${isSelected ? 'scale-110 text-brand-gold' : 'text-gray-400'}`} />
                  <span>{nav.label}</span>
                  
                  {/* Dot highlight for high engagement areas */}
                  {(nav.id === 'shop' || nav.id === 'community') && (
                    <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Header Action Elements */}
          <div className="flex items-center gap-1.5 md:gap-2.5 select-none relative">

            {/* Google Authentication Control - Hidden on Mobile, accessible via Lainnya drawer */}
            {currentUser ? (
              <div className="hidden md:flex items-center gap-2 bg-slate-950/40 border border-white/5 pl-2.5 pr-1 py-1 rounded-2xl">
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.displayName || 'User'}
                    className="w-7 h-7 rounded-xl border border-brand-gold/40 shadow-md shadow-black"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-7 h-7 bg-brand-gold/15 text-brand-gold rounded-xl flex items-center justify-center font-bold text-xs font-mono border border-brand-gold/20">
                    {currentUser.displayName?.charAt(0) || 'U'}
                  </div>
                )}
                <div className="flex flex-col text-left max-w-[90px] mr-1">
                  <span className="text-[10px] font-bold text-gray-200 truncate leading-none">
                    {currentUser.displayName || 'Kreator'}
                  </span>
                  <span className="text-[8px] font-mono text-gray-500 truncate leading-none mt-1">
                    {userRole === 'admin' ? 'Administrator' : 'Anggota'}
                  </span>
                </div>
                {userRole === 'admin' && (
                  <span className="text-[8px] font-mono font-black uppercase text-brand-charcoal bg-brand-gold px-1.5 py-0.5 rounded border border-brand-gold shadow-sm inline-block scale-95 origin-right" title="Administrator">
                    Admin
                  </span>
                )}
                <button
                  onClick={handleLogout}
                  className="p-1.5 px-2 text-[9px] uppercase font-mono text-gray-400 hover:text-rose-400 cursor-pointer transition-colors border-l border-white/5 ml-1 font-bold"
                  id="btn-logout"
                  title="Keluar akun"
                >
                  Keluar
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setAuthModalOpen(true);
                  setNotificationsOpen(false);
                }}
                className="hidden md:flex px-4 py-2.5 bg-gradient-to-r from-brand-gold to-amber-500 hover:from-white hover:to-white text-brand-charcoal font-black rounded-xl text-xs items-center gap-1.5 cursor-pointer shadow-lg shadow-brand-gold/5 transition-all duration-300 font-mono"
                id="btn-login-trigger"
                title="Akses Portal Komunitas"
              >
                <LogIn className="w-3.5 h-3.5" /> <span>Masuk</span>
              </button>
            )}

            {/* REAL-TIME NOTIFICATION HUB POP-OVER */}
            <div className="relative">
              <button
                onClick={() => {
                  setNotificationsOpen(!notificationsOpen);
                }}
                className={`p-2 md:p-2.5 rounded-lg md:rounded-xl border relative transition-all duration-300 cursor-pointer ${
                  notificationsOpen
                    ? 'bg-brand-gold/10 text-brand-gold border-brand-gold/50'
                    : 'bg-white/5 text-gray-300 hover:text-white border-white/5 hover:border-white/10'
                }`}
                id="header-notif-bell"
                title="Log Notifikasi Real-time"
              >
                <Bell className={`w-4 h-4 md:w-5 md:h-5 ${notifications.length > 0 && !notificationsOpen ? 'animate-bounce' : ''}`} />
                
                {/* Dynamic badge with pulse */}
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border border-brand-charcoal ring-1 ring-rose-500/50 animate-pulse" />
                )}
              </button>

              {/* Dropdown container */}
              <AnimatePresence>
                {notificationsOpen && (
                  <>
                    {/* Invisible backdrop to close dropdown */}
                    <div
                      className="fixed inset-0 z-40 cursor-default"
                      onClick={() => setNotificationsOpen(false)}
                    />
                    
                    <motion.div
                      initial={{ opacity: 0, y: 15, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 15, scale: 0.95 }}
                      transition={{ duration: 0.2, ease: 'easeOut' }}
                      className="absolute right-0 mt-3 w-80 sm:w-[24rem] bg-brand-card/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl z-50 overflow-hidden font-sans no-print"
                    >
                      <div className="p-4 bg-slate-950 border-b border-white/5 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Bell className="w-4 h-4 text-brand-gold animate-pulse" />
                          <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">Log Notifikasi ({notifications.length})</span>
                        </div>
                        {notifications.length > 0 && (
                          <button
                            onClick={() => {
                              clearNotifications();
                              addNotification("Log notifikasi berhasil dibersihkan.");
                            }}
                            className="text-[9px] uppercase font-mono font-bold text-gray-500 hover:text-brand-gold transition-colors cursor-pointer"
                          >
                            Hapus Semua
                          </button>
                        )}
                      </div>

                      {/* Scrollable Feed */}
                      <div className="max-h-[300px] overflow-y-auto divide-y divide-white/5">
                        {notifications.length === 0 ? (
                          <div className="p-8 text-center text-gray-500 space-y-2">
                            <Compass className="w-6 h-6 mx-auto text-gray-700 animate-spin" style={{ animationDuration: '6s' }} />
                            <p className="text-xs font-bold">Tidak ada notifikasi aktif</p>
                            <p className="text-[10px] text-gray-600 max-w-[200px] mx-auto leading-normal">
                              Aktivitas real-time seperti ulasan atau booking tiket akan meluncur di sini.
                            </p>
                          </div>
                        ) : (
                          notifications.map((notif) => (
                            <div key={notif.id} className="p-3.5 hover:bg-white/5 transition-colors flex items-start gap-3">
                              <div className="w-2 h-2 rounded-full bg-brand-gold shrink-0 mt-1.5" />
                              <div className="flex-1 space-y-1">
                                <p className="text-[11px] leading-relaxed text-gray-300 font-medium">
                                  {notif.message}
                                </p>
                                <span className="text-[8px] font-mono text-gray-500 block">
                                  ⌛ {notif.timestamp}
                                </span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>

                      <div className="p-2.5 bg-slate-950/80 border-t border-white/5 text-center">
                        <span className="text-[8px] uppercase tracking-widest font-mono text-gray-600">
                          Rantai Informasi Terbuka Rumah Adiksi
                        </span>
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            {/* Live Shopping Cart Hub Trigger */}
            <button
              onClick={() => {
                setActiveTab('cart');
                setNotificationsOpen(false);
              }}
              className={`p-2 md:p-2.5 rounded-lg md:rounded-xl border relative transition-all duration-300 cursor-pointer ${
                activeTab === 'cart'
                  ? 'bg-brand-gold text-brand-charcoal border-brand-gold shadow-lg shadow-brand-gold/10'
                  : 'bg-white/5 text-gray-300 hover:text-white border-white/5 hover:border-white/10'
              }`}
              id="header-cart-icon"
              title="Keranjang belanjaan"
            >
              <ShoppingBag className="w-4 h-4 md:w-5 md:h-5" />
              
              {/* Dynamic bounce badge wrapper */}
              <AnimatePresence>
                {cartCount > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-amber-500 font-mono text-[9px] font-black text-brand-charcoal rounded-full flex items-center justify-center border border-brand-charcoal shadow-md"
                  >
                    {cartCount}
                  </motion.span>
                )}
              </AnimatePresence>
            </button>

          </div>
        </div>
      </header>

      {/* Main Container Layout */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-32 lg:pb-8 flex-grow w-full z-10 relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
          >
            {activeTab === 'beranda' && (
              <HomeSection
                talents={talents}
                artworks={artworks}
                shopItems={shopItems}
                setActiveTab={setActiveTab}
                onSelectTalent={handleSelectTalentFromHome}
                addToCart={handleAddShopToCart}
              />
            )}

            {activeTab === 'manifesto' && (
              <ManifestoSection />
            )}

            {activeTab === 'gallery' && (
              <GallerySection
                artworks={artworks}
                setArtworks={setArtworks}
                addToCart={handleAddArtToCart}
                onExploreArtist={(id) => {
                  setSelectedTalentId(id);
                  setActiveTab('talents');
                }}
              />
            )}

            {activeTab === 'talents' && (
              <TalentSection
                talents={talents}
                artworks={artworks}
                selectedTalentId={selectedTalentId}
                setSelectedTalentId={setSelectedTalentId}
                setActiveTab={setActiveTab}
                onExploreArtDetail={handleExploreArtFromTalent}
              />
            )}

            {activeTab === 'shop' && (
              <ShopSection
                items={shopItems}
                addToCart={handleAddShopToCart}
                currentUser={currentUser}
                addNotification={addNotification}
              />
            )}

            {activeTab === 'community' && (
              <CommunitySection
                posts={posts}
                setPosts={setPosts}
              />
            )}

            {activeTab === 'events' && (
              <EventsSection
                events={events}
                setEvents={setEvents}
                notifications={notifications}
                addNotification={addNotification}
                clearNotifications={clearNotifications}
              />
            )}

            {activeTab === 'cart' && (
              <CartCheckout
                cart={cart}
                setCart={setCart}
                clearCart={() => setCart([])}
                addNotification={addNotification}
                setActiveTab={setActiveTab}
              />
            )}

            {activeTab === 'profile' && (
              <ProfileSection
                currentUser={currentUser}
                userRole={userRole}
                talents={talents}
                artworks={artworks}
                openAuthModal={() => setAuthModalOpen(true)}
                triggerToast={addNotification}
                setActiveTab={setActiveTab}
              />
            )}

            {activeTab === 'admin' && (
              <AdminSection
                addNotification={addNotification}
                setActiveTab={setActiveTab}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Decorative and informative Footer assembly */}
      <footer className="bg-slate-950/90 border-t border-white/5 py-12 text-gray-400 font-sans z-10 text-xs no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          {/* Footer Logo & Mission */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded bg-brand-gold flex items-center justify-center text-brand-charcoal font-serif font-black">
                R
              </div>
              <span className="font-serif font-bold text-white tracking-tight">RUMAH ADIKSI</span>
            </div>
            <p className="leading-relaxed">
              Sebuah inisiatif independen pemuda kreatif Pelabuhan Ratu, Sukabumi. Kami mereklamasi bakat-bakat seni tradisional dan modern, membentuk kecanduan positif melalui pameran lukis, daur ulang kriya pantai, gelaran akustik, dan kafe seduhan lokal guna meningkatkan martabat ekonomi kreatif di ujung dermaga Jawa Barat.
            </p>
          </div>

          {/* Location detail */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="font-mono text-[10px] uppercase font-bold text-white tracking-widest">Markas Komunitas</h4>
            <div className="space-y-1 text-gray-300">
              <p className="font-semibold">Basecamp Utama Rumah Adiksi</p>
              <p>Jl. Raya Bayah - Citepus Km 2, Pantai Citepus,</p>
              <p>Kec. Pelabuhanratu, Kabupaten Sukabumi,</p>
              <p>Jawa Barat 43364, Indonesia</p>
            </div>
          </div>

          {/* Socials & hours */}
          <div className="md:col-span-3 space-y-3 text-right md:text-left">
            <h4 className="font-mono text-[10px] uppercase font-bold text-white tracking-widest">Hubungi Kami</h4>
            <div className="space-y-1 text-gray-400">
              <p>Instagram: <a href="#" className="hover:text-brand-gold font-bold">@rumah_adiksi_pesisir</a></p>
              <p>WhatsApp: <span className="text-gray-300 font-mono">+62 812-3456-7890</span></p>
              <p className="pt-2 text-[10px] font-mono text-gray-500">Buka Tiap Hari: 09:00 - 22:00 WIB</p>
            </div>
          </div>
        </div>

        {/* Bottom credits */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 mt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center text-gray-600 gap-4 text-[10px]">
          <div>
            © {new Date().getFullYear()} Rumah Adiksi Pelabuhan Ratu. Seluruh hak cipta dilindungi.
          </div>
          <div>
            Meningkatkan Kedaulatan Seni & Ekonomi Kreatif Pesisir Selatan Sukabumi
          </div>
        </div>
      </footer>

      {/* Auth Error & Domain Diagnostic Fallback Modal */}
      <AnimatePresence>
        {authErrorModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-brand-card border border-brand-gold/30 rounded-3xl p-6 max-w-lg w-full space-y-6 shadow-2xl relative"
            >
              <button
                onClick={() => setAuthErrorModalOpen(false)}
                className="absolute top-4 right-4 p-1.5 text-gray-400 hover:text-white rounded-lg bg-white/5 transition-colors cursor-pointer"
                title="Tutup"
              >
                <X className="w-4 h-4" />
              </button>

              {authErrorMessage === 'operation-not-allowed-anon' ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="inline-flex items-center gap-1.5 text-amber-400 text-xs font-mono font-bold uppercase tracking-widest bg-amber-500/10 px-2.5 py-1 rounded-full">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                      <span>Metode Masuk Dinonaktifkan</span>
                    </div>
                    <h3 className="text-xl font-serif font-black text-white tracking-tight">Aktifkan "Anonymous Auth"</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      Metode masuk sementara (Anonymous Auth) saat ini dinonaktifkan di Konsol Firebase Anda. Silakan ikuti langkah-langkah di bawah ini untuk mengaktifkannya agar Anda dapat berselancar sebagai tamu dengan aman:
                    </p>
                  </div>

                  <div className="bg-slate-950/60 border border-white/5 p-4 rounded-2xl space-y-3 font-sans text-xs text-gray-300">
                    <p className="font-semibold text-white font-mono text-[11px] uppercase tracking-wider text-brand-gold">Langkah Mengaktifkan:</p>
                    <ol className="list-decimal pl-4 space-y-2 text-gray-400">
                      <li>Buka halaman <strong className="text-white">Firebase Console</strong> untuk proyek Anda.</li>
                      <li>Ke menu <strong className="text-white">Authentication</strong> di bilah navigasi kiri.</li>
                      <li>Pilih tab <strong className="text-white">Sign-in method</strong>.</li>
                      <li>Klik tombol <strong className="text-white font-mono text-[11px] bg-white/5 px-1.5 py-0.5 rounded">Add new provider</strong>, lalu pilih <strong className="text-white">Anonymous</strong> (Anonim).</li>
                      <li>Geser kontrol toggle ke posisi aktif (<strong className="text-white">Enable</strong>), lalu klik <strong className="text-white">Save / Simpan</strong>.</li>
                    </ol>
                  </div>
                </div>
              ) : authErrorMessage === 'network-request-failed' ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="inline-flex items-center gap-1.5 text-rose-400 text-xs font-mono font-bold uppercase tracking-widest bg-rose-500/10 px-2.5 py-1 rounded-full">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
                      <span>Koneksi Terhambat</span>
                    </div>
                    <h3 className="text-xl font-serif font-black text-white tracking-tight">Koneksi Firebase Auth Gagal</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      Sistem mendeteksi bahwa permintaan masuk gagal karena diblokir oleh adblocker, kebijakan browser, atau batasan lingkungan sandbox (<code className="text-rose-300 font-mono">auth/network-request-failed</code>).
                    </p>
                  </div>

                  <div className="bg-slate-950/60 border border-white/5 p-4 rounded-2xl space-y-3 font-sans text-xs text-gray-300">
                    <p className="font-semibold text-white font-mono text-[11px] uppercase tracking-wider text-brand-gold">Solusi & Langkah Penanganan:</p>
                    <ul className="list-disc pl-4 space-y-2 text-gray-400">
                      <li>
                        <strong className="text-white">Buka di Tab Baru (Sangat Disarankan):</strong> Lingkungan <em className="italic text-gray-300">Iframe</em> pada editor terkadang memblokir kuki pihak ketiga (<em className="italic text-gray-300">third-party cookies</em>) yang dibutuhkan oleh Firebase untuk memproses otentikasi. Silakan klik tombol "Buka aplikasi di tab baru" atau buka URL pratinjau Anda langsung.
                      </li>
                      <li>
                        <strong className="text-white">Matikan Brave Shields / Adblocker:</strong> Ekstensi seperti Brave Shields atau uBlock Origin memblokir domain otentikasi Google (<code className="text-xs text-brand-gold font-mono font-bold">identitytoolkit.googleapis.com</code>) secara default. Nonaktifkan sementara adblocker Anda untuk situs ini.
                      </li>
                      <li>
                        <strong className="text-white">Gunakan Koneksi Internet Lain:</strong> Pastikan jaringan internet Anda stabil dan tidak sedang memblokir layanan API eksternal.
                      </li>
                    </ul>
                  </div>
                </div>
              ) : (
                <>
                  <div className="space-y-2">
                    <div className="inline-flex items-center gap-1.5 text-amber-400 text-xs font-mono font-bold uppercase tracking-widest bg-amber-500/10 px-2.5 py-1 rounded-full">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                      <span>Saran Keamanan Domain</span>
                    </div>
                    <h3 className="text-xl font-serif font-black text-white tracking-tight">Otorisasi Domain Firebase</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      Layanan login Google mendeteksi bahwa domain pratinjau ini belum diotorisasi di Konsol Firebase Anda. Silakan tambahkan domain ini ke Konsol Firebase Anda agar fitur login eksternal dapat terhubung.
                    </p>
                  </div>

                  {/* Informative Diagnostic Step Panel */}
                  <div className="bg-slate-950/60 border border-white/5 p-4 rounded-2xl space-y-3 font-mono text-[11px] text-gray-300">
                    <div className="flex justify-between items-center text-brand-gold font-bold">
                      <span>DOMAIN AKTIF ANDA:</span>
                      <button
                        onClick={() => {
                          const hostname = window.location.hostname;
                          try {
                            if (navigator.clipboard) {
                              navigator.clipboard.writeText(hostname)
                                .then(() => {
                                  addNotification("Domain disalin ke papan klip.");
                                })
                                .catch(() => {
                                  // Safe fallback utilizing temporary input element
                                  const tempInput = document.createElement("input");
                                  tempInput.value = hostname;
                                  document.body.appendChild(tempInput);
                                  tempInput.select();
                                  document.execCommand("copy");
                                  document.body.removeChild(tempInput);
                                  addNotification("Domain disalin (metode cadangan).");
                                });
                            } else {
                              const tempInput = document.createElement("input");
                              tempInput.value = hostname;
                              document.body.appendChild(tempInput);
                              tempInput.select();
                              document.execCommand("copy");
                              document.body.removeChild(tempInput);
                              addNotification("Domain disalin (metode cadangan).");
                            }
                          } catch (err) {
                            console.info("Clipboard copy fallback active due to iframe restriction:", err);
                            addNotification(`Akses klip terbatas. Silakan salin manual: ${hostname}`);
                          }
                        }}
                        className="text-[10px] uppercase bg-white/5 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer text-gray-400 hover:text-white transition-colors"
                      >
                        Salin Domain
                      </button>
                    </div>
                    <div className="p-2 bg-black/40 rounded border border-white/5 text-white select-all text-center text-xs font-sans font-bold">
                      {window.location.hostname}
                    </div>
                    <div className="space-y-1.5 font-sans text-xs text-gray-400">
                      <p className="font-semibold text-white">Langkah Otorisasi:</p>
                      <ol className="list-decimal pl-4 space-y-1">
                        <li>Buka <strong className="text-white">Firebase Console</strong> untuk proyek Anda.</li>
                        <li>Pilih menu <strong className="text-white">Authentication</strong> &gt; <strong className="text-white">Settings</strong> &gt; <strong className="text-white">Authorized domains</strong>.</li>
                        <li>Klik <strong className="text-white">Add domain</strong>, tempel domain di atas lalu simpan.</li>
                      </ol>
                    </div>
                  </div>

                  <div className="border-t border-white/5 pt-4 space-y-4">
                    <div className="space-y-1">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                        Atau Masuk Sementara (Non-Popup)
                      </h4>
                      <p className="text-[11px] text-gray-400">
                        Anda bisa langsung masuk dengan nama samaran melalui Firebase Anonymous Auth (aman dari pembatasan domain pratinjau).
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={tempNickname}
                        onChange={(e) => setTempNickname(e.target.value)}
                        placeholder="Masukkan nama samaran Anda..."
                        className="flex-grow bg-slate-950/80 border border-white/10 hover:border-white/20 focus:border-brand-gold outline-none rounded-xl px-4 py-2 text-xs text-white placeholder-gray-500 font-sans transition-colors"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleAnonymousLogin(tempNickname);
                        }}
                      />
                      <button
                        onClick={() => handleAnonymousLogin(tempNickname)}
                        disabled={isLoggingInAnonymously || !tempNickname.trim()}
                        className="px-4 py-2 bg-brand-gold hover:bg-amber-500 disabled:bg-neutral-800 disabled:text-gray-600 text-brand-charcoal font-bold text-xs rounded-xl transition-all font-mono whitespace-nowrap cursor-pointer flex items-center justify-center min-w-[120px]"
                      >
                        {isLoggingInAnonymously ? 'Menghubungkan...' : 'Masuk Tamu'}
                      </button>
                    </div>
                  </div>
                </>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {authModalOpen && (
          <AuthModal
            isOpen={authModalOpen}
            onClose={() => setAuthModalOpen(false)}
            onSuccess={(message) => addNotification(message)}
            onGoogleLogin={handleGoogleLogin}
            onAnonymousLogin={handleAnonymousLogin}
          />
        )}

        {/* Mobile Bottom Navigation Dock */}
        <div className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-brand-card/90 backdrop-blur-xl border-t border-white/5 py-2 px-4 pb-safe-bottom flex items-center justify-around shadow-[0_-8px_30px_rgb(0,0,0,0.5)]">
          <button
            onClick={() => {
              setActiveTab('beranda');
              setMobileMenuOpen(false);
            }}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'beranda' ? 'text-brand-gold' : 'text-gray-400'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[9px] font-medium tracking-tight font-sans">Beranda</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('gallery');
              setMobileMenuOpen(false);
            }}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'gallery' ? 'text-brand-gold' : 'text-gray-400'
            }`}
          >
            <Palette className="w-5 h-5" />
            <span className="text-[9px] font-medium tracking-tight font-sans">Galeri</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('community');
              setMobileMenuOpen(false);
            }}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all relative ${
              activeTab === 'community' ? 'text-brand-gold' : 'text-gray-400'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-[9px] font-medium tracking-tight font-sans">Komunitas</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('shop');
              setMobileMenuOpen(false);
            }}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all relative ${
              activeTab === 'shop' ? 'text-brand-gold' : 'text-gray-400'
            }`}
          >
            <Coffee className="w-5 h-5" />
            <span className="text-[9px] font-medium tracking-tight font-sans">Toko</span>
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              mobileMenuOpen ? 'text-brand-gold' : 'text-gray-400'
            }`}
          >
            <Menu className="w-5 h-5" />
            <span className="text-[9px] font-medium tracking-tight font-sans">Lainnya</span>
          </button>
        </div>

        {/* Beautiful Mobile Slide-up Bottom Sheet Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <>
              {/* Dark Backing Backdrop Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6 }}
                exit={{ opacity: 0 }}
                onClick={() => setMobileMenuOpen(false)}
                className="lg:hidden fixed inset-0 bg-black z-50 backdrop-blur-sm"
              />
              {/* Bottom Sheet Modal Container */}
              <motion.div
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 220 }}
                className="lg:hidden fixed bottom-0 inset-x-0 z-50 bg-brand-card/95 backdrop-blur-xl border-t border-white/10 rounded-t-[2.5rem] p-6 pb-20 max-h-[85vh] overflow-y-auto font-sans shadow-2xl space-y-6"
              >
                {/* Visual Handlebar decoration */}
                <div className="w-12 h-1 bg-white/20 rounded-full mx-auto" />

                {/* Header Context */}
                <div className="flex justify-between items-center border-b border-white/5 pb-4">
                  <div>
                    <h3 className="text-base font-serif font-black text-white">Rumah Adiksi</h3>
                    <p className="text-[10px] font-mono whitespace-nowrap text-brand-gold uppercase tracking-wider">
                      Pelabuhan Ratu Creative Hub
                    </p>
                  </div>
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* User Info / Sign-In CTAs on Mobile Menu */}
                <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                  {currentUser ? (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {currentUser.photoURL ? (
                          <img
                            src={currentUser.photoURL}
                            alt={currentUser.displayName || 'User'}
                            className="w-10 h-10 rounded-full border border-brand-gold/50"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-10 h-10 bg-brand-gold/20 text-brand-gold rounded-full flex items-center justify-center font-bold text-sm font-mono">
                            {currentUser.displayName?.charAt(0) || 'U'}
                          </div>
                        )}
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-white block">
                              {currentUser.displayName || 'Kreator Adiksi'}
                            </span>
                            {userRole === 'admin' && (
                              <span className="text-[8px] font-mono uppercase bg-brand-gold text-brand-charcoal px-1.5 py-0.5 rounded font-black">
                                Admin
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] font-mono text-gray-400 truncate max-w-[150px] block">
                            {currentUser.email || 'Anonymous Guest'}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          handleLogout();
                          setMobileMenuOpen(false);
                        }}
                        className="p-2 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-mono text-[9px] font-bold uppercase rounded-lg border border-rose-500/20"
                      >
                        Keluar
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-[11px] text-gray-400">
                        Masuk untuk menggelar gagasan, menyumbang karya, kelas pameran, dan berbelanja merchandise.
                      </p>
                      <button
                        onClick={() => {
                          setMobileMenuOpen(false);
                          setAuthModalOpen(true);
                        }}
                        className="w-full py-2.5 bg-gradient-to-r from-brand-gold to-amber-500 hover:from-white hover:to-white text-brand-charcoal font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition-all font-mono"
                      >
                        <LogIn className="w-4 h-4" /> <span>Masuk / Akses Akun</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Navigation Links Grid for secondary tabs */}
                <div className="space-y-2">
                  <span className="text-[10px] font-mono font-bold uppercase text-brand-gold tracking-widest block mb-1">
                    Halaman & Program
                  </span>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => {
                        setActiveTab('manifesto');
                        setMobileMenuOpen(false);
                      }}
                      className={`p-3.5 rounded-2xl border text-left flex flex-col gap-1.5 transition-all ${
                        activeTab === 'manifesto'
                          ? 'bg-brand-gold/10 border-brand-gold/40 text-brand-gold'
                          : 'bg-white/5 border-white/5 hover:border-white/10 text-gray-300'
                      }`}
                    >
                      <Scroll className="w-5 h-5 text-brand-gold" />
                      <span className="text-xs font-bold block">Manifesto Hub</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('talents');
                        setMobileMenuOpen(false);
                        setSelectedTalentId(null);
                      }}
                      className={`p-3.5 rounded-2xl border text-left flex flex-col gap-1.5 transition-all ${
                        activeTab === 'talents'
                          ? 'bg-brand-gold/10 border-brand-gold/40 text-brand-gold'
                          : 'bg-white/5 border-white/5 hover:border-white/10 text-gray-300'
                      }`}
                    >
                      <Users className="w-5 h-5 text-brand-gold" />
                      <span className="text-xs font-bold block">Direktori Bakat</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('profile');
                        setMobileMenuOpen(false);
                      }}
                      className={`p-3.5 rounded-2xl border text-left flex flex-col gap-1.5 transition-all ${
                        activeTab === 'profile'
                          ? 'bg-brand-gold/10 border-brand-gold/40 text-brand-gold'
                          : 'bg-white/5 border-white/5 hover:border-white/10 text-gray-300'
                      }`}
                    >
                      <UserIcon className="w-5 h-5 text-brand-gold" />
                      <span className="text-xs font-bold block">Profil Saya</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('events');
                        setMobileMenuOpen(false);
                      }}
                      className={`p-3.5 rounded-2xl border text-left flex flex-col gap-1.5 transition-all ${
                        activeTab === 'events'
                          ? 'bg-brand-gold/10 border-brand-gold/40 text-brand-gold'
                          : 'bg-white/5 border-white/5 hover:border-white/10 text-gray-300'
                      }`}
                    >
                      <Calendar className="w-5 h-5 text-brand-gold" />
                      <span className="text-xs font-bold block">Acara Seni</span>
                    </button>

                    {userRole === 'admin' && (
                      <button
                        onClick={() => {
                          setActiveTab('admin');
                          setMobileMenuOpen(false);
                        }}
                        className={`p-3.5 rounded-2xl border text-left flex flex-col gap-1.5 transition-all ${
                          activeTab === 'admin'
                            ? 'bg-brand-gold/10 border-brand-gold/40 text-brand-gold'
                            : 'bg-white/5 border-white/5 hover:border-white/10 text-gray-300'
                        }`}
                      >
                        <Award className="w-5 h-5 text-brand-gold" />
                        <span className="text-xs font-bold block">Panel Admin</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Mini Community Guidelines Context Info */}
                <div className="text-[10px] text-gray-500 text-center leading-relaxed">
                  Rumah Adiksi Pelabuhan Ratu adalah ruang berserikat mandiri generasi muda. Mari saling memberdayakan.
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
    </div>
  );
}

